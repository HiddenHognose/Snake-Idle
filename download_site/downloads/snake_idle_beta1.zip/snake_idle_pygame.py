import pygame
import json
import os
import math

# Initialize Pygame
pygame.init()

# Signal that game has started successfully (right after pygame init)
signal_file = '/tmp/snake_idle_started.signal'
try:
    with open(signal_file, 'w') as f:
        import time
        f.write(str(int(time.time() * 1000)))  # Milliseconds since epoch
except:
    pass

# Colors - Snake-themed palette
BG_DARK = (10, 25, 15)  # Dark forest green
BG_MEDIUM = (20, 45, 25)  # Medium forest
BG_LIGHT = (30, 65, 35)  # Lighter forest
GREEN_DARK = (15, 50, 25)  # Dark snake green
GREEN_MEDIUM = (25, 90, 45)  # Medium snake green
GREEN_LIGHT = (40, 140, 70)  # Light snake green
GREEN_BRIGHT = (60, 180, 90)  # Bright snake green
SNAKE_SCALE = (35, 75, 45)  # Scale pattern color
SNAKE_BELLY = (50, 120, 60)  # Belly color
GOLD = (200, 180, 50)  # Snake eye gold
GOLD_BRIGHT = (220, 200, 70)
GOLD_DARK = (160, 140, 30)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (100, 100, 100)
DARK_GRAY = (50, 50, 50)
LIGHT_GRAY = (180, 200, 180)  # Slightly green tinted
RED = (200, 50, 50)
DARK_RED = (140, 30, 30)
GREEN_BUTTON = (30, 140, 60)
BLUE_ACCENT = (50, 120, 150)

# Screen setup
WIDTH, HEIGHT = 1600, 1000
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("🐍 Snake Idle - Hatch Your Collection! 🐍")
# Ensure window is visible
pygame.display.flip()
clock = pygame.time.Clock()

# Fonts
try:
    font_title = pygame.font.Font(None, 56)
    font_large = pygame.font.Font(None, 48)
    font_medium = pygame.font.Font(None, 32)
    font_small = pygame.font.Font(None, 24)
    font_tiny = pygame.font.Font(None, 18)
except:
    font_title = pygame.font.SysFont('arial', 56)
    font_large = pygame.font.SysFont('arial', 48)
    font_medium = pygame.font.SysFont('arial', 32)
    font_small = pygame.font.SysFont('arial', 24)
    font_tiny = pygame.font.SysFont('arial', 18)

class SnakeIdleGame:
    def __init__(self):
        self.state_file = 'game_state.json'
        self.state = self.load_state()
        self.last_update = pygame.time.get_ticks()
        self.scroll_y_upgrades = 0
        self.scroll_y_generators = 0
        self.current_tab = 'upgrades'
        self.hovered_item = None
        self.hovered_tab = None
        self.hovered_button = None
        
        # Golden cookie equivalent: Lavender Hognose
        self.lavender_hognose = None  # None when not spawned, dict with 'x', 'y', 'spawn_time', 'duration' when spawned
        self.lavender_hognose_image = None
        self.lavender_hognose_spawn_timer = 0
        self.lavender_hognose_min_spawn_time = 30000  # 30 seconds minimum between spawns
        self.lavender_hognose_max_spawn_time = 120000  # 2 minutes maximum between spawns
        self.lavender_hognose_duration = 15000  # 15 seconds to click it
        self.bonus_message = None  # For displaying bonus messages
        
        # Store button rects to avoid duplication and bugs - RESET TO ORIGINAL HEIGHTS
        self.upgrades_tab_rect = pygame.Rect(50, 430, 230, 50)
        self.generators_tab_rect = pygame.Rect(290, 430, 230, 50)
        self.reset_btn_rect = pygame.Rect(WIDTH - 300, 710, 140, 35)
        self.save_btn_rect = pygame.Rect(WIDTH - 150, 710, 100, 35)
        self.shop_rect = pygame.Rect(50, 490, WIDTH - 100, 500)  # Increased height to show more items (was 210)
        
        # Upgrades - Expanded list with many more options
        self.upgrades = [
            {'id': 1, 'name': 'Better Incubator', 'cost': 10, 'effect': 2, 'description': 'Double your hatching power!'},
            {'id': 2, 'name': 'Warm Lamp', 'cost': 100, 'effect': 2, 'description': 'Snakes hatch twice as fast!'},
            {'id': 3, 'name': 'Premium Nest', 'cost': 1000, 'effect': 2, 'description': 'Professional snake breeding!'},
            {'id': 4, 'name': 'Snake Whisperer', 'cost': 10000, 'effect': 2, 'description': 'You understand snakes now!'},
            {'id': 5, 'name': 'Golden Eggs', 'cost': 100000, 'effect': 2, 'description': 'Legendary golden snake eggs!'},
            {'id': 6, 'name': 'Snake Master', 'cost': 1000000, 'effect': 2, 'description': 'You are the snake master!'},
            {'id': 7, 'name': 'Heat Mat', 'cost': 10000000, 'effect': 2, 'description': 'Perfect temperature for hatching!'},
            {'id': 8, 'name': 'Egg Turner', 'cost': 100000000, 'effect': 2, 'description': 'Automatically rotate eggs!'},
            {'id': 9, 'name': 'Humidity Controller', 'cost': 1000000000, 'effect': 2, 'description': 'Optimal humidity levels!'},
            {'id': 10, 'name': 'Snake DNA Enhancer', 'cost': 10000000000, 'effect': 2, 'description': 'Genetically superior snakes!'},
            {'id': 11, 'name': 'Mega Incubator', 'cost': 100000000000, 'effect': 2, 'description': 'Massive hatching facility!'},
            {'id': 12, 'name': 'Quantum Egg Processor', 'cost': 1000000000000, 'effect': 2, 'description': 'Breakthrough technology!'},
            {'id': 13, 'name': 'Snake Deity Blessing', 'cost': 10000000000000, 'effect': 2, 'description': 'Divine intervention!'},
            {'id': 14, 'name': 'Reality Warper', 'cost': 100000000000000, 'effect': 2, 'description': 'Bend reality itself!'},
            {'id': 15, 'name': 'Snake God Mode', 'cost': 1000000000000000, 'effect': 2, 'description': 'Ultimate power achieved!'},
            {'id': 16, 'name': 'Time Accelerator', 'cost': 10000000000000000, 'effect': 2, 'description': 'Speed up time itself!'},
            {'id': 17, 'name': 'Dimensional Portal', 'cost': 100000000000000000, 'effect': 2, 'description': 'Snakes from other dimensions!'},
            {'id': 18, 'name': 'Universe Creator', 'cost': 1000000000000000000, 'effect': 2, 'description': 'Create universes of snakes!'},
            {'id': 19, 'name': 'Infinity Multiplier', 'cost': 10000000000000000000, 'effect': 2, 'description': 'Infinite hatching power!'},
            {'id': 20, 'name': 'Snake Singularity', 'cost': 100000000000000000000, 'effect': 2, 'description': 'The ultimate upgrade!'},
            {'id': 21, 'name': 'Cosmic Egg Chamber', 'cost': 1000000000000000000000, 'effect': 2, 'description': 'Eggs from the cosmos!'},
            {'id': 22, 'name': 'Snake Dimension', 'cost': 10000000000000000000000, 'effect': 2, 'description': 'An entire dimension of snakes!'},
            {'id': 23, 'name': 'Reality Breaker', 'cost': 100000000000000000000000, 'effect': 2, 'description': 'Break through reality!'},
            {'id': 24, 'name': 'Snake Overlord', 'cost': 1000000000000000000000000, 'effect': 2, 'description': 'Rule over all snakes!'},
            {'id': 25, 'name': 'Eternal Hatching', 'cost': 10000000000000000000000000, 'effect': 2, 'description': 'Hatching never stops!'},
            {'id': 26, 'name': 'Snake Ascension', 'cost': 100000000000000000000000000, 'effect': 2, 'description': 'Ascend to snake godhood!'},
            {'id': 27, 'name': 'Infinite Power', 'cost': 1000000000000000000000000000, 'effect': 2, 'description': 'Unlimited snake power!'},
            {'id': 28, 'name': 'Snake Transcendence', 'cost': 10000000000000000000000000000, 'effect': 2, 'description': 'Transcend all limits!'},
            {'id': 29, 'name': 'Absolute Snake', 'cost': 100000000000000000000000000000, 'effect': 2, 'description': 'The absolute snake!'},
            {'id': 30, 'name': 'Snake Omega', 'cost': 1000000000000000000000000000000, 'effect': 2, 'description': 'The final form!'},
            {'id': 31, 'name': 'START A SNAKE YOUTUBE CHANNEL', 'cost': 10000000000000000000000000000000, 'effect': 2, 'description': 'The ultimate upgrade!'}
        ]
        
        # Generators - Expanded list with many more options
        self.generators = [
            {'id': 1, 'name': 'Emily & Ed', 'base_cost': 15, 'base_production': 0.1, 'description': "Snake Discovery's favorite duo!"},
            {'id': 2, 'name': 'Snake Farm', 'base_cost': 100, 'base_production': 1, 'description': 'A small farm that breeds snakes.'},
            {'id': 3, 'name': 'Snake Nest', 'base_cost': 1100, 'base_production': 8, 'description': 'A cozy nest where snakes multiply.'},
            {'id': 4, 'name': 'Snake Temple', 'base_cost': 12000, 'base_production': 47, 'description': 'An ancient temple dedicated to snakes.'},
            {'id': 5, 'name': 'Snake Laboratory', 'base_cost': 130000, 'base_production': 260, 'description': 'Scientists study and breed snakes.'},
            {'id': 6, 'name': 'Snake Sanctuary', 'base_cost': 1400000, 'base_production': 1400, 'description': 'A massive sanctuary for snakes.'},
            {'id': 7, 'name': 'Snake Hatchery', 'base_cost': 15000000, 'base_production': 16000, 'description': 'Industrial-scale hatching facility.'},
            {'id': 8, 'name': 'Snake Breeding Center', 'base_cost': 160000000, 'base_production': 170000, 'description': 'Advanced breeding technology.'},
            {'id': 9, 'name': 'Snake Research Facility', 'base_cost': 1700000000, 'base_production': 1800000, 'description': 'Cutting-edge snake research.'},
            {'id': 10, 'name': 'Snake Factory', 'base_cost': 18000000000, 'base_production': 19000000, 'description': 'Mass production of snakes!'},
            {'id': 11, 'name': 'Snake City', 'base_cost': 190000000000, 'base_production': 200000000, 'description': 'An entire city of snakes!'},
            {'id': 12, 'name': 'Snake Planet', 'base_cost': 2000000000000, 'base_production': 2100000000, 'description': 'A whole planet for snakes!'},
            {'id': 13, 'name': 'Snake Galaxy', 'base_cost': 21000000000000, 'base_production': 22000000000, 'description': 'Snakes across the galaxy!'},
            {'id': 14, 'name': 'Snake Universe', 'base_cost': 220000000000000, 'base_production': 230000000000, 'description': 'Snakes fill the universe!'},
            {'id': 15, 'name': 'Snake Multiverse', 'base_cost': 2300000000000000, 'base_production': 2400000000000, 'description': 'Infinite snake dimensions!'},
            {'id': 16, 'name': 'Snake Reality Engine', 'base_cost': 24000000000000000, 'base_production': 25000000000000, 'description': 'Generate snake realities!'},
            {'id': 17, 'name': 'Snake Time Machine', 'base_cost': 250000000000000000, 'base_production': 260000000000000, 'description': 'Snakes from all timelines!'},
            {'id': 18, 'name': 'Snake Black Hole', 'base_cost': 2600000000000000000, 'base_production': 2700000000000000, 'description': 'Snakes from the void!'},
            {'id': 19, 'name': 'Snake Infinity Generator', 'base_cost': 27000000000000000000, 'base_production': 28000000000000000, 'description': 'Infinite snake production!'},
            {'id': 20, 'name': 'Snake God', 'base_cost': 280000000000000000000, 'base_production': 290000000000000000, 'description': 'The ultimate snake generator!'},
            {'id': 21, 'name': 'Snake Cosmos', 'base_cost': 2900000000000000000000, 'base_production': 3000000000000000000, 'description': 'Snakes fill the cosmos!'},
            {'id': 22, 'name': 'Snake Dimension', 'base_cost': 30000000000000000000000, 'base_production': 31000000000000000000, 'description': 'A dimension of pure snakes!'},
            {'id': 23, 'name': 'Snake Void', 'base_cost': 310000000000000000000000, 'base_production': 320000000000000000000, 'description': 'Snakes from the void!'},
            {'id': 24, 'name': 'Snake Eternity', 'base_cost': 3200000000000000000000000, 'base_production': 3300000000000000000000, 'description': 'Eternal snake generation!'},
            {'id': 25, 'name': 'Snake Absolute', 'base_cost': 33000000000000000000000000, 'base_production': 34000000000000000000000, 'description': 'Absolute snake power!'},
            {'id': 26, 'name': 'Snake Infinity', 'base_cost': 340000000000000000000000000, 'base_production': 350000000000000000000000, 'description': 'Infinite snake generation!'},
            {'id': 27, 'name': 'Snake Transcendence', 'base_cost': 3500000000000000000000000000, 'base_production': 3600000000000000000000000, 'description': 'Transcend all limits!'},
            {'id': 28, 'name': 'Snake Omega', 'base_cost': 36000000000000000000000000000, 'base_production': 37000000000000000000000000, 'description': 'The final generator!'},
            {'id': 29, 'name': 'Snake Alpha', 'base_cost': 370000000000000000000000000000, 'base_production': 380000000000000000000000000, 'description': 'The beginning and end!'},
            {'id': 30, 'name': 'Snake Everything', 'base_cost': 3800000000000000000000000000000, 'base_production': 3900000000000000000000000000, 'description': 'Everything is snakes!'},
            {'id': 31, 'name': 'Rex', 'base_cost': 39000000000000000000000000000000, 'base_production': 40000000000000000000000000000, 'description': 'The ultimate snake companion!'}
        ]
        
        # Initialize state if needed
        if 'upgrades' not in self.state:
            self.state['upgrades'] = [u.copy() for u in self.upgrades]
            for u in self.state['upgrades']:
                u['purchased'] = False
        if 'generators' not in self.state:
            self.state['generators'] = [g.copy() for g in self.generators]
            for g in self.state['generators']:
                g['count'] = 0
        
        # Egg button
        self.egg_rect = pygame.Rect(WIDTH//2 - 125, 140, 250, 250)
        self.egg_click_animation = 0
        
        # Load all images for upgrades and generators
        self.images = {}  # Dictionary to store all loaded images
        images_dir = os.path.join(os.path.dirname(__file__), 'images')
        root_dir = os.path.dirname(__file__)
        display_size = 96  # Size for all images (doubled from 48)
        
        # Dynamically discover and assign images - each item gets a unique image
        # First, collect all available images (excluding amily.jpg which is reserved for Emily & Ed)
        import glob
        available_images = []
        
        # Check images folder (case-insensitive)
        if os.path.exists(images_dir):
            available_images.extend(glob.glob(os.path.join(images_dir, '*.jpg')))
            available_images.extend(glob.glob(os.path.join(images_dir, '*.png')))
            available_images.extend(glob.glob(os.path.join(images_dir, '*.jpeg')))
            available_images.extend(glob.glob(os.path.join(images_dir, '*.JPG')))
            available_images.extend(glob.glob(os.path.join(images_dir, '*.PNG')))
            available_images.extend(glob.glob(os.path.join(images_dir, '*.JPEG')))
        
        # Also check root directory for images (but exclude amily.jpg)
        root_images = []
        root_images.extend(glob.glob(os.path.join(root_dir, '*.jpg')))
        root_images.extend(glob.glob(os.path.join(root_dir, '*.png')))
        root_images.extend(glob.glob(os.path.join(root_dir, '*.jpeg')))
        root_images.extend(glob.glob(os.path.join(root_dir, '*.JPG')))
        root_images.extend(glob.glob(os.path.join(root_dir, '*.PNG')))
        root_images.extend(glob.glob(os.path.join(root_dir, '*.JPEG')))
        # Filter out amily from root
        root_images = [f for f in root_images if 'amily' not in os.path.basename(f).lower()]
        available_images.extend(root_images)
        
        # Convert to just filenames and filter out amily, remove duplicates
        image_filenames = []
        seen = set()
        for f in available_images:
            basename = os.path.basename(f)
            if 'amily' not in basename.lower() and basename not in seen:
                image_filenames.append(basename)
                seen.add(basename)
        image_filenames = sorted(image_filenames)
        
        # Create lists of all items that need images
        upgrade_names = [u['name'] for u in self.upgrades]
        generator_names = [g['name'] for g in self.generators if g['name'] not in ['Emily & Ed', 'Rex']]  # Exclude Emily & Ed and Rex (special images)
        
        # Assign images uniquely - cycle through available images if needed
        upgrade_image_map = {}
        generator_image_map = {'Emily & Ed': 'amily.jpg', 'Rex': 'rex.jpg'}  # Emily & Ed uses amily.jpg, Rex uses rex.jpg
        
        image_index = 0
        total_images = len(image_filenames)
        
        # Assign upgrades
        for upgrade_name in upgrade_names:
            if total_images > 0:
                upgrade_image_map[upgrade_name] = image_filenames[image_index % total_images]
                image_index += 1
            else:
                # No images available - will show warning but won't break
                upgrade_image_map[upgrade_name] = None
        
        # Assign generators (excluding Emily & Ed)
        for gen_name in generator_names:
            if total_images > 0:
                generator_image_map[gen_name] = image_filenames[image_index % total_images]
                image_index += 1
            else:
                # No images available - will show warning but won't break
                generator_image_map[gen_name] = None
        
        print(f"Image assignment: Found {total_images} images, assigned to {len(upgrade_names)} upgrades and {len(generator_names)} generators")
        
        # Load upgrade images - dynamically assigned, no duplicates
        for upgrade_name, filename in upgrade_image_map.items():
            if filename is None:
                print(f"WARNING: No image available for {upgrade_name}")
                continue
            
            # Try images folder first, then root directory
            image_path = os.path.join(images_dir, filename)
            if not os.path.exists(image_path):
                image_path = os.path.join(root_dir, filename)
            
            if os.path.exists(image_path):
                try:
                    img = pygame.image.load(image_path)
                    self.images[upgrade_name] = pygame.transform.smoothscale(img, (display_size, display_size))
                    print(f"Loaded upgrade image: {upgrade_name} -> {filename}")
                except Exception as e:
                    print(f"Error loading {image_path}: {e}")
            else:
                print(f"WARNING: Image file not found: {filename} for {upgrade_name} (checked images/ and root)")
        
        # Load generator images - dynamically assigned, no duplicates (Emily & Ed uses amily.jpg, Rex uses rex.jpg)
        for gen_name, filename in generator_image_map.items():
            if gen_name == 'Emily & Ed':
                # Special case: amily.jpg is in root directory
                image_path = os.path.join(root_dir, filename)
                # Try multiple case variations
                possible_filenames = ['amily.jpg', 'Amily.jpg', 'amily.JPG', 'Amily.JPG']
                found = False
                for fn in possible_filenames:
                    test_path = os.path.join(root_dir, fn)
                    if os.path.exists(test_path):
                        image_path = test_path
                        found = True
                        break
                if found:
                    try:
                        img = pygame.image.load(image_path)
                        self.images[gen_name] = pygame.transform.smoothscale(img, (display_size, display_size))
                        print(f"Loaded generator image: {gen_name} -> {filename}")
                    except Exception as e:
                        print(f"Error loading {image_path}: {e}")
                else:
                    print(f"WARNING: Emily & Ed image not found in root directory")
            elif gen_name == 'Rex':
                # Special case: Rex uses rex.jpg
                rex_paths = [
                    os.path.join(root_dir, 'rex.jpg'),
                    os.path.join(root_dir, 'rex.JPG'),
                    os.path.join(images_dir, 'rex.jpg'),
                    os.path.join(images_dir, 'rex.JPG')
                ]
                found = False
                for path in rex_paths:
                    if os.path.exists(path):
                        try:
                            img = pygame.image.load(path)
                            self.images[gen_name] = pygame.transform.smoothscale(img, (display_size, display_size))
                            print(f"Loaded generator image: {gen_name} -> rex.jpg")
                            found = True
                            break
                        except Exception as e:
                            print(f"Error loading Rex image {path}: {e}")
                if not found:
                    print(f"WARNING: Rex image (rex.jpg) not found")
            elif filename is None:
                print(f"WARNING: No image available for {gen_name}")
            else:
                # Try images folder first, then root directory
                image_path = os.path.join(images_dir, filename)
                if not os.path.exists(image_path):
                    image_path = os.path.join(root_dir, filename)
                
                if os.path.exists(image_path):
                    try:
                        img = pygame.image.load(image_path)
                        self.images[gen_name] = pygame.transform.smoothscale(img, (display_size, display_size))
                        print(f"Loaded generator image: {gen_name} -> {filename}")
                    except Exception as e:
                        print(f"Error loading {image_path}: {e}")
                else:
                    print(f"WARNING: Image file not found: {filename} for {gen_name} (checked images/ and root)")
        
        # Load background image with transparent shop area
        bg_image_path = os.path.join(root_dir, 'background.png')
        if os.path.exists(bg_image_path):
            try:
                self.background_image = pygame.image.load(bg_image_path).convert_alpha()
                print(f"Loaded background image: {bg_image_path}")
            except Exception as e:
                print(f"Error loading background image {bg_image_path}: {e}")
                self.background_image = None
        else:
            print(f"WARNING: Background image not found: background.png")
            self.background_image = None
        
        # Load special images: Lavender Hognose and YouTube Channel
        # Try to load lavender hognose image
        lavender_hognose_paths = [
            os.path.join(root_dir, 'purpue snek :3.jpg'),
            os.path.join(root_dir, 'purpue snek :3.JPG'),
            os.path.join(root_dir, 'purple snek :3.jpg'),
            os.path.join(images_dir, 'purpue snek :3.jpg'),
            os.path.join(images_dir, 'purpue snek :3.JPG'),
            os.path.join(images_dir, 'purple snek :3.jpg')
        ]
        for path in lavender_hognose_paths:
            if os.path.exists(path):
                try:
                    img = pygame.image.load(path)
                    self.lavender_hognose_image = pygame.transform.smoothscale(img, (80, 80))
                    print(f"Loaded Lavender Hognose image: {path}")
                    break
                except Exception as e:
                    print(f"Error loading lavender hognose image {path}: {e}")
        
        # Load YouTube channel image for upgrade #30
        youtube_paths = [
            os.path.join(root_dir, 'start a youtube channel.jpg'),
            os.path.join(root_dir, 'start a youtube channel.JPG'),
            os.path.join(images_dir, 'start a youtube channel.jpg'),
            os.path.join(images_dir, 'start a youtube channel.JPG')
        ]
        for path in youtube_paths:
            if os.path.exists(path):
                try:
                    img = pygame.image.load(path)
                    self.images['START A SNAKE YOUTUBE CHANNEL'] = pygame.transform.smoothscale(img, (display_size, display_size))
                    print(f"Loaded YouTube Channel image: {path}")
                    break
                except Exception as e:
                    print(f"Error loading YouTube channel image {path}: {e}")
        
    def load_state(self):
        if os.path.exists(self.state_file):
            try:
                with open(self.state_file, 'r') as f:
                    return json.load(f)
            except:
                pass
        return {
            'snakes': 0,
            'snakes_per_click': 1,
            'snakes_per_second': 0
        }
    
    def save_state(self):
        with open(self.state_file, 'w') as f:
            json.dump(self.state, f)
    
    def format_number(self, num):
        if num < 1000:
            return str(int(num))
        elif num < 1000000:
            return f"{num/1000:.2f}K"
        elif num < 1000000000:
            return f"{num/1000000:.2f}M"
        elif num < 1000000000000:
            return f"{num/1000000000:.2f}B"
        else:
            return f"{num/1000000000000:.2f}T"
    
    def format_production(self, num):
        if num < 1:
            return f"{num:.1f}"
        elif num < 1000:
            return str(int(num))
        elif num < 1000000:
            return f"{num/1000:.2f}K"
        elif num < 1000000000:
            return f"{num/1000000:.2f}M"
        else:
            return f"{num/1000000000:.2f}T"
    
    def calculate_sps(self):
        total = 0
        for gen in self.state['generators']:
            total += gen['count'] * gen['base_production']
        # Apply multiplier if active
        multiplier = self.state.get('production_multiplier', 1.0)
        return total * multiplier
    
    def get_max_scroll(self, tab):
        """Calculate maximum scroll amount for a tab"""
        item_height = 110  # Doubled height for easier clicking (was 55)
        shop_visible_height = self.shop_rect.height - 20  # Height of shop area minus padding
        shop_top_padding = 10  # Padding at top of shop
        
        if tab == 'upgrades':
            total_items = len(self.state['upgrades'])
        else:
            total_items = len(self.state['generators'])
        
        total_height = total_items * item_height
        max_scroll = max(0, total_height - (shop_visible_height - shop_top_padding * 2))
        return max_scroll
    
    def get_generator_cost(self, generator):
        return int(generator['base_cost'] * (1.15 ** generator['count']))
    
    def click_egg(self):
        self.state['snakes'] += self.state['snakes_per_click']
        self.egg_click_animation = 15
        self.save_state()
    
    def buy_upgrade(self, index):
        if 0 <= index < len(self.state['upgrades']):
            upgrade = self.state['upgrades'][index]
            if upgrade['purchased']:
                return False
            
            if self.state['snakes'] >= upgrade['cost']:
                self.state['snakes'] -= upgrade['cost']
                self.state['snakes_per_click'] *= upgrade['effect']
                upgrade['purchased'] = True
                self.save_state()
                return True
        return False
    
    def buy_generator(self, index):
        if 0 <= index < len(self.state['generators']):
            generator = self.state['generators'][index]
            cost = self.get_generator_cost(generator)
            
            if self.state['snakes'] >= cost:
                self.state['snakes'] -= cost
                generator['count'] += 1
                self.state['snakes_per_second'] = self.calculate_sps()
                self.save_state()
                return True
        return False
    
    def reset_game(self):
        if os.path.exists(self.state_file):
            os.remove(self.state_file)
        self.state = {
            'snakes': 0,
            'snakes_per_click': 1,
            'snakes_per_second': 0
        }
        self.state['upgrades'] = [u.copy() for u in self.upgrades]
        for u in self.state['upgrades']:
            u['purchased'] = False
        self.state['generators'] = [g.copy() for g in self.generators]
        for g in self.state['generators']:
            g['count'] = 0
        self.save_state()
    
    def update(self):
        # Update passive income
        current_time = pygame.time.get_ticks()
        if current_time - self.last_update >= 1000:
            if self.state['snakes_per_second'] > 0:
                self.state['snakes'] += self.state['snakes_per_second']
                self.state['snakes_per_second'] = self.calculate_sps()
                self.save_state()
            self.last_update = current_time
        
        # Update animation
        if self.egg_click_animation > 0:
            self.egg_click_animation -= 1
        
        # Update Lavender Hognose (golden cookie equivalent)
        if self.lavender_hognose is None:
            # Not spawned, check if we should spawn it
            if current_time - self.lavender_hognose_spawn_timer >= self.lavender_hognose_min_spawn_time:
                # Random chance to spawn (higher chance as time passes)
                time_since_last = current_time - self.lavender_hognose_spawn_timer
                spawn_chance = min(0.1, (time_since_last - self.lavender_hognose_min_spawn_time) / (self.lavender_hognose_max_spawn_time - self.lavender_hognose_min_spawn_time) * 0.1)
                import random
                if random.random() < spawn_chance or time_since_last >= self.lavender_hognose_max_spawn_time:
                    # Spawn the lavender hognose at a random position
                    import random
                    x = random.randint(100, WIDTH - 100)
                    y = random.randint(200, HEIGHT - 200)
                    self.lavender_hognose = {
                        'x': x,
                        'y': y,
                        'spawn_time': current_time,
                        'duration': self.lavender_hognose_duration
                    }
        else:
            # Check if it's expired
            if current_time - self.lavender_hognose['spawn_time'] >= self.lavender_hognose['duration']:
                self.lavender_hognose = None
                self.lavender_hognose_spawn_timer = current_time
        
        # Update production multiplier if active
        if 'production_multiplier' in self.state and 'multiplier_end_time' in self.state:
            if current_time >= self.state['multiplier_end_time']:
                self.state['production_multiplier'] = 1.0
                del self.state['multiplier_end_time']
        
        # Update bonus message display
        if self.bonus_message:
            if current_time - self.bonus_message['time'] >= self.bonus_message['duration']:
                self.bonus_message = None
    
    def draw_button(self, surface, rect, text, bg_color, text_color=WHITE, hover=False, disabled=False, border_color=None):
        if disabled:
            bg_color = DARK_GRAY
            text_color = GRAY
        elif hover:
            # Brighten on hover
            bg_color = tuple(min(255, c + 30) for c in bg_color)
        
        # Shadow
        shadow_rect = pygame.Rect(rect.x + 3, rect.y + 3, rect.width, rect.height)
        pygame.draw.rect(surface, (0, 0, 0, 80), shadow_rect)
        
        # Button background
        pygame.draw.rect(surface, bg_color, rect)
        
        # Border
        border = border_color if border_color else (tuple(max(0, c - 30) for c in bg_color))
        pygame.draw.rect(surface, border, rect, 2)
        
        # Highlight on top
        if not disabled:
            highlight_rect = pygame.Rect(rect.x, rect.y, rect.width, rect.height // 2)
            highlight_color = tuple(min(255, c + 20) for c in bg_color)
            pygame.draw.rect(surface, highlight_color, highlight_rect)
        
        # Draw text with shadow
        text_surf = font_small.render(text, True, text_color if not disabled else GRAY)
        text_shadow = font_small.render(text, True, BLACK)
        text_rect = text_surf.get_rect(center=rect.center)
        surface.blit(text_shadow, (text_rect.x + 1, text_rect.y + 1))
        surface.blit(text_surf, text_rect)
    
    def draw(self):
        # Clamp scroll positions to valid ranges - prevent negative scrolls
        max_scroll_upgrades = self.get_max_scroll('upgrades')
        max_scroll_generators = self.get_max_scroll('generators')
        self.scroll_y_upgrades = max(0, min(max_scroll_upgrades, max(0, self.scroll_y_upgrades)))
        self.scroll_y_generators = max(0, min(max_scroll_generators, max(0, self.scroll_y_generators)))
        
        # Reset hover states at start of each frame
        self.hovered_item = None
        self.hovered_tab = None
        self.hovered_button = None
        
        mouse_pos = pygame.mouse.get_pos()
        shop_rect = self.shop_rect
        
        # Draw shop items on a separate surface (behind background)
        shop_items_surface = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        y_offset = 500 - (self.scroll_y_upgrades if self.current_tab == 'upgrades' else self.scroll_y_generators)
        item_height = 110
        item_width = WIDTH - 120
        shop_top = shop_rect.y + 10
        shop_bottom = shop_rect.y + shop_rect.height - 10
        
        if self.current_tab == 'upgrades':
            for i, upgrade in enumerate(self.state['upgrades']):
                item_y = y_offset + i * item_height
                if item_y + item_height < shop_top or item_y > shop_bottom:
                    continue
                item_rect = pygame.Rect(60, item_y, item_width, item_height - 3)
                hover = item_rect.collidepoint(mouse_pos)
                if upgrade['purchased']:
                    bg_color = (50, 50, 50)
                elif hover:
                    bg_color = GREEN_MEDIUM
                else:
                    bg_color = (35, 80, 55)
                shadow_rect = pygame.Rect(item_rect.x + 2, item_rect.y + 2, item_rect.width, item_rect.height)
                pygame.draw.rect(shop_items_surface, (0, 0, 0, 60), shadow_rect)
                pygame.draw.rect(shop_items_surface, bg_color, item_rect)
                border_color = GOLD if hover and not upgrade['purchased'] else (GREEN_LIGHT if hover else (60, 60, 60))
                pygame.draw.rect(shop_items_surface, border_color, item_rect, 2)
                status_x = item_rect.x + 15
                text_y = item_rect.y + (item_rect.height - font_small.get_height()) // 2
                text_x = status_x
                if upgrade['name'] in self.images:
                    img = self.images[upgrade['name']]
                    img_size = img.get_width()
                    img_y = item_rect.y + (item_rect.height - img_size) // 2
                    img_border = pygame.Rect(text_x - 2, img_y - 2, img_size + 4, img_size + 4)
                    pygame.draw.rect(shop_items_surface, GOLD, img_border, 2)
                    shop_items_surface.blit(img, (text_x, img_y))
                    text_x += img_size + 10
                if upgrade['purchased']:
                    status_text = font_small.render("[SOLD]", True, GOLD)
                else:
                    status_text = font_small.render("[BUY]", True, GREEN_LIGHT)
                shop_items_surface.blit(status_text, (text_x, text_y))
                cost_text = "SOLD" if upgrade['purchased'] else f"{self.format_number(upgrade['cost'])} snakes"
                name_text = f"{upgrade['name']} - {cost_text}"
                text_color = GRAY if upgrade['purchased'] else (GOLD_BRIGHT if hover else WHITE)
                item_text = font_small.render(name_text, True, text_color)
                shop_items_surface.blit(item_text, (text_x + status_text.get_width() + 15, text_y))
        else:
            for i, gen in enumerate(self.state['generators']):
                item_y = y_offset + i * item_height
                if item_y + item_height < shop_top or item_y > shop_bottom:
                    continue
                item_rect = pygame.Rect(60, item_y, item_width, item_height - 3)
                hover = item_rect.collidepoint(mouse_pos)
                if hover:
                    bg_color = GREEN_MEDIUM
                    self.hovered_item = ('generator', i)
                else:
                    bg_color = (35, 80, 55)
                shadow_rect = pygame.Rect(item_rect.x + 2, item_rect.y + 2, item_rect.width, item_rect.height)
                pygame.draw.rect(shop_items_surface, (0, 0, 0, 60), shadow_rect)
                pygame.draw.rect(shop_items_surface, bg_color, item_rect)
                border_color = GOLD if hover else GREEN_LIGHT
                pygame.draw.rect(shop_items_surface, border_color, item_rect, 2)
                text_x = item_rect.x + 15
                if gen['name'] in self.images:
                    img = self.images[gen['name']]
                    img_size = img.get_width()
                    img_y = item_rect.y + (item_rect.height - img_size) // 2
                    img_border = pygame.Rect(text_x - 2, img_y - 2, img_size + 4, img_size + 4)
                    pygame.draw.rect(shop_items_surface, GOLD, img_border, 2)
                    shop_items_surface.blit(img, (text_x, img_y))
                    text_x += img_size + 10
                cost = self.get_generator_cost(gen)
                production = gen['count'] * gen['base_production']
                text_y = item_rect.y + (item_rect.height - font_small.get_height()) // 2
                name_text = font_small.render(f"{gen['name']} - ", True, GOLD_BRIGHT if hover else WHITE)
                shop_items_surface.blit(name_text, (text_x, text_y))
                current_x = text_x + name_text.get_width()
                cost_text = font_small.render(f"Cost: {self.format_number(cost)}", True, GREEN_LIGHT)
                shop_items_surface.blit(cost_text, (current_x, text_y))
                current_x += cost_text.get_width() + 10
                if current_x < item_rect.x + item_width - 200:
                    owned_text = font_small.render(f"Owned: {gen['count']}", True, LIGHT_GRAY)
                    shop_items_surface.blit(owned_text, (current_x, text_y))
                    current_x += owned_text.get_width() + 10
                    if current_x < item_rect.x + item_width - 150:
                        prod_text = font_small.render(f"Produces: {self.format_production(production)}/sec", True, LIGHT_GRAY)
                        shop_items_surface.blit(prod_text, (current_x, text_y))
        
        # Blit shop items first (they'll be behind the background)
        screen.blit(shop_items_surface, (0, 0))
        
        # Draw background image if available (has transparent shop area), otherwise draw programmatically
        if hasattr(self, 'background_image') and self.background_image:
            # Use background image with transparent shop area
            screen.blit(self.background_image, (0, 0))
        else:
            # Fallback: draw background programmatically
            screen.fill(BG_DARK)
            for y in range(0, HEIGHT, 2):
                alpha = int(255 * (1 - y / HEIGHT * 0.3))
                color = tuple(min(255, BG_DARK[i] + int((BG_MEDIUM[i] - BG_DARK[i]) * (1 - y / HEIGHT))) for i in range(3))
                pygame.draw.line(screen, color, (0, y), (WIDTH, y))
            
            # Add subtle scale pattern overlay everywhere
            for y in range(0, HEIGHT, 40):
                for x in range(0, WIDTH, 60):
                    if (x // 60 + y // 40) % 2 == 0:
                        scale_rect = pygame.Rect(x, y, 50, 35)
                        pygame.draw.ellipse(screen, SNAKE_SCALE, scale_rect)
        
        # Header with gradient effect
        header_rect = pygame.Rect(0, 0, WIDTH, 130)
        for y in range(header_rect.height):
            alpha = y / header_rect.height
            color = tuple(int(BG_MEDIUM[i] * (1 - alpha) + GREEN_DARK[i] * alpha) for i in range(3))
            pygame.draw.line(screen, color, (0, y), (WIDTH, y))
        
        # Header border glow
        pygame.draw.line(screen, GREEN_BRIGHT, (0, 130), (WIDTH, 130), 3)
        pygame.draw.line(screen, GREEN_MEDIUM, (0, 0), (WIDTH, 0), 2)
        
        # Title with better styling
        title = font_title.render("Snake Idle", True, GOLD_BRIGHT)
        title_shadow = font_title.render("Snake Idle", True, BLACK)
        title_glow = font_title.render("Snake Idle", True, GOLD_DARK)
        title_x = WIDTH//2 - title.get_width()//2
        title_y = 25
        # Glow effect
        for offset in [(2, 2), (-2, 2), (2, -2), (-2, -2)]:
            screen.blit(title_glow, (title_x + offset[0], title_y + offset[1]))
        screen.blit(title_shadow, (title_x + 3, title_y + 3))
        screen.blit(title, (title_x, title_y))
        
        # Stats panel with modern card design
        stats_panel = pygame.Rect(50, 60, WIDTH - 100, 55)
        # Shadow
        shadow_rect = pygame.Rect(stats_panel.x + 4, stats_panel.y + 4, stats_panel.width, stats_panel.height)
        pygame.draw.rect(screen, (0, 0, 0, 100), shadow_rect)
        # Panel background
        pygame.draw.rect(screen, BG_LIGHT, stats_panel)
        pygame.draw.rect(screen, GREEN_MEDIUM, stats_panel, 2)
        # Inner highlight
        highlight_rect = pygame.Rect(stats_panel.x, stats_panel.y, stats_panel.width, stats_panel.height // 2)
        pygame.draw.rect(screen, (BG_LIGHT[0] + 10, BG_LIGHT[1] + 10, BG_LIGHT[2] + 10), highlight_rect)
        
        stats_y = 78
        # Stats with better formatting - spaced evenly across panel
        stats_panel_width = WIDTH - 100
        stats_spacing = stats_panel_width // 3
        
        snakes_text = font_medium.render(f"Snakes: {self.format_number(self.state['snakes'])}", True, GOLD_BRIGHT)
        snakes_shadow = font_medium.render(f"Snakes: {self.format_number(self.state['snakes'])}", True, BLACK)
        snakes_x = stats_panel.x + 20
        screen.blit(snakes_shadow, (snakes_x + 2, stats_y + 2))
        screen.blit(snakes_text, (snakes_x, stats_y))
        
        spc_text = font_medium.render(f"Per Click: {self.format_number(self.state['snakes_per_click'])}", True, GOLD_BRIGHT)
        spc_shadow = font_medium.render(f"Per Click: {self.format_number(self.state['snakes_per_click'])}", True, BLACK)
        spc_x = stats_panel.x + stats_spacing
        screen.blit(spc_shadow, (spc_x + 2, stats_y + 2))
        screen.blit(spc_text, (spc_x, stats_y))
        
        self.state['snakes_per_second'] = self.calculate_sps()
        sps_text = font_medium.render(f"Per Second: {self.format_production(self.state['snakes_per_second'])}", True, GOLD_BRIGHT)
        sps_shadow = font_medium.render(f"Per Second: {self.format_production(self.state['snakes_per_second'])}", True, BLACK)
        sps_x = stats_panel.x + stats_spacing * 2
        screen.blit(sps_shadow, (sps_x + 2, stats_y + 2))
        screen.blit(sps_text, (sps_x, stats_y))
        
        # Egg button with premium visuals - ALL PARTS AS CIRCLES
        egg_size = 250 + (self.egg_click_animation * 3)
        egg_x = WIDTH//2 - egg_size//2
        egg_y = 145 - self.egg_click_animation
        egg_center_x = egg_x + egg_size // 2
        egg_center_y = egg_y + egg_size // 2
        
        # Multiple shadow layers for depth - CIRCLES
        for i in range(3, 0, -1):
            shadow_radius = (egg_size // 2) + i * 2
            # Draw circle shadow using filled circle (pygame doesn't support alpha in draw.circle)
            shadow_surface = pygame.Surface((shadow_radius * 2, shadow_radius * 2), pygame.SRCALPHA)
            shadow_alpha = 40 - i * 10
            pygame.draw.circle(shadow_surface, (0, 0, 0, shadow_alpha), (shadow_radius, shadow_radius), shadow_radius)
            screen.blit(shadow_surface, (egg_center_x + i - shadow_radius, egg_center_y + i - shadow_radius))
        
        # Egg with original beautiful design - PERFECT CIRCLE, NO CORNERS
        egg_radius = egg_size // 2
        
        # Draw egg as a SINGLE perfect circle - no gradient overlay to avoid distortion
        pygame.draw.circle(screen, (255, 248, 220), (egg_center_x, egg_center_y), egg_radius)
        
        # Simple border - just one thin circle outline, no multiple layers
        pygame.draw.circle(screen, (139, 115, 85), (egg_center_x, egg_center_y), egg_radius, 2)
        
        # Shine/highlight - CIRCLE (with alpha)
        highlight_radius = egg_size // 5
        highlight_x = egg_center_x - egg_radius // 3
        highlight_y = egg_center_y - egg_radius // 3
        highlight_surface = pygame.Surface((highlight_radius * 2, highlight_radius * 2), pygame.SRCALPHA)
        pygame.draw.circle(highlight_surface, (255, 255, 255, 150), (highlight_radius, highlight_radius), highlight_radius)
        screen.blit(highlight_surface, (highlight_x - highlight_radius, highlight_y - highlight_radius))
        
        # Inner glow - CIRCLE (with alpha)
        inner_glow_radius = int(egg_radius * 0.7)
        glow_surface = pygame.Surface((inner_glow_radius * 2, inner_glow_radius * 2), pygame.SRCALPHA)
        pygame.draw.circle(glow_surface, (255, 255, 255, 30), (inner_glow_radius, inner_glow_radius), inner_glow_radius)
        screen.blit(glow_surface, (egg_center_x - inner_glow_radius, egg_center_y - inner_glow_radius))
        
        # Hint text with better styling
        hint_text = font_tiny.render("Click to hatch snakes!", True, LIGHT_GRAY)
        hint_shadow = font_tiny.render("Click to hatch snakes!", True, BLACK)
        hint_x = WIDTH//2 - hint_text.get_width()//2
        screen.blit(hint_shadow, (hint_x + 1, egg_y + egg_size + 11))
        screen.blit(hint_text, (hint_x, egg_y + egg_size + 10))
        
        # Update egg_rect for collision detection (still a rect for pygame collision)
        self.egg_rect = pygame.Rect(egg_x, egg_y, egg_size, egg_size)
        
        # Tabs with modern design - taller for snake theme
        upgrades_hover = self.upgrades_tab_rect.collidepoint(mouse_pos)
        generators_hover = self.generators_tab_rect.collidepoint(mouse_pos)
        
        # Active tab gets gold, inactive gets dark green
        if self.current_tab == 'upgrades':
            tab_color = GOLD_DARK if not upgrades_hover else GOLD
            border_color = GOLD_BRIGHT
        else:
            tab_color = GREEN_DARK if not upgrades_hover else GREEN_MEDIUM
            border_color = GREEN_LIGHT
        
        self.draw_button(screen, self.upgrades_tab_rect, "Upgrades", tab_color, WHITE, upgrades_hover, border_color=border_color)
        
        if self.current_tab == 'generators':
            tab_color = GOLD_DARK if not generators_hover else GOLD
            border_color = GOLD_BRIGHT
        else:
            tab_color = GREEN_DARK if not generators_hover else GREEN_MEDIUM
            border_color = GREEN_LIGHT
        
        self.draw_button(screen, self.generators_tab_rect, "Generators", tab_color, WHITE, generators_hover, border_color=border_color)
        
        # Shop area border only (no shadow, no background - items are fully visible)
        shop_rect = self.shop_rect
        # Just draw the border outline
        pygame.draw.rect(screen, GREEN_MEDIUM, shop_rect, 3)
        pygame.draw.rect(screen, GREEN_BRIGHT, shop_rect, 1)
        
        # Draw Lavender Hognose (golden cookie equivalent) if spawned
        if self.lavender_hognose and self.lavender_hognose_image:
            import math
            # Pulsing animation
            current_time = pygame.time.get_ticks()
            time_alive = current_time - self.lavender_hognose['spawn_time']
            pulse = 1.0 + 0.1 * math.sin(time_alive / 200.0)  # Gentle pulsing
            size = int(80 * pulse)
            
            # Draw shadow
            shadow_surface = pygame.Surface((size + 4, size + 4), pygame.SRCALPHA)
            pygame.draw.circle(shadow_surface, (0, 0, 0, 100), (size // 2 + 2, size // 2 + 2), size // 2 + 2)
            screen.blit(shadow_surface, (self.lavender_hognose['x'] - size // 2, self.lavender_hognose['y'] - size // 2 + 2))
            
            # Draw the image with pulsing effect
            scaled_img = pygame.transform.smoothscale(self.lavender_hognose_image, (size, size))
            screen.blit(scaled_img, (self.lavender_hognose['x'] - size // 2, self.lavender_hognose['y'] - size // 2))
            
            # Draw glow effect
            glow_surface = pygame.Surface((size + 10, size + 10), pygame.SRCALPHA)
            pygame.draw.circle(glow_surface, (200, 150, 255, 100), (size // 2 + 5, size // 2 + 5), size // 2 + 5)
            screen.blit(glow_surface, (self.lavender_hognose['x'] - size // 2 - 5, self.lavender_hognose['y'] - size // 2 - 5))
        
        # Draw bonus message if active
        if self.bonus_message:
            current_time = pygame.time.get_ticks()
            elapsed = current_time - self.bonus_message['time']
            if elapsed < self.bonus_message['duration']:
                # Fade out effect
                alpha = int(255 * (1 - elapsed / self.bonus_message['duration']))
                bonus_surf = font_large.render(self.bonus_message['text'], True, GOLD_BRIGHT)
                bonus_surf.set_alpha(alpha)
                bonus_x = WIDTH // 2 - bonus_surf.get_width() // 2
                bonus_y = HEIGHT // 2 - 100
                screen.blit(bonus_surf, (bonus_x, bonus_y))
        
        # Action buttons with premium styling - taller
        reset_hover = self.reset_btn_rect.collidepoint(mouse_pos)
        save_hover = self.save_btn_rect.collidepoint(mouse_pos)
        
        self.draw_button(screen, self.reset_btn_rect, "Reset Game", DARK_RED, WHITE, reset_hover, border_color=RED)
        self.draw_button(screen, self.save_btn_rect, "Save", GREEN_BUTTON, WHITE, save_hover, border_color=GREEN_BRIGHT)
        
        pygame.display.flip()
    
    def handle_click(self, pos):
        # Lavender Hognose (golden cookie equivalent) - check first so it has priority
        if self.lavender_hognose and self.lavender_hognose_image:
            hognose_size = 80
            hognose_rect = pygame.Rect(
                self.lavender_hognose['x'] - hognose_size // 2,
                self.lavender_hognose['y'] - hognose_size // 2,
                hognose_size,
                hognose_size
            )
            if hognose_rect.collidepoint(pos):
                # Clicked the lavender hognose! Give bonus
                import random
                bonus_type = random.choice(['snakes', 'multiplier', 'time'])
                
                if bonus_type == 'snakes':
                    # Give snakes equal to 10 minutes of production
                    bonus = max(100, self.state['snakes_per_second'] * 600)
                    self.state['snakes'] += bonus
                    bonus_text = f"+{self.format_number(bonus)} snakes!"
                elif bonus_type == 'multiplier':
                    # Double production for 30 seconds (stored in state)
                    if 'production_multiplier' not in self.state:
                        self.state['production_multiplier'] = 1.0
                    self.state['production_multiplier'] = 2.0
                    self.state['multiplier_end_time'] = pygame.time.get_ticks() + 30000
                    bonus_text = "2x production for 30s!"
                else:  # time
                    # Give 1 hour of production instantly
                    bonus = max(1000, self.state['snakes_per_second'] * 3600)
                    self.state['snakes'] += bonus
                    bonus_text = f"+{self.format_number(bonus)} snakes!"
                
                # Remove the lavender hognose
                self.lavender_hognose = None
                self.lavender_hognose_spawn_timer = pygame.time.get_ticks()
                self.save_state()
                
                # Show bonus message (we'll display this in the draw function)
                self.bonus_message = {
                    'text': bonus_text,
                    'time': pygame.time.get_ticks(),
                    'duration': 2000  # 2 seconds
                }
                return True
        
        # Egg button
        if self.egg_rect.collidepoint(pos):
            self.click_egg()
            return True
        
        # Tabs - check buttons first to avoid conflicts (using enlarged rects)
        if self.upgrades_tab_rect.collidepoint(pos):
            self.current_tab = 'upgrades'
            max_scroll = self.get_max_scroll('upgrades')
            self.scroll_y_upgrades = min(max_scroll, max(0, self.scroll_y_upgrades))
            return True
        if self.generators_tab_rect.collidepoint(pos):
            self.current_tab = 'generators'
            max_scroll = self.get_max_scroll('generators')
            self.scroll_y_generators = min(max_scroll, max(0, self.scroll_y_generators))
            return True
        
        # Action buttons - check before shop items
        if self.reset_btn_rect.collidepoint(pos):
            return 'reset'
        if self.save_btn_rect.collidepoint(pos):
            self.save_state()
            return True
        
        # Shop items - improved click detection
        if self.shop_rect.collidepoint(pos):
            y_offset = 500 - (self.scroll_y_upgrades if self.current_tab == 'upgrades' else self.scroll_y_generators)
            item_height = 110  # Doubled height for easier clicking (was 55)
            shop_top = self.shop_rect.y + 10
            relative_y = pos[1] - y_offset
            
            # Only process clicks within visible shop area
            if shop_top <= pos[1] <= self.shop_rect.y + self.shop_rect.height - 10 and relative_y >= 0:
                index = int(relative_y // item_height)
                if self.current_tab == 'upgrades':
                    if 0 <= index < len(self.state['upgrades']):
                        self.buy_upgrade(index)
                        return True
                else:
                    if 0 <= index < len(self.state['generators']):
                        self.buy_generator(index)
                        return True
            return False
        
        return False
    
    def run(self):
        running = True
        reset_pending = False
        
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:  # Left click
                        result = self.handle_click(event.pos)
                        if result == 'reset':
                            reset_pending = True
                    elif event.button == 4:  # Scroll up - move content up (increase scroll_y since we subtract it)
                        if self.current_tab == 'upgrades':
                            max_scroll = self.get_max_scroll('upgrades')
                            if max_scroll > 0:  # Only scroll if there's content cut off
                                self.scroll_y_upgrades = min(max_scroll, self.scroll_y_upgrades + 30)
                        else:
                            max_scroll = self.get_max_scroll('generators')
                            if max_scroll > 0:  # Only scroll if there's content cut off
                                self.scroll_y_generators = min(max_scroll, self.scroll_y_generators + 30)
                    elif event.button == 5:  # Scroll down - move content down (decrease scroll_y since we subtract it)
                        if self.current_tab == 'upgrades':
                            max_scroll = self.get_max_scroll('upgrades')
                            if max_scroll > 0:  # Only scroll if there's content cut off
                                self.scroll_y_upgrades = max(0, self.scroll_y_upgrades - 30)
                        else:
                            max_scroll = self.get_max_scroll('generators')
                            if max_scroll > 0:  # Only scroll if there's content cut off
                                self.scroll_y_generators = max(0, self.scroll_y_generators - 30)
                elif event.type == pygame.KEYDOWN:
                    if reset_pending and event.key == pygame.K_y:
                        self.reset_game()
                        reset_pending = False
                    elif reset_pending and event.key == pygame.K_n:
                        reset_pending = False
            
            self.update()
            self.draw()
            
            # Show reset confirmation
            if reset_pending:
                confirm_rect = pygame.Rect(WIDTH//2 - 200, HEIGHT//2 - 50, 400, 100)
                pygame.draw.rect(screen, (50, 50, 50), confirm_rect)
                pygame.draw.rect(screen, RED, confirm_rect, 3)
                confirm_text = font_medium.render("Reset game? Press Y for Yes, N for No", True, WHITE)
                screen.blit(confirm_text, (WIDTH//2 - confirm_text.get_width()//2, HEIGHT//2 - 20))
                pygame.display.flip()
            
            clock.tick(60)
        
        pygame.quit()

if __name__ == '__main__':
    game = SnakeIdleGame()
    game.run()
