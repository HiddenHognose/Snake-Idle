# Snake Idle Game - Python Flask Version

A snake-themed idle clicker game built with Python Flask!

## Setup

1. Install Python (if you don't have it):
   ```bash
   python3 --version
   ```

2. Install Flask:
   ```bash
   pip3 install -r requirements.txt
   ```

3. Make sure you have the `amily.jpg` image file in the `static` folder

4. Run the game:
   ```bash
   python3 app.py
   ```

5. Open your browser and go to:
   ```
   http://localhost:5000
   ```

## How to Play

- Click the egg to hatch snakes!
- Buy upgrades to increase snakes per click
- Buy generators (like Emily & Ed!) for passive income
- Your progress saves automatically

## Files

- `app.py` - Main Flask application (Python backend)
- `templates/index.html` - Game webpage
- `static/style.css` - Styling
- `static/script.js` - Frontend JavaScript
- `static/amily.jpg` - Emily & Ed image
- `game_state.json` - Saved game data (created automatically)

Enjoy your snake idle game! 🐍🥚

