import pygame
import json
import os
import math

# Initialize Pygame
pygame.init()

# Signal that game has started successfully (right after pygame init)
signal_file = '/tmp/snake_idle_started.signal'
try:
    with open(signal_file, 'w') as f:
        import time
        f.write(str(int(time.time() * 1000)))  # Milliseconds since epoch
except:
    pass

# Load and set window icon
def load_window_icon():
    """Load Snakes.png and set it as the window icon"""
    import os
    root_dir = os.path.dirname(os.path.abspath(__file__))
    images_dir = os.path.join(root_dir, 'images')
    
    # Check for easter egg
    force_easter_egg = os.environ.get('FORCE_EASTER_EGG', '').lower() in ('1', 'true', 'yes')
    
    # Try to load missing texture first if easter egg is active
    # Note: We need to load the original snakes.png first to get dimensions, then crop missing texture
    # For now, we'll use a default size since we don't have access to the game instance here
    # The window icon is typically 32x32, so we'll use that
    if force_easter_egg:
        missing_texture_paths = [
            os.path.join(root_dir, 'missingtexture.jpeg'),
            os.path.join(root_dir, 'missingtexture.jpg'),
            os.path.join(images_dir, 'missingtexture.jpeg'),
            os.path.join(images_dir, 'missingtexture.jpg')
        ]
        # First try to get original dimensions from snakes.png
        snakes_icon_paths = [
            os.path.join(images_dir, 'snakes.png'),
            os.path.join(images_dir, 'Snakes.png'),
            os.path.join(root_dir, 'snakes.png'),
            os.path.join(root_dir, 'Snakes.png')
        ]
        orig_width, orig_height = 32, 32  # Default
        for path in snakes_icon_paths:
            if os.path.exists(path):
                try:
                    orig_img = pygame.image.load(path).convert_alpha()
                    orig_width, orig_height = orig_img.get_size()
                    break
                except:
                    pass
        
        for path in missing_texture_paths:
            if os.path.exists(path):
                try:
                    missing_img = pygame.image.load(path).convert_alpha()
                    # Crop missing texture to original dimensions
                    mt_width, mt_height = missing_img.get_size()
                    cropped = pygame.Surface((orig_width, orig_height), pygame.SRCALPHA)
                    # Tile and crop
                    for y in range(0, orig_height, mt_height):
                        for x in range(0, orig_width, mt_width):
                            blit_width = min(mt_width, orig_width - x)
                            blit_height = min(mt_height, orig_height - y)
                            if blit_width > 0 and blit_height > 0:
                                if blit_width == mt_width and blit_height == mt_height:
                                    cropped.blit(missing_img, (x, y))
                                else:
                                    partial = pygame.Surface((blit_width, blit_height), pygame.SRCALPHA)
                                    partial.blit(missing_img, (0, 0), (0, 0, blit_width, blit_height))
                                    cropped.blit(partial, (x, y))
                    window_icon = pygame.transform.smoothscale(cropped, (32, 32))
                    print(f"Loaded window icon (easter egg): missing texture cropped to {orig_width}x{orig_height}")
                    return window_icon
                except Exception as e:
                    print(f"Error loading missing texture for window icon {path}: {e}")
                    continue
    
    snakes_icon_paths = [
        os.path.join(images_dir, 'snakes.png'),
        os.path.join(images_dir, 'Snakes.png'),
        os.path.join(root_dir, 'snakes.png'),
        os.path.join(root_dir, 'Snakes.png'),
        os.path.join(images_dir, 'snakes.PNG'),
        os.path.join(root_dir, 'snakes.PNG')
    ]
    
    for path in snakes_icon_paths:
        if os.path.exists(path):
            try:
                # Load PNG directly with pygame
                img = pygame.image.load(path).convert_alpha()
                # Scale to 32x32 (standard icon size, most systems accept this)
                window_icon = pygame.transform.smoothscale(img, (32, 32))
                print(f"Loaded window icon from: {path}")
                return window_icon
            except Exception as e:
                print(f"Error loading window icon {path}: {e}")
                continue
    
    print("WARNING: Could not find or load Snakes.png for window icon")
    return None

# Colors - Snake-themed palette
BG_DARK = (10, 25, 15)  # Dark forest green
BG_MEDIUM = (20, 45, 25)  # Medium forest
BG_LIGHT = (30, 65, 35)  # Lighter forest
GREEN_DARK = (15, 50, 25)  # Dark snake green
GREEN_MEDIUM = (25, 90, 45)  # Medium snake green
GREEN_LIGHT = (40, 140, 70)  # Light snake green
GREEN_BRIGHT = (60, 180, 90)  # Bright snake green
SNAKE_SCALE = (35, 75, 45)  # Scale pattern color
SNAKE_BELLY = (50, 120, 60)  # Belly color
GOLD = (200, 180, 50)  # Snake eye gold
GOLD_BRIGHT = (220, 200, 70)
GOLD_DARK = (160, 140, 30)
WHITE = (255, 255, 255)
BLACK = (0, 0, 0)
GRAY = (100, 100, 100)
DARK_GRAY = (50, 50, 50)
LIGHT_GRAY = (180, 200, 180)  # Slightly green tinted
RED = (200, 50, 50)
DARK_RED = (140, 30, 30)
YELLOW = (255, 255, 0)
GREEN_BUTTON = (30, 140, 60)
BLUE_ACCENT = (50, 120, 150)
PURPLE = (150, 50, 200)

# Screen setup
WIDTH, HEIGHT = 1600, 1000
screen = pygame.display.set_mode((WIDTH, HEIGHT))
pygame.display.set_caption("🐍 Snake Idle - Hatch Your Collection! 🐍")
# Set window icon (must be done after window is created)
# Try setting icon - wrap in try/except to prevent crashes
try:
    window_icon = load_window_icon()
    if window_icon:
        try:
            pygame.display.set_icon(window_icon)
            print("Window icon set successfully")
        except Exception as e:
            print(f"Warning: Could not set window icon: {e}")
    else:
        print("WARNING: Window icon not set - using default Python icon")
except Exception as e:
    print(f"Warning: Error loading window icon (non-fatal): {e}")
# Ensure window is visible
pygame.display.flip()
clock = pygame.time.Clock()

# Fonts
try:
    font_title = pygame.font.Font(None, 56)
    font_large = pygame.font.Font(None, 48)
    font_medium = pygame.font.Font(None, 32)
    font_small = pygame.font.Font(None, 24)
    font_tiny = pygame.font.Font(None, 18)
except:
    font_title = pygame.font.SysFont('arial', 56)
    font_large = pygame.font.SysFont('arial', 48)
    font_medium = pygame.font.SysFont('arial', 32)
    font_small = pygame.font.SysFont('arial', 24)
    font_tiny = pygame.font.SysFont('arial', 18)

class SnakeIdleGame:
    def __init__(self):
        self.state_file = 'game_state.json'
        self.state = self.load_state()
        # Ensure achievements dict exists and initialize all achievements
        if 'achievements' not in self.state:
            self.state['achievements'] = {}
        # Initialize playtime tracking if not exists
        if 'total_playtime' not in self.state:
            self.state['total_playtime'] = 0
        # Initialize click tracking if not exists
        if 'total_clicks' not in self.state:
            self.state['total_clicks'] = 0
        # Initialize lavender hognose click tracking if not exists
        if 'lavender_hognose_clicked' not in self.state:
            self.state['lavender_hognose_clicked'] = False
        # Initialize all achievements list
        all_achievements = [
            'first click', 'first snake', 'snake collector', 'snake hoarder', 'snake millionaire',
            'snake billionaire', 'generator master', 'production line',
            'first upgrade', 'upgrade enthusiast', 'upgrade master', 'speed demon', 'click master',
            'passive income', 'snake empire', 'you started an education program about reptiles',
            'youtube star', 'rex owner', '100 snakes per second', '1000 snakes per second',
            '10000 snakes per second', '100000 snakes per second', '1 million snakes per second',
            '10 generators', '50 generators', '100 generators', 'all upgrades', 'snake whisperer',
            'super rare morph!', 'oops we lost the code', 'dedicated player'
        ]
        for achievement_name in all_achievements:
            if achievement_name not in self.state['achievements']:
                self.state['achievements'][achievement_name] = False
        self.last_update = pygame.time.get_ticks()
        
        # Easter egg: 1% chance that all images load as missing texture
        # Can be forced by setting FORCE_EASTER_EGG environment variable
        import random
        import os
        force_easter_egg = os.environ.get('FORCE_EASTER_EGG', '').lower() in ('1', 'true', 'yes')
        self.easter_egg_missing_textures = force_easter_egg or (random.random() < 0.01)  # 1% chance (or forced)
        if self.easter_egg_missing_textures:
            print("🎉 EASTER EGG TRIGGERED: All images will use missing texture!")
            # Trigger achievement
            # We'll trigger it after images are loaded
        self.scroll_y_upgrades = 0
        self.scroll_y_generators = 0
        self.scroll_y_achievements = 0
        self.current_tab = 'generators'
        self.hovered_item = None
        self.hovered_tab = None
        self.hovered_button = None
        
        # Golden cookie equivalent: Lavender Hognose
        self.lavender_hognose = None  # None when not spawned, dict with 'x', 'y', 'spawn_time', 'duration' when spawned
        self.lavender_hognose_image = None
        self.lavender_hognose_spawn_timer = 0
        self.lavender_hognose_min_spawn_time = 30000  # 30 seconds minimum between spawns
        self.lavender_hognose_max_spawn_time = 120000  # 2 minutes maximum between spawns
        self.lavender_hognose_duration = 15000  # 15 seconds to click it

        # Thief snake event
        self.thief_snake = None  # Thief snake that steals snakes
        self.thief_snake_spawn_timer = 0
        self.thief_snake_min_spawn_time = 45000  # 45 seconds minimum
        self.thief_snake_max_spawn_time = 180000  # 3 minutes maximum
        self.thief_snake_duration = 15000  # 15 seconds duration
        self.thief_snake_steal_amount = 1  # Steals 1 snake per second
        self.thief_snake_image = None

        self.bonus_message = None  # For displaying bonus messages
        self.save_message = None  # For displaying save confirmation
        self.achievement_message = None  # For displaying achievements
        self.fullscreen = False  # Fullscreen state
        self.achievement_image = None  # For achievement images
        self.snakes_money_icon = None  # Icon for snake money display
        self.shop_background_image = None  # Background image for shop area
        self.missing_texture_image = None  # Fallback image for missing textures
        self.tutorial_bot_frames = []  # Frames for tutorial bot animation
        self.tutorial_bot_frame_index = 0  # Current frame index
        self.tutorial_bot_animation_timer = 0  # Timer for animation
        self.dedicated_player_font = None  # Special font for dedicated player achievement
        
        # Tutorial system
        self.tutorial_active = False
        self.tutorial_type = None  # 'start' or 'ui'
        self.tutorial_step = 0
        self.tutorial_clicks = 0  # Track clicks during tutorial
        self.tutorial_message = None
        self.tutorial_message_timer = 0
        self.pointer_target = None
        self.pointer_frames = []
        self.pointer_frame_index = 0
        self.pointer_animation_timer = 0
        self.tutorial_displayed_text = ""
        self.tutorial_full_text = ""
        self.tutorial_text_index = 0
        self.tutorial_text_timer = 0
        self.tutorial_bot_talking_frames = []
        self.tutorial_bot_nottalking_frames = []
        self.tutorial_bot_talking_frame_index = 0
        self.tutorial_bot_nottalking_frame_index = 0
        self.tutorial_bot_talking_timer = 0
        self.tutorial_bot_nottalking_timer = 0
        self.first_tutorial_completed = False  # Track if first tutorial was completed
        
        # Store button rects to avoid duplication and bugs - RESET TO ORIGINAL HEIGHTS
        self.upgrades_tab_rect = pygame.Rect(50, 430, 230, 50)
        self.generators_tab_rect = pygame.Rect(290, 430, 230, 50)
        self.achievements_tab_rect = pygame.Rect(530, 430, 230, 50)
        self.reset_btn_rect = pygame.Rect(WIDTH - 300, 10, 140, 35)
        self.save_btn_rect = pygame.Rect(WIDTH - 150, 10, 100, 35)
        self.fullscreen_btn_rect = pygame.Rect(10, 10, 100, 35)
        self.tutorial_btn_rect = pygame.Rect(120, 10, 100, 35)
        self.shop_rect = pygame.Rect(50, 490, WIDTH - 100, 500)  # Increased height to show more items (was 210)
        
        # Upgrades - Better difficulty curve with more gradual scaling
        # Costs increase by ~3-4x instead of 10x for smoother progression
        # Effects are additive (added together before multiplying)
        self.upgrades = [
            {'id': 1, 'name': 'Better Incubator', 'cost': 10, 'effect': 1.5, 'description': '+50% hatching power!'},
            {'id': 2, 'name': 'Warm Lamp', 'cost': 50, 'effect': 1.5, 'description': '+50% faster hatching!'},
            {'id': 3, 'name': 'Premium Nest', 'cost': 200, 'effect': 1.75, 'description': '+75% professional breeding!'},
            {'id': 4, 'name': 'Snake Whisperer', 'cost': 1000, 'effect': 1.75, 'description': '+75% snake understanding!'},
            {'id': 5, 'name': 'Golden Eggs', 'cost': 5000, 'effect': 2.0, 'description': '+100% legendary power!'},
            {'id': 6, 'name': 'Snake Master', 'cost': 25000, 'effect': 2.0, 'description': '+100% snake mastery!'},
            {'id': 7, 'name': 'Heat Mat', 'cost': 125000, 'effect': 2.25, 'description': '+125% perfect temperature!'},
            {'id': 8, 'name': 'Egg Turner', 'cost': 600000, 'effect': 2.25, 'description': '+125% automatic rotation!'},
            {'id': 9, 'name': 'Humidity Controller', 'cost': 3000000, 'effect': 2.5, 'description': '+150% optimal humidity!'},
            {'id': 10, 'name': 'Snake DNA Enhancer', 'cost': 15000000, 'effect': 2.5, 'description': '+150% genetic superiority!'},
            {'id': 11, 'name': 'Mega Incubator', 'cost': 75000000, 'effect': 2.75, 'description': '+175% massive facility!'},
            {'id': 12, 'name': 'Quantum Egg Processor', 'cost': 375000000, 'effect': 2.75, 'description': '+175% quantum breakthrough!'},
            {'id': 13, 'name': 'Snake Deity Blessing', 'cost': 1800000000, 'effect': 3.0, 'description': '+200% divine power!'},
            {'id': 14, 'name': 'Reality Warper', 'cost': 9000000000, 'effect': 3.0, 'description': '+200% reality bending!'},
            {'id': 15, 'name': 'Snake God Mode', 'cost': 45000000000, 'effect': 3.25, 'description': '+225% ultimate power!'},
            {'id': 16, 'name': 'Time Accelerator', 'cost': 225000000000, 'effect': 3.25, 'description': '+225% time control!'},
            {'id': 17, 'name': 'Dimensional Portal', 'cost': 1100000000000, 'effect': 3.5, 'description': '+250% dimensional access!'},
            {'id': 18, 'name': 'Universe Creator', 'cost': 5500000000000, 'effect': 3.5, 'description': '+250% universe creation!'},
            {'id': 19, 'name': 'Infinity Multiplier', 'cost': 27500000000000, 'effect': 3.75, 'description': '+275% infinite power!'},
            {'id': 20, 'name': 'Snake Singularity', 'cost': 137500000000000, 'effect': 3.75, 'description': '+275% ultimate singularity!'},
            {'id': 21, 'name': 'Cosmic Egg Chamber', 'cost': 687500000000000, 'effect': 4.0, 'description': '+300% cosmic eggs!'},
            {'id': 22, 'name': 'Snake Dimension', 'cost': 3437500000000000, 'effect': 4.0, 'description': '+300% dimensional snakes!'},
            {'id': 23, 'name': 'Reality Breaker', 'cost': 17187500000000000, 'effect': 4.25, 'description': '+325% reality breaking!'},
            {'id': 24, 'name': 'Snake Overlord', 'cost': 85937500000000000, 'effect': 4.25, 'description': '+325% snake dominion!'},
            {'id': 25, 'name': 'Eternal Hatching', 'cost': 429687500000000000, 'effect': 4.5, 'description': '+350% eternal hatching!'},
            {'id': 26, 'name': 'Snake Ascension', 'cost': 2148437500000000000, 'effect': 4.5, 'description': '+350% godhood ascension!'},
            {'id': 27, 'name': 'Infinite Power', 'cost': 10742187500000000000, 'effect': 4.75, 'description': '+375% unlimited power!'},
            {'id': 28, 'name': 'Snake Transcendence', 'cost': 53710937500000000000, 'effect': 4.75, 'description': '+375% limit transcendence!'},
            {'id': 29, 'name': 'Absolute Snake', 'cost': 268554687500000000000, 'effect': 5.0, 'description': '+400% absolute dominance!'},
            {'id': 30, 'name': 'Snake Omega', 'cost': 1342773437500000000000, 'effect': 5.0, 'description': '+400% final omega power!'},
            {'id': 31, 'name': 'START A SNAKE YOUTUBE CHANNEL', 'cost': 6713867187500000000000, 'effect': 5.5, 'description': '+450% ultimate YouTube fame!'}
        ]
        
        # Generators - Expanded list with many more options
        self.generators = [
            {'id': 1, 'name': 'Emily & Ed', 'base_cost': 15, 'base_production': 0.1, 'description': "Snake Discovery's favorite duo!"},
            {'id': 2, 'name': 'Snake Farm', 'base_cost': 100, 'base_production': 1, 'description': 'A small farm that breeds snakes.'},
            {'id': 3, 'name': 'Snake Nest', 'base_cost': 1100, 'base_production': 8, 'description': 'A cozy nest where snakes multiply.'},
            {'id': 4, 'name': 'Snake Temple', 'base_cost': 12000, 'base_production': 47, 'description': 'An ancient temple dedicated to snakes.'},
            {'id': 5, 'name': 'Snake Laboratory', 'base_cost': 130000, 'base_production': 260, 'description': 'Scientists study and breed snakes.'},
            {'id': 6, 'name': 'Snake Sanctuary', 'base_cost': 1400000, 'base_production': 1400, 'description': 'A massive sanctuary for snakes.'},
            {'id': 7, 'name': 'Snake Hatchery', 'base_cost': 15000000, 'base_production': 16000, 'description': 'Industrial-scale hatching facility.'},
            {'id': 8, 'name': 'Snake Breeding Center', 'base_cost': 160000000, 'base_production': 170000, 'description': 'Advanced breeding technology.'},
            {'id': 9, 'name': 'Snake Research Facility', 'base_cost': 1700000000, 'base_production': 1800000, 'description': 'Cutting-edge snake research.'},
            {'id': 10, 'name': 'Snake Factory', 'base_cost': 18000000000, 'base_production': 19000000, 'description': 'Mass production of snakes!'},
            {'id': 11, 'name': 'Snake City', 'base_cost': 190000000000, 'base_production': 200000000, 'description': 'An entire city of snakes!'},
            {'id': 12, 'name': 'Snake Planet', 'base_cost': 2000000000000, 'base_production': 2100000000, 'description': 'A whole planet for snakes!'},
            {'id': 13, 'name': 'Snake Galaxy', 'base_cost': 21000000000000, 'base_production': 22000000000, 'description': 'Snakes across the galaxy!'},
            {'id': 14, 'name': 'Snake Universe', 'base_cost': 220000000000000, 'base_production': 230000000000, 'description': 'Snakes fill the universe!'},
            {'id': 15, 'name': 'Snake Multiverse', 'base_cost': 2300000000000000, 'base_production': 2400000000000, 'description': 'Infinite snake dimensions!'},
            {'id': 16, 'name': 'Snake Reality Engine', 'base_cost': 24000000000000000, 'base_production': 25000000000000, 'description': 'Generate snake realities!'},
            {'id': 17, 'name': 'Snake Time Machine', 'base_cost': 250000000000000000, 'base_production': 260000000000000, 'description': 'Snakes from all timelines!'},
            {'id': 18, 'name': 'Snake Black Hole', 'base_cost': 2600000000000000000, 'base_production': 2700000000000000, 'description': 'Snakes from the void!'},
            {'id': 19, 'name': 'Snake Infinity Generator', 'base_cost': 27000000000000000000, 'base_production': 28000000000000000, 'description': 'Infinite snake production!'},
            {'id': 20, 'name': 'Snake God', 'base_cost': 280000000000000000000, 'base_production': 290000000000000000, 'description': 'The ultimate snake generator!'},
            {'id': 21, 'name': 'Snake Cosmos', 'base_cost': 2900000000000000000000, 'base_production': 3000000000000000000, 'description': 'Snakes fill the cosmos!'},
            {'id': 22, 'name': 'Snake Dimension', 'base_cost': 30000000000000000000000, 'base_production': 31000000000000000000, 'description': 'A dimension of pure snakes!'},
            {'id': 23, 'name': 'Snake Void', 'base_cost': 310000000000000000000000, 'base_production': 320000000000000000000, 'description': 'Snakes from the void!'},
            {'id': 24, 'name': 'Snake Eternity', 'base_cost': 3200000000000000000000000, 'base_production': 3300000000000000000000, 'description': 'Eternal snake generation!'},
            {'id': 25, 'name': 'Snake Absolute', 'base_cost': 33000000000000000000000000, 'base_production': 34000000000000000000000, 'description': 'Absolute snake power!'},
            {'id': 26, 'name': 'Snake Infinity', 'base_cost': 340000000000000000000000000, 'base_production': 350000000000000000000000, 'description': 'Infinite snake generation!'},
            {'id': 27, 'name': 'Snake Transcendence', 'base_cost': 3500000000000000000000000000, 'base_production': 3600000000000000000000000, 'description': 'Transcend all limits!'},
            {'id': 28, 'name': 'Snake Omega', 'base_cost': 36000000000000000000000000000, 'base_production': 37000000000000000000000000, 'description': 'The final generator!'},
            {'id': 29, 'name': 'Snake Alpha', 'base_cost': 370000000000000000000000000000, 'base_production': 380000000000000000000000000, 'description': 'The beginning and end!'},
            {'id': 30, 'name': 'Snake Everything', 'base_cost': 3800000000000000000000000000000, 'base_production': 3900000000000000000000000000, 'description': 'Everything is snakes!'},
            {'id': 31, 'name': 'Rex', 'base_cost': 39000000000000000000000000000000, 'base_production': 40000000000000000000000000000, 'description': 'The ultimate snake companion!'}
        ]
        
        # Initialize state if needed
        if 'upgrades' not in self.state:
            self.state['upgrades'] = [u.copy() for u in self.upgrades]
            for u in self.state['upgrades']:
                u['purchased'] = False
        if 'generators' not in self.state:
            self.state['generators'] = [g.copy() for g in self.generators]
            for g in self.state['generators']:
                g['count'] = 0
        
        # Recalculate snakes_per_click using additive system (in case of old save files)
        base_click = 1
        total_effect = 0.0
        for u in self.state['upgrades']:
            if u.get('purchased', False):
                total_effect += (u['effect'] - 1.0)
        self.state['snakes_per_click'] = base_click * (1.0 + total_effect)
        
        # Egg button
        self.egg_rect = pygame.Rect(WIDTH//2 - 125, 140, 250, 250)
        self.egg_click_animation = 0
        
        # Load all images for upgrades and generators
        self.images = {}  # Dictionary to store all loaded images
        images_dir = os.path.join(os.path.dirname(__file__), 'images')
        root_dir = os.path.dirname(__file__)
        
        # Load missing texture fallback image FIRST (needed for easter egg)
        missing_texture_paths = [
            os.path.join(root_dir, 'Missingtexture.jpeg'),
            os.path.join(root_dir, 'Missingtexture.JPEG'),
            os.path.join(root_dir, 'Missingtexture.jpg'),
            os.path.join(root_dir, 'Missingtexture.JPG'),
            os.path.join(root_dir, 'missingtexture.jpeg'),
            os.path.join(root_dir, 'missingtexture.JPEG'),
            os.path.join(root_dir, 'missingtexture.jpg'),
            os.path.join(root_dir, 'missingtexture.JPG'),
            os.path.join(images_dir, 'Missingtexture.jpeg'),
            os.path.join(images_dir, 'Missingtexture.JPEG'),
            os.path.join(images_dir, 'Missingtexture.jpg'),
            os.path.join(images_dir, 'Missingtexture.JPG'),
            os.path.join(images_dir, 'missingtexture.jpeg'),
            os.path.join(images_dir, 'missingtexture.JPEG'),
            os.path.join(images_dir, 'missingtexture.jpg'),
            os.path.join(images_dir, 'missingtexture.JPG')
        ]
        for path in missing_texture_paths:
            if os.path.exists(path):
                try:
                    self.missing_texture_image = pygame.image.load(path).convert_alpha()
                    print(f"Loaded missing texture fallback: {path}")
                    break
                except Exception as e:
                    print(f"Error loading missing texture {path}: {e}")
        display_size = 96  # Size for all images (doubled from 48)
        
        # Dynamically discover and assign images - each item gets a unique image
        # Load ALL images from the images folder (excluding special ones: amily, rex, youtuber)
        import glob
        available_images = []
        
        # Only check images folder (case-insensitive) - load everything
        if os.path.exists(images_dir):
            available_images.extend(glob.glob(os.path.join(images_dir, '*.jpg')))
            available_images.extend(glob.glob(os.path.join(images_dir, '*.png')))
            available_images.extend(glob.glob(os.path.join(images_dir, '*.jpeg')))
            available_images.extend(glob.glob(os.path.join(images_dir, '*.JPG')))
            available_images.extend(glob.glob(os.path.join(images_dir, '*.PNG')))
            available_images.extend(glob.glob(os.path.join(images_dir, '*.JPEG')))
        
        # Convert to just filenames - include ALL images from images folder, remove duplicates
        image_filenames = []
        seen = set()
        used_images = set()  # Track images that are reserved for special items
        
        for f in available_images:
            basename = os.path.basename(f)
            basename_lower = basename.lower()
            
            # Mark special images as used (Emily & Ed, Rex, YouTube, Purple Hognose, Education, Snakes money icon)
            if 'amily' in basename_lower:
                used_images.add(basename)
                print(f"Marked as USED (Emily & Ed): {basename}")
            elif 'rex' in basename_lower and (basename_lower.endswith('.jpg') or basename_lower.endswith('.jpeg') or basename_lower.endswith('.png')):
                used_images.add(basename)
                print(f"Marked as USED (Rex): {basename}")
            elif 'youtube' in basename_lower or 'youtuber' in basename_lower or ('start' in basename_lower and 'youtube' in basename_lower and 'channel' in basename_lower):
                used_images.add(basename)
                print(f"Marked as USED (YouTube upgrade): {basename}")
            elif 'purple' in basename_lower and 'hognose' in basename_lower:
                used_images.add(basename)
                print(f"Marked as USED (Purple Hognose): {basename}")
            elif 'education' in basename_lower and basename_lower.endswith('.png'):
                used_images.add(basename)
                print(f"Marked as USED (Achievement): {basename}")
            elif 'snakes' in basename_lower and (basename_lower.endswith('.avif') or basename_lower.endswith('.AVIF')):
                used_images.add(basename)
                print(f"Marked as USED (Snakes money icon): {basename}")
            elif 'snaketummy' in basename_lower and basename_lower.endswith('.png'):
                used_images.add(basename)
                print(f"Marked as USED (Shop background): {basename}")
            elif 'missingtexture' in basename_lower and (basename_lower.endswith('.jpeg') or basename_lower.endswith('.jpg')):
                used_images.add(basename)
                print(f"Marked as USED (Missing texture fallback): {basename}")
            elif 'locked' in basename_lower and basename_lower.endswith('.png'):
                used_images.add(basename)
                print(f"Marked as USED (Locked achievement): {basename}")
            
            # Include all images in the list (for reference), but mark special ones as used
            if basename not in seen:
                image_filenames.append(basename)
                seen.add(basename)
        
        image_filenames = sorted(image_filenames)
        
        # Filter out used images from general assignment
        available_for_assignment = [img for img in image_filenames if img not in used_images]
        
        print(f"Found {len(image_filenames)} images in images/ folder")
        print(f"Marked {len(used_images)} images as USED (reserved for special items)")
        print(f"Available for general assignment: {len(available_for_assignment)} images")
        
        # Create lists of all items that need images
        # Exclude "START A SNAKE YOUTUBE CHANNEL" from regular assignment (it gets a special image)
        upgrade_names = [u['name'] for u in self.upgrades if u['name'] != 'START A SNAKE YOUTUBE CHANNEL']
        generator_names = [g['name'] for g in self.generators if g['name'] not in ['Emily & Ed', 'Rex']]  # Exclude Emily & Ed and Rex (special images)
        
        # Assign images uniquely - cycle through available images if needed
        upgrade_image_map = {}
        # Special assignments: Emily & Ed, Rex, and YouTube upgrade
        generator_image_map = {'Emily & Ed': 'amily.jpg', 'Rex': 'rex.jpeg'}  # Emily & Ed uses amily.jpg, Rex uses rex.jpeg
        
        # Find youtuber image file - use "start a youtube channel.jpg"
        youtuber_image = None
        youtuber_paths = [
            os.path.join(images_dir, 'start a youtube channel.jpg'),
            os.path.join(images_dir, 'start a youtube channel.JPG'),
            os.path.join(images_dir, 'Start a Youtube Channel.jpg'),
            os.path.join(images_dir, 'Start a Youtube Channel.JPG'),
            os.path.join(root_dir, 'start a youtube channel.jpg'),
            os.path.join(root_dir, 'start a youtube channel.JPG'),
            os.path.join(root_dir, 'Start a Youtube Channel.jpg'),
            os.path.join(root_dir, 'Start a Youtube Channel.JPG'),
        ]
        for path in youtuber_paths:
            if os.path.exists(path):
                youtuber_image = os.path.basename(path)
                break
        
        # Assign the youtuber upgrade its special image
        if youtuber_image:
            upgrade_image_map['START A SNAKE YOUTUBE CHANNEL'] = youtuber_image
        else:
            # Fallback: try to find any file with "youtube" or "youtuber" in the name
            for img_file in image_filenames:
                if 'youtube' in img_file.lower() or 'youtuber' in img_file.lower():
                    upgrade_image_map['START A SNAKE YOUTUBE CHANNEL'] = img_file
                    break
            if 'START A SNAKE YOUTUBE CHANNEL' not in upgrade_image_map:
                print(f"WARNING: Could not find 'start a youtube channel.jpg' file")
                upgrade_image_map['START A SNAKE YOUTUBE CHANNEL'] = None
        
        # Assign upgrades (excluding the youtuber one which is already assigned)
        # First, try to load meme assignments from JSON file
        meme_assignments_file = os.path.join(root_dir, 'meme_assignments.json')
        meme_assignments = {}
        if os.path.exists(meme_assignments_file):
            try:
                import json
                with open(meme_assignments_file, 'r') as f:
                    meme_assignments = json.load(f)
                print(f"Loaded {len([k for k, v in meme_assignments.items() if v])} meme assignments from meme_assignments.json")
            except Exception as e:
                print(f"Error loading meme_assignments.json: {e}")
        
        # Assign upgrades - use meme assignments from memes folder
        memes_dir = os.path.join(root_dir, 'memes')
        for upgrade_name in upgrade_names:
            # Check if this upgrade has a meme assignment
            if upgrade_name in meme_assignments and meme_assignments[upgrade_name]:
                assigned_image = meme_assignments[upgrade_name]
                # Verify image exists in memes folder (not images folder)
                image_path = os.path.join(memes_dir, assigned_image)
                if os.path.exists(image_path):
                    # Store as tuple (folder, filename) to indicate it's from memes folder
                    upgrade_image_map[upgrade_name] = ('memes', assigned_image)
                    print(f"Assigned meme to {upgrade_name}: {assigned_image}")
                else:
                    print(f"WARNING: Meme assignment for {upgrade_name} not found in memes/: {assigned_image}")
                    upgrade_image_map[upgrade_name] = None
            else:
                # No meme assignment
                upgrade_image_map[upgrade_name] = None
                print(f"No meme assignment for {upgrade_name}")
        
        # Assign generators (excluding Emily & Ed and Rex)
        # Use meme assignments from JSON file, similar to upgrades
        for gen_name in generator_names:
            # Check if this generator has a meme assignment
            if gen_name in meme_assignments and meme_assignments[gen_name]:
                assigned_image = meme_assignments[gen_name]
                # Verify image exists in memes folder
                image_path = os.path.join(memes_dir, assigned_image)
                if os.path.exists(image_path):
                    # Store as tuple (folder, filename) to indicate it's from memes folder
                    generator_image_map[gen_name] = ('memes', assigned_image)
                    print(f"Assigned meme to {gen_name}: {assigned_image}")
                else:
                    print(f"WARNING: Meme assignment for {gen_name} not found in memes/: {assigned_image}")
                    generator_image_map[gen_name] = None
            else:
                # No meme assignment - fallback to available_for_assignment if any remain
                if len(available_for_assignment) > 0:
                    generator_image_map[gen_name] = available_for_assignment[0]
                    available_for_assignment.pop(0)  # Remove to prevent reuse
                else:
                    # No images available - will show warning but won't break
                    generator_image_map[gen_name] = None
                    print(f"No image available for {gen_name} (all images used)")
        
        print(f"Image assignment complete: {len(used_images)} images marked as used, assigned to {len([x for x in upgrade_image_map.values() if x is not None])} upgrades and {len([x for x in generator_image_map.values() if x is not None])} generators")
        
        # Load upgrade images - dynamically assigned, no duplicates
        for upgrade_name, filename_info in upgrade_image_map.items():
            if filename_info is None:
                print(f"WARNING: No image available for {upgrade_name}")
                continue
            
            # Special handling for YouTube upgrade - use "start a youtube channel.jpg" from images folder
            if upgrade_name == 'START A SNAKE YOUTUBE CHANNEL':
                youtuber_paths = [
                    os.path.join(images_dir, 'start a youtube channel.jpg'),
                    os.path.join(images_dir, 'start a youtube channel.JPG'),
                    os.path.join(images_dir, 'Start a Youtube Channel.jpg'),
                    os.path.join(images_dir, 'Start a Youtube Channel.JPG'),
                    os.path.join(root_dir, 'start a youtube channel.jpg'),
                    os.path.join(root_dir, 'start a youtube channel.JPG'),
                    os.path.join(root_dir, 'Start a Youtube Channel.jpg'),
                    os.path.join(root_dir, 'Start a Youtube Channel.JPG'),
                ]
                found = False
                for path in youtuber_paths:
                    if os.path.exists(path):
                        try:
                            # Easter egg: replace with missing texture cropped to original dimensions
                            if self.easter_egg_missing_textures:
                                # Load original to get dimensions
                                original_img = pygame.image.load(path)
                                orig_width, orig_height = original_img.get_size()
                                # Crop missing texture to exact original dimensions
                                missing_tex = self.crop_missing_texture(orig_width, orig_height)
                                if missing_tex:
                                    # Scale to display size after cropping
                                    self.images[upgrade_name] = pygame.transform.smoothscale(missing_tex, (display_size, display_size))
                                    found = True
                                    break
                            img = pygame.image.load(path)
                            self.images[upgrade_name] = pygame.transform.smoothscale(img, (display_size, display_size))
                            print(f"Loaded upgrade image: {upgrade_name} -> {os.path.basename(path)}")
                            found = True
                            break
                        except Exception as e:
                            print(f"Error loading youtuber image {path}: {e}")
                if not found:
                    print(f"WARNING: 'start a youtube channel.jpg' not found for {upgrade_name}")
                    # Use missing texture as fallback (16x16 if no original)
                    missing_tex = self.crop_missing_texture(16, 16)
                    if missing_tex:
                        # Scale to display size
                        self.images[upgrade_name] = pygame.transform.smoothscale(missing_tex, (display_size, display_size))
                continue
            
            # Check if filename_info is a tuple (folder, filename) for memes, or just a string for images folder
            if isinstance(filename_info, tuple):
                folder, filename = filename_info
                if folder == 'memes':
                    # Load from memes folder
                    image_path = os.path.join(root_dir, 'memes', filename)
                else:
                    # Load from specified folder
                    image_path = os.path.join(root_dir, folder, filename)
            else:
                # Legacy: just filename, load from images folder
                filename = filename_info
                image_path = os.path.join(images_dir, filename)
            
            if os.path.exists(image_path):
                try:
                    # Easter egg: replace all images with missing texture cropped to original dimensions
                    if self.easter_egg_missing_textures:
                        # Load original to get dimensions
                        original_img = pygame.image.load(image_path)
                        orig_width, orig_height = original_img.get_size()
                        # Crop missing texture to exact original dimensions
                        missing_tex = self.crop_missing_texture(orig_width, orig_height)
                        if missing_tex:
                            # Scale to display size after cropping
                            self.images[upgrade_name] = pygame.transform.smoothscale(missing_tex, (display_size, display_size))
                        else:
                            img = pygame.image.load(image_path)
                            self.images[upgrade_name] = pygame.transform.smoothscale(img, (display_size, display_size))
                    else:
                        img = pygame.image.load(image_path)
                        self.images[upgrade_name] = pygame.transform.smoothscale(img, (display_size, display_size))
                    print(f"Loaded upgrade image: {upgrade_name} -> {filename}")
                except Exception as e:
                    print(f"Error loading {image_path}: {e}")
                    # Use missing texture as fallback (16x16 if no original)
                    missing_tex = self.crop_missing_texture(16, 16)
                    if missing_tex:
                        # Scale to display size
                        self.images[upgrade_name] = pygame.transform.smoothscale(missing_tex, (display_size, display_size))
            else:
                print(f"WARNING: Image file not found: {image_path} for {upgrade_name}")
                # Use missing texture as fallback (16x16 if no original)
                missing_tex = self.crop_missing_texture(16, 16)
                if missing_tex:
                    # Scale to display size
                    self.images[upgrade_name] = pygame.transform.smoothscale(missing_tex, (display_size, display_size))
        
        # Load generator images - dynamically assigned, no duplicates (Emily & Ed uses amily.jpg, Rex uses rex.jpg)
        for gen_name, filename_info in generator_image_map.items():
            if gen_name == 'Emily & Ed':
                # Special case: amily.jpg is in root directory
                # Try multiple case variations
                possible_filenames = ['amily.jpg', 'Amily.jpg', 'amily.JPG', 'Amily.JPG']
                found = False
                for fn in possible_filenames:
                    test_path = os.path.join(root_dir, fn)
                    if os.path.exists(test_path):
                        image_path = test_path
                        found = True
                        break
                if found:
                    try:
                        # Easter egg: replace with missing texture cropped to original dimensions
                        if self.easter_egg_missing_textures:
                            # Load original to get dimensions
                            original_img = pygame.image.load(image_path)
                            orig_width, orig_height = original_img.get_size()
                            # Crop missing texture to exact original dimensions
                            missing_tex = self.crop_missing_texture(orig_width, orig_height)
                            if missing_tex:
                                # Scale to display size after cropping
                                self.images[gen_name] = pygame.transform.smoothscale(missing_tex, (display_size, display_size))
                            else:
                                img = pygame.image.load(image_path)
                                self.images[gen_name] = pygame.transform.smoothscale(img, (display_size, display_size))
                        else:
                            img = pygame.image.load(image_path)
                            self.images[gen_name] = pygame.transform.smoothscale(img, (display_size, display_size))
                        print(f"Loaded generator image: {gen_name} -> amily.jpg")
                    except Exception as e:
                        print(f"Error loading {image_path}: {e}")
                else:
                    print(f"WARNING: Emily & Ed image not found in root directory")
                    # Use missing texture as fallback (16x16 if no original)
                    missing_tex = self.crop_missing_texture(16, 16)
                    if missing_tex:
                        # Scale to display size
                        self.images[gen_name] = pygame.transform.smoothscale(missing_tex, (display_size, display_size))
            elif gen_name == 'Rex':
                # Special case: Rex uses rex.jpeg (or rex.jpg)
                rex_paths = [
                    os.path.join(images_dir, 'rex.jpeg'),
                    os.path.join(images_dir, 'rex.JPEG'),
                    os.path.join(images_dir, 'rex.jpg'),
                    os.path.join(images_dir, 'rex.JPG'),
                    os.path.join(root_dir, 'rex.jpeg'),
                    os.path.join(root_dir, 'rex.JPEG'),
                    os.path.join(root_dir, 'rex.jpg'),
                    os.path.join(root_dir, 'rex.JPG')
                ]
                found = False
                for path in rex_paths:
                    if os.path.exists(path):
                        try:
                            # Easter egg: replace with missing texture cropped to original dimensions
                            if self.easter_egg_missing_textures:
                                # Load original to get dimensions
                                original_img = pygame.image.load(path)
                                orig_width, orig_height = original_img.get_size()
                                # Crop missing texture to exact original dimensions
                                missing_tex = self.crop_missing_texture(orig_width, orig_height)
                                if missing_tex:
                                    # Scale to display size after cropping
                                    self.images[gen_name] = pygame.transform.smoothscale(missing_tex, (display_size, display_size))
                                    found = True
                                    break
                            img = pygame.image.load(path)
                            self.images[gen_name] = pygame.transform.smoothscale(img, (display_size, display_size))
                            print(f"Loaded generator image: {gen_name} -> {os.path.basename(path)}")
                            found = True
                            break
                        except Exception as e:
                            print(f"Error loading Rex image {path}: {e}")
                if not found:
                    print(f"WARNING: Rex image (rex.jpeg or rex.jpg) not found")
                    # Use missing texture as fallback (16x16 if no original)
                    missing_tex = self.crop_missing_texture(16, 16)
                    if missing_tex:
                        # Scale to display size
                        self.images[gen_name] = pygame.transform.smoothscale(missing_tex, (display_size, display_size))
            elif filename_info is None:
                print(f"WARNING: No image available for {gen_name}")
                # Use missing texture as fallback
                missing_tex = self.get_missing_texture(display_size)
                if missing_tex:
                    self.images[gen_name] = missing_tex
            else:
                # Check if filename_info is a tuple (folder, filename) for memes, or just a string for images folder
                if isinstance(filename_info, tuple):
                    folder, filename = filename_info
                    if folder == 'memes':
                        # Load from memes folder
                        image_path = os.path.join(root_dir, 'memes', filename)
                    else:
                        # Load from specified folder
                        image_path = os.path.join(root_dir, folder, filename)
                else:
                    # Legacy: just filename, load from images folder
                    filename = filename_info
                    image_path = os.path.join(images_dir, filename)
                
                if os.path.exists(image_path):
                    try:
                        # Easter egg: replace all images with missing texture cropped to original dimensions
                        if self.easter_egg_missing_textures:
                            # Load original to get dimensions
                            original_img = pygame.image.load(image_path)
                            orig_width, orig_height = original_img.get_size()
                            # Crop missing texture to exact original dimensions
                            missing_tex = self.crop_missing_texture(orig_width, orig_height)
                            if missing_tex:
                                # Scale to display size after cropping
                                self.images[gen_name] = pygame.transform.smoothscale(missing_tex, (display_size, display_size))
                            else:
                                img = pygame.image.load(image_path)
                                self.images[gen_name] = pygame.transform.smoothscale(img, (display_size, display_size))
                        else:
                            img = pygame.image.load(image_path)
                            self.images[gen_name] = pygame.transform.smoothscale(img, (display_size, display_size))
                        print(f"Loaded generator image: {gen_name} -> {filename}")
                    except Exception as e:
                        print(f"Error loading {image_path}: {e}")
                else:
                    print(f"WARNING: Image file not found: {filename} for {gen_name} in images/ folder")
                    # Use missing texture as fallback (16x16 if no original)
                    missing_tex = self.crop_missing_texture(16, 16)
                    if missing_tex:
                        # Scale to display size
                        self.images[gen_name] = pygame.transform.smoothscale(missing_tex, (display_size, display_size))
        
        # Load background image with transparent shop area
        # Easter egg: replace with missing texture cropped to original dimensions
        bg_image_path = os.path.join(root_dir, 'background.png')
        if os.path.exists(bg_image_path):
            try:
                if self.easter_egg_missing_textures and self.missing_texture_image:
                    # Load original to get dimensions
                    original_img = pygame.image.load(bg_image_path).convert_alpha()
                    orig_width, orig_height = original_img.get_size()
                    # Crop missing texture to exact original dimensions
                    self.background_image = self.crop_missing_texture(orig_width, orig_height)
                    print(f"Loaded background image (easter egg): missing texture cropped to {orig_width}x{orig_height}")
                else:
                    self.background_image = pygame.image.load(bg_image_path).convert_alpha()
                    print(f"Loaded background image: {bg_image_path}")
            except Exception as e:
                print(f"Error loading background image {bg_image_path}: {e}")
                self.background_image = None
        else:
            print(f"WARNING: Background image not found: background.png")
            self.background_image = None
        
        # Load shop background image (snaketummy.png)
        # Easter egg: replace with missing texture cropped to original dimensions
        shop_bg_paths = [
            os.path.join(root_dir, 'snaketummy.png'),
            os.path.join(root_dir, 'snaketummy.PNG'),
            os.path.join(images_dir, 'snaketummy.png'),
            os.path.join(images_dir, 'snaketummy.PNG')
        ]
        for path in shop_bg_paths:
            if os.path.exists(path):
                try:
                    if self.easter_egg_missing_textures and self.missing_texture_image:
                        # Load original to get dimensions
                        original_img = pygame.image.load(path).convert_alpha()
                        orig_width, orig_height = original_img.get_size()
                        # Crop missing texture to exact original dimensions
                        self.shop_background_image = self.crop_missing_texture(orig_width, orig_height)
                        print(f"Loaded shop background image (easter egg): missing texture cropped to {orig_width}x{orig_height}")
                    else:
                        self.shop_background_image = pygame.image.load(path).convert_alpha()
                        print(f"Loaded shop background image: {path}")
                    break
                except Exception as e:
                    print(f"Error loading shop background image {path}: {e}")
        
        # Cache for scaled shop background
        self.scaled_shop_bg = None
        self.cached_shop_bg_size = None
        
        # Missing texture already loaded earlier (needed for easter egg)
        
        # Cache for scaled background
        self.scaled_background = None
        self.cached_bg_size = None
        
        # Load locked achievement image
        # Easter egg: replace with missing texture cropped to original dimensions
        locked_paths = [
            os.path.join(root_dir, 'locked.png'),
            os.path.join(root_dir, 'locked.PNG'),
            os.path.join(images_dir, 'locked.png'),
            os.path.join(images_dir, 'locked.PNG')
        ]
        for path in locked_paths:
            if os.path.exists(path):
                try:
                    if self.easter_egg_missing_textures and self.missing_texture_image:
                        # Load original to get dimensions
                        original_img = pygame.image.load(path).convert_alpha()
                        orig_width, orig_height = original_img.get_size()
                        # Crop missing texture to exact original dimensions
                        self.locked_achievement_image = self.crop_missing_texture(orig_width, orig_height)
                        print(f"Loaded locked achievement image (easter egg): missing texture cropped to {orig_width}x{orig_height}")
                    else:
                        self.locked_achievement_image = pygame.image.load(path).convert_alpha()
                        print(f"Loaded locked achievement image: {path}")
                    break
                except Exception as e:
                    print(f"Error loading locked achievement image {path}: {e}")
        
        # Load tutorial bot talking sprite sheet
        talking_paths = [
            os.path.join(images_dir, 'talking_spritesheet.png'),
            os.path.join(root_dir, 'talking_spritesheet.png'),
            os.path.join(images_dir, 'talking_spritesheet.PNG'),
            os.path.join(root_dir, 'talking_spritesheet.PNG')
        ]
        for path in talking_paths:
            if os.path.exists(path):
                try:
                    sprite_sheet = pygame.image.load(path).convert_alpha()
                    # Extract frames from sprite sheet (45 frames, each 450x405)
                    frame_width = 450
                    frame_height = 405
                    num_frames = 45
                    
                    # Easter egg: replace tutorial bot frames with missing texture cropped to original dimensions
                    if self.easter_egg_missing_textures and self.missing_texture_image:
                        # Crop missing texture to exact frame dimensions
                        missing_frame = self.crop_missing_texture(frame_width, frame_height)
                        if missing_frame:
                            for i in range(num_frames):
                                self.tutorial_bot_talking_frames.append(missing_frame)
                        else:
                            for i in range(num_frames):
                                frame_surface = pygame.Surface((frame_width, frame_height), pygame.SRCALPHA)
                                frame_surface.blit(sprite_sheet, (0, 0), (i * frame_width, 0, frame_width, frame_height))
                                self.tutorial_bot_talking_frames.append(frame_surface)
                    else:
                        for i in range(num_frames):
                            frame_surface = pygame.Surface((frame_width, frame_height), pygame.SRCALPHA)
                            frame_surface.blit(sprite_sheet, (0, 0), (i * frame_width, 0, frame_width, frame_height))
                            self.tutorial_bot_talking_frames.append(frame_surface)
                    
                    print(f"Loaded talking sprite sheet: {path} ({num_frames} frames)")
                    break
                except Exception as e:
                    print(f"Error loading talking sprite sheet {path}: {e}")
        
        # Load tutorial bot nottalking sprite sheet
        nottalking_paths = [
            os.path.join(images_dir, 'nottalking_spritesheet.png'),
            os.path.join(root_dir, 'nottalking_spritesheet.png'),
            os.path.join(images_dir, 'nottalking_spritesheet.PNG'),
            os.path.join(root_dir, 'nottalking_spritesheet.PNG')
        ]
        for path in nottalking_paths:
            if os.path.exists(path):
                try:
                    sprite_sheet = pygame.image.load(path).convert_alpha()
                    # Extract frames from sprite sheet (25 frames, each 450x405)
                    frame_width = 450
                    frame_height = 405
                    num_frames = 25
                    
                    # Easter egg: replace tutorial bot frames with missing texture cropped to original dimensions
                    if self.easter_egg_missing_textures and self.missing_texture_image:
                        # Crop missing texture to exact frame dimensions
                        missing_frame = self.crop_missing_texture(frame_width, frame_height)
                        if missing_frame:
                            for i in range(num_frames):
                                self.tutorial_bot_nottalking_frames.append(missing_frame)
                        else:
                            for i in range(num_frames):
                                frame_surface = pygame.Surface((frame_width, frame_height), pygame.SRCALPHA)
                                frame_surface.blit(sprite_sheet, (0, 0), (i * frame_width, 0, frame_width, frame_height))
                                self.tutorial_bot_nottalking_frames.append(frame_surface)
                    else:
                        for i in range(num_frames):
                            frame_surface = pygame.Surface((frame_width, frame_height), pygame.SRCALPHA)
                            frame_surface.blit(sprite_sheet, (0, 0), (i * frame_width, 0, frame_width, frame_height))
                            self.tutorial_bot_nottalking_frames.append(frame_surface)
                    
                    print(f"Loaded nottalking sprite sheet: {path} ({num_frames} frames)")
                    break
                except Exception as e:
                    print(f"Error loading nottalking sprite sheet {path}: {e}")
        
        # Load pointer sprite sheet
        pointer_paths = [
            os.path.join(images_dir, 'pointer.png'),
            os.path.join(root_dir, 'pointer.png'),
            os.path.join(images_dir, 'pointer.PNG'),
            os.path.join(root_dir, 'pointer.PNG')
        ]
        for path in pointer_paths:
            if os.path.exists(path):
                try:
                    sprite_sheet = pygame.image.load(path).convert_alpha()
                    # Extract frames from sprite sheet (2 frames, each 325x326)
                    frame_width = 325
                    frame_height = 326
                    num_frames = 2
                    
                    # Easter egg: replace pointer frames with missing texture cropped to original dimensions
                    if self.easter_egg_missing_textures and self.missing_texture_image:
                        # Crop missing texture to exact frame dimensions
                        missing_frame = self.crop_missing_texture(frame_width, frame_height)
                        if missing_frame:
                            for i in range(num_frames):
                                self.pointer_frames.append(missing_frame)
                        else:
                            for i in range(num_frames):
                                frame_surface = pygame.Surface((frame_width, frame_height), pygame.SRCALPHA)
                                frame_surface.blit(sprite_sheet, (0, 0), (i * frame_width, 0, frame_width, frame_height))
                                self.pointer_frames.append(frame_surface)
                    else:
                        for i in range(num_frames):
                            frame_surface = pygame.Surface((frame_width, frame_height), pygame.SRCALPHA)
                            frame_surface.blit(sprite_sheet, (0, 0), (i * frame_width, 0, frame_width, frame_height))
                            self.pointer_frames.append(frame_surface)
                    
                    print(f"Loaded pointer sprite sheet: {path} ({num_frames} frames)")
                    break
                except Exception as e:
                    print(f"Error loading pointer sprite sheet {path}: {e}")
        
        # Load speech bubble image
        self.speech_bubble_image = None
        bubble_paths = [
            os.path.join(images_dir, 'bubble.png'),
            os.path.join(root_dir, 'bubble.png'),
            os.path.join(images_dir, 'bubble.PNG'),
            os.path.join(root_dir, 'bubble.PNG')
        ]
        for path in bubble_paths:
            if os.path.exists(path):
                try:
                    # Easter egg: replace speech bubble with missing texture cropped to original dimensions
                    if self.easter_egg_missing_textures and self.missing_texture_image:
                        # Load original to get dimensions
                        original_img = pygame.image.load(path).convert_alpha()
                        orig_width, orig_height = original_img.get_size()
                        # Crop missing texture to exact original dimensions
                        self.speech_bubble_image = self.crop_missing_texture(orig_width, orig_height)
                        print(f"Loaded speech bubble image (easter egg): missing texture cropped to {orig_width}x{orig_height}")
                    else:
                        self.speech_bubble_image = pygame.image.load(path).convert_alpha()
                        print(f"Loaded speech bubble image: {path}")
                    break
                except Exception as e:
                    print(f"Error loading speech bubble image {path}: {e}")
        
        # Load special images: Lavender Hognose and YouTube Channel
        # Try to load lavender hognose image (now using purple hognose.jpg)
        lavender_hognose_paths = [
            os.path.join(images_dir, 'purple hognose.jpg'),
            os.path.join(images_dir, 'purple hognose.JPG'),
            os.path.join(root_dir, 'purple hognose.jpg'),
            os.path.join(root_dir, 'purple hognose.JPG'),
            os.path.join(root_dir, 'purpue snek :3.jpg'),
            os.path.join(root_dir, 'purpue snek :3.JPG'),
            os.path.join(root_dir, 'purple snek :3.jpg'),
            os.path.join(images_dir, 'purpue snek :3.jpg'),
            os.path.join(images_dir, 'purpue snek :3.JPG'),
            os.path.join(images_dir, 'purple snek :3.jpg')
        ]
        for path in lavender_hognose_paths:
            if os.path.exists(path):
                try:
                    # Easter egg: replace with missing texture cropped to original dimensions
                    if self.easter_egg_missing_textures and self.missing_texture_image:
                        # Load original to get dimensions
                        original_img = pygame.image.load(path)
                        orig_width, orig_height = original_img.get_size()
                        # Crop missing texture to exact original dimensions
                        missing_tex = self.crop_missing_texture(orig_width, orig_height)
                        if missing_tex:
                            # Scale to display size after cropping
                            self.lavender_hognose_image = pygame.transform.smoothscale(missing_tex, (80, 80))
                        else:
                            img = pygame.image.load(path)
                            self.lavender_hognose_image = pygame.transform.smoothscale(img, (80, 80))
                        print(f"Loaded Lavender Hognose image (easter egg): missing texture cropped to {orig_width}x{orig_height}")
                    else:
                        img = pygame.image.load(path)
                        self.lavender_hognose_image = pygame.transform.smoothscale(img, (80, 80))
                        print(f"Loaded Lavender Hognose image: {path}")
                    break
                except Exception as e:
                    print(f"Error loading lavender hognose image {path}: {e}")

        # Load thief snake image
        thief_snake_paths = [
            os.path.join(images_dir, 'FeArMeEeEeEeEeEe.jpg'),
            os.path.join(images_dir, 'FeArMeEeEeEeEeEe.JPG'),
            os.path.join(root_dir, 'FeArMeEeEeEeEeEe.jpg'),
            os.path.join(root_dir, 'FeArMeEeEeEeEeEe.JPG')
        ]
        for path in thief_snake_paths:
            if os.path.exists(path):
                try:
                    # Easter egg: replace with missing texture cropped to original dimensions
                    if self.easter_egg_missing_textures and self.missing_texture_image:
                        # Load original to get dimensions
                        original_img = pygame.image.load(path)
                        orig_width, orig_height = original_img.get_size()
                        # Crop missing texture to exact original dimensions
                        missing_tex = self.crop_missing_texture(orig_width, orig_height)
                        if missing_tex:
                            # Scale to display size after cropping
                            self.thief_snake_image = pygame.transform.smoothscale(missing_tex, (80, 80))
                        else:
                            img = pygame.image.load(path)
                            self.thief_snake_image = pygame.transform.smoothscale(img, (80, 80))
                        print(f"Loaded Thief Snake image (easter egg): missing texture cropped to {orig_width}x{orig_height}")
                    else:
                        img = pygame.image.load(path)
                        self.thief_snake_image = pygame.transform.smoothscale(img, (80, 80))
                        print(f"Loaded Thief Snake image: {path}")
                    break
                except Exception as e:
                    print(f"Error loading thief snake image {path}: {e}")

        # Load YouTube channel image for upgrade #30
        # Easter egg: replace with missing texture cropped to original dimensions
        youtube_paths = [
            os.path.join(root_dir, 'start a youtube channel.jpg'),
            os.path.join(root_dir, 'start a youtube channel.JPG'),
            os.path.join(images_dir, 'start a youtube channel.jpg'),
            os.path.join(images_dir, 'start a youtube channel.JPG')
        ]
        for path in youtube_paths:
            if os.path.exists(path):
                try:
                    if self.easter_egg_missing_textures and self.missing_texture_image:
                        # Load original to get dimensions
                        original_img = pygame.image.load(path)
                        orig_width, orig_height = original_img.get_size()
                        # Crop missing texture to exact original dimensions
                        missing_tex = self.crop_missing_texture(orig_width, orig_height)
                        if missing_tex:
                            # Scale to display size after cropping
                            self.images['START A SNAKE YOUTUBE CHANNEL'] = pygame.transform.smoothscale(missing_tex, (display_size, display_size))
                            print(f"Loaded YouTube Channel image (easter egg): missing texture")
                        else:
                            img = pygame.image.load(path)
                            self.images['START A SNAKE YOUTUBE CHANNEL'] = pygame.transform.smoothscale(img, (display_size, display_size))
                    else:
                        img = pygame.image.load(path)
                        self.images['START A SNAKE YOUTUBE CHANNEL'] = pygame.transform.smoothscale(img, (display_size, display_size))
                        print(f"Loaded YouTube Channel image: {path}")
                    break
                except Exception as e:
                    print(f"Error loading YouTube channel image {path}: {e}")
        
        # Load achievement image (education.png)
        # Easter egg: replace with missing texture cropped to original dimensions
        education_paths = [
            os.path.join(root_dir, 'education.png'),
            os.path.join(root_dir, 'education.PNG'),
            os.path.join(images_dir, 'education.png'),
            os.path.join(images_dir, 'education.PNG')
        ]
        for path in education_paths:
            if os.path.exists(path):
                try:
                    if self.easter_egg_missing_textures and self.missing_texture_image:
                        # Load original to get dimensions
                        original_img = pygame.image.load(path)
                        orig_width, orig_height = original_img.get_size()
                        # Crop missing texture to exact original dimensions
                        missing_tex = self.crop_missing_texture(orig_width, orig_height)
                        if missing_tex:
                            # Scale to display size after cropping
                            self.achievement_image = pygame.transform.smoothscale(missing_tex, (200, 200))
                            print(f"Loaded achievement image (easter egg): missing texture cropped to {orig_width}x{orig_height}")
                        else:
                            img = pygame.image.load(path)
                            self.achievement_image = pygame.transform.smoothscale(img, (200, 200))
                    else:
                        img = pygame.image.load(path)
                        # Scale to a reasonable size for achievement display (200x200)
                        self.achievement_image = pygame.transform.smoothscale(img, (200, 200))
                        print(f"Loaded achievement image: {path}")
                    break
                except Exception as e:
                    print(f"Error loading achievement image {path}: {e}")
        
        # Load snakes money icon (Snakes.png)
        # Easter egg: replace with missing texture cropped to original dimensions
        snakes_icon_paths = [
            os.path.join(images_dir, 'snakes.png'),
            os.path.join(images_dir, 'Snakes.png'),
            os.path.join(root_dir, 'snakes.png'),
            os.path.join(root_dir, 'Snakes.png'),
            os.path.join(images_dir, 'snakes.PNG'),
            os.path.join(root_dir, 'snakes.PNG')
        ]
        for path in snakes_icon_paths:
            if os.path.exists(path):
                try:
                    if self.easter_egg_missing_textures and self.missing_texture_image:
                        # Load original to get dimensions
                        original_img = pygame.image.load(path).convert_alpha()
                        orig_width, orig_height = original_img.get_size()
                        # Crop missing texture to exact original dimensions
                        missing_tex = self.crop_missing_texture(orig_width, orig_height)
                        if missing_tex:
                            # Scale to icon size after cropping
                            self.snakes_money_icon = pygame.transform.smoothscale(missing_tex, (32, 32))
                            print(f"Loaded snakes money icon (easter egg): missing texture cropped to {orig_width}x{orig_height}")
                        else:
                            img = pygame.image.load(path).convert_alpha()
                            self.snakes_money_icon = pygame.transform.smoothscale(img, (32, 32))
                    else:
                        # Load PNG directly with pygame
                        img = pygame.image.load(path).convert_alpha()
                        # Scale to icon size (32x32 for stats panel)
                        self.snakes_money_icon = pygame.transform.smoothscale(img, (32, 32))
                        print(f"Loaded snakes money icon: {path}")
                    break
                except Exception as e:
                    print(f"Error loading snakes money icon {path}: {e}")

        # Load TimesNewBastard font for dedicated player achievement
        font_paths = [
            os.path.join(images_dir, 'TimesNewBastard-Regular.otf'),
            os.path.join(root_dir, 'TimesNewBastard-Regular.otf')
        ]
        for path in font_paths:
            if os.path.exists(path):
                try:
                    self.dedicated_player_font = pygame.font.Font(path, 24)  # Size 24 for achievement text
                    print(f"Loaded TimesNewBastard font: {path}")
                    break
                except Exception as e:
                    print(f"Error loading TimesNewBastard font {path}: {e}")

        # Load timesnewbastard.jpg for dedicated player achievement
        # Easter egg: replace with missing texture cropped to original dimensions
        self.dedicated_player_image = None
        dedicated_image_paths = [
            os.path.join(images_dir, 'timesnewbastard.jpg'),
            os.path.join(root_dir, 'timesnewbastard.jpg')
        ]
        for path in dedicated_image_paths:
            if os.path.exists(path):
                try:
                    if self.easter_egg_missing_textures and self.missing_texture_image:
                        # Load original to get dimensions
                        original_img = pygame.image.load(path).convert_alpha()
                        orig_width, orig_height = original_img.get_size()
                        # Crop missing texture to exact original dimensions
                        missing_tex = self.crop_missing_texture(orig_width, orig_height)
                        if missing_tex:
                            # Scale to display size after cropping
                            self.dedicated_player_image = pygame.transform.smoothscale(missing_tex, (200, 200))
                            print(f"Loaded dedicated player image (easter egg): missing texture cropped to {orig_width}x{orig_height}")
                        else:
                            img = pygame.image.load(path).convert_alpha()
                            self.dedicated_player_image = pygame.transform.smoothscale(img, (200, 200))
                    else:
                        img = pygame.image.load(path).convert_alpha()
                        self.dedicated_player_image = pygame.transform.smoothscale(img, (200, 200))
                        print(f"Loaded dedicated player image: {path}")
                    break
                except Exception as e:
                    print(f"Error loading dedicated player image {path}: {e}")
        
        # Auto-start tutorial if this is the first time playing
        # Check if player has never clicked (first time) or has no progress
        if (self.state.get('total_clicks', 0) == 0 and 
            self.state.get('snakes', 0) == 0 and 
            not any(u.get('purchased', False) for u in self.state.get('upgrades', [])) and
            not any(g.get('count', 0) > 0 for g in self.state.get('generators', []))):
            # Small delay to ensure everything is initialized, then start tutorial
            # We'll start it in the first update cycle instead
            self.auto_start_tutorial = True
        else:
            self.auto_start_tutorial = False
        
    def get_missing_texture(self, size):
        """Get the missing texture image cropped to the specified size (defaults to 16x16 if original doesn't exist)"""
        if self.missing_texture_image:
            # Always crop to exact dimensions (pixel-for-pixel)
            return self.crop_missing_texture(size, size)
        return None
    
    def crop_missing_texture(self, width, height):
        """Crop missing texture to exact dimensions (pixel-for-pixel match)"""
        if not self.missing_texture_image:
            return None
        # Get original missing texture dimensions
        mt_width, mt_height = self.missing_texture_image.get_size()
        # Crop from top-left corner to match exact dimensions
        cropped = pygame.Surface((width, height), pygame.SRCALPHA)
        # Tile the missing texture if needed, then crop
        for y in range(0, height, mt_height):
            for x in range(0, width, mt_width):
                # Calculate how much to blit (might be partial at edges)
                blit_width = min(mt_width, width - x)
                blit_height = min(mt_height, height - y)
                if blit_width > 0 and blit_height > 0:
                    # Create a sub-surface of the missing texture if needed
                    if blit_width == mt_width and blit_height == mt_height:
                        cropped.blit(self.missing_texture_image, (x, y))
                    else:
                        # Partial tile - crop the missing texture
                        partial = pygame.Surface((blit_width, blit_height), pygame.SRCALPHA)
                        partial.blit(self.missing_texture_image, (0, 0), (0, 0, blit_width, blit_height))
                        cropped.blit(partial, (x, y))
        return cropped
    
    def load_achievement_image(self, achievement_name, size):
        """Load achievement-specific image by name"""
        import os
        root_dir = os.path.dirname(os.path.abspath(__file__))
        images_dir = os.path.join(root_dir, 'images')
        
        # Sanitize achievement name for filename
        safe_name = achievement_name.lower().replace(' ', '_').replace('!', '').replace(':', '').replace(',', '')
        
        # Try various extensions and locations
        paths = [
            os.path.join(images_dir, f"{safe_name}.png"),
            os.path.join(images_dir, f"{safe_name}.jpg"),
            os.path.join(images_dir, f"{safe_name}.jpeg"),
            os.path.join(root_dir, f"{safe_name}.png"),
            os.path.join(root_dir, f"{safe_name}.jpg"),
            os.path.join(root_dir, f"{safe_name}.jpeg"),
        ]
        
        for path in paths:
            if os.path.exists(path):
                try:
                    img = pygame.image.load(path).convert_alpha()
                    return pygame.transform.smoothscale(img, (size, size))
                except Exception as e:
                    print(f"Error loading achievement image {path}: {e}")
        
        return None
    
    def load_state(self):
        if os.path.exists(self.state_file):
            try:
                with open(self.state_file, 'r') as f:
                    return json.load(f)
            except:
                pass
        return {
            'snakes': 0,
            'snakes_per_click': 1,
            'snakes_per_second': 0,
            'total_clicks': 0,
            'lavender_hognose_clicked': False,
            'achievements': {
                'you started an education program about reptiles': False,
                'super rare morph!': False,
                'oops we lost the code': False,
                'first click': False,
                'first snake': False,
                'snake collector': False,
                'snake hoarder': False,
                'snake millionaire': False,
                'snake billionaire': False,
                'generator master': False,
                'production line': False,
                'first upgrade': False,
                'upgrade enthusiast': False,
                'upgrade master': False,
                'speed demon': False,
                'click master': False,
                'passive income': False,
                'snake empire': False,
                'youtube star': False,
                'rex owner': False,
                '100 snakes per second': False,
                '1000 snakes per second': False,
                '10000 snakes per second': False,
                '100000 snakes per second': False,
                '1 million snakes per second': False,
                '10 generators': False,
                '50 generators': False,
                '100 generators': False,
                'all upgrades': False,
                'snake whisperer': False,
                'dedicated player': False
            }
        }
    
    def save_state(self):
        # Recalculate snakes_per_second before saving to ensure it's up to date
        self.state['snakes_per_second'] = self.calculate_sps()
        try:
            with open(self.state_file, 'w') as f:
                json.dump(self.state, f)
            # Show save confirmation message
            self.save_message = {
                'text': 'Game Saved!',
                'time': pygame.time.get_ticks(),
                'duration': 3000  # 3 seconds for better visibility
            }
        except Exception as e:
            # Show error message if save fails
            self.save_message = {
                'text': f'Save Failed: {str(e)}',
                'time': pygame.time.get_ticks(),
                'duration': 2000  # 2 seconds
            }
            print(f"Error saving game: {e}")
    
    def format_number(self, num):
        if num < 1000:
            return str(int(num))
        else:
            # Use a, b, c, d... notation where each letter = 1000^N
            # a = 1000, b = 1,000,000, c = 1,000,000,000, etc.
            suffix = ''
            divisor = 1000.0
            letter = ord('a')
            
            while num >= divisor * 1000:
                divisor *= 1000
                letter += 1
                if letter > ord('z'):
                    # If we exceed z, wrap around or use a different system
                    # For now, just use the last letter
                    letter = ord('z')
                    break
            
            value = num / divisor
            if value >= 100:
                # Show as integer if >= 100
                return f"{int(value)}{chr(letter)}"
            else:
                # Show with 2 decimal places if < 100
                return f"{value:.2f}{chr(letter)}"
    
    def format_production(self, num):
        if num < 1:
            return f"{num:.1f}"
        elif num < 1000:
            return str(int(num))
        else:
            # Use a, b, c, d... notation where each letter = 1000^N
            suffix = ''
            divisor = 1000.0
            letter = ord('a')
            
            while num >= divisor * 1000:
                divisor *= 1000
                letter += 1
                if letter > ord('z'):
                    letter = ord('z')
                    break
            
            value = num / divisor
            if value >= 100:
                return f"{int(value)}{chr(letter)}"
            else:
                return f"{value:.2f}{chr(letter)}"
    
    def get_upgrade_multiplier(self):
        """Calculate the total multiplier from all purchased upgrades
        Effects are added together first, then multiplied (e.g., 2x + 2.5x = 4.5x total)"""
        total_effect = 0.0
        for upgrade in self.state['upgrades']:
            if upgrade.get('purchased', False):
                # Add the effect (subtract 1 because effect is a multiplier, e.g., 2x = +1.0)
                total_effect += (upgrade['effect'] - 1.0)
        # Return 1.0 + total_effect (e.g., 1.0 + 3.5 = 4.5x)
        return 1.0 + total_effect
    
    def calculate_sps(self):
        total = 0
        for gen in self.state['generators']:
            total += gen['count'] * gen['base_production']
        
        # Apply all purchased upgrade effects (upgrades multiply generator production too!)
        upgrade_multiplier = self.get_upgrade_multiplier()
        
        # Apply temporary multiplier if active (from lavender hognose)
        temp_multiplier = self.state.get('production_multiplier', 1.0)
        
        return total * upgrade_multiplier * temp_multiplier
    
    def get_max_scroll(self, tab):
        """Calculate maximum scroll amount for a tab"""
        # Use scaled item height to match what's used in drawing
        scale_y = HEIGHT / 1000.0
        item_height = int(110 * scale_y)
        shop_visible_height = self.shop_rect.height - int(20 * scale_y)  # Height of shop area minus padding
        shop_top_padding = int(10 * scale_y)  # Padding at top of shop
        
        if tab == 'upgrades':
            total_items = len(self.state['upgrades'])
        elif tab == 'generators':
            total_items = len(self.state['generators'])
        elif tab == 'achievements':
            # Count total achievements (2 per row, so calculate rows)
            achievements_list = [
                'first click', 'first snake', 'snake collector', 'snake hoarder', 'snake millionaire',
                'snake billionaire', 'generator master', 'production line',
                'first upgrade', 'upgrade enthusiast', 'upgrade master', 'speed demon', 'click master',
                'passive income', 'snake empire', 'you started an education program about reptiles',
                'youtube star', 'rex owner', '100 snakes per second', '1000 snakes per second',
                '10000 snakes per second', '100000 snakes per second', '1 million snakes per second',
                '10 generators', '50 generators', '100 generators', 'all upgrades', 'snake whisperer',
                'super rare morph!', 'oops we lost the code', 'dedicated player'
            ]
            # With 2 per row, calculate number of rows
            achievements_per_row = 2
            num_rows = (len(achievements_list) + achievements_per_row - 1) // achievements_per_row  # Ceiling division
            total_items = num_rows  # Use rows for scroll calculation
        else:
            total_items = 0
        
        total_height = total_items * item_height
        # Ensure we can scroll enough to see the last item fully
        # When scrolled to max, the last item should be at the bottom of the visible area
        # Last item position = (total_items - 1) * item_height
        # We need to scroll so that last item's bottom is at shop_bottom
        last_item_bottom = (total_items - 1) * item_height + item_height
        shop_bottom = self.shop_rect.y + self.shop_rect.height - int(10 * scale_y)
        max_scroll = max(0, last_item_bottom - shop_bottom + int(10 * scale_y))
        return max_scroll
    
    def get_generator_cost(self, generator):
        return int(generator['base_cost'] * (1.15 ** generator['count']))
    
    def click_egg(self):
        self.state['snakes'] += self.state['snakes_per_click']
        self.egg_click_animation = 15
        # Track total clicks
        if 'total_clicks' not in self.state:
            self.state['total_clicks'] = 0
        self.state['total_clicks'] += 1
        # Track tutorial clicks
        if self.tutorial_active:
            self.tutorial_clicks += 1
        self.save_state()
        # Check achievements after click
        self.check_achievements()
    
    def buy_upgrade(self, index):
        if 0 <= index < len(self.state['upgrades']):
            upgrade = self.state['upgrades'][index]
            if upgrade['purchased']:
                return False
            
            if self.state['snakes'] >= upgrade['cost']:
                self.state['snakes'] -= upgrade['cost']
                upgrade['purchased'] = True
                # Recalculate snakes_per_click from base (1) with all upgrades added together
                base_click = 1
                total_effect = 0.0
                for u in self.state['upgrades']:
                    if u.get('purchased', False):
                        total_effect += (u['effect'] - 1.0)
                self.state['snakes_per_click'] = base_click * (1.0 + total_effect)
                self.save_state()
                # Check for YouTube star achievement
                if upgrade['name'] == 'START A SNAKE YOUTUBE CHANNEL':
                    self.trigger_achievement('youtube star')
                # Check all upgrade-related achievements
                self.check_achievements()
                return True
        return False
    
    def buy_generator(self, index):
        if 0 <= index < len(self.state['generators']):
            generator = self.state['generators'][index]
            cost = self.get_generator_cost(generator)
            
            if self.state['snakes'] >= cost:
                # Check if this is the first Emily & Ed purchase
                is_first_emily_ed = (generator['name'] == 'Emily & Ed' and generator['count'] == 0)
                
                self.state['snakes'] -= cost
                generator['count'] += 1
                self.state['snakes_per_second'] = self.calculate_sps()
                
                # Trigger achievement if first Emily & Ed purchase
                if is_first_emily_ed:
                    self.trigger_achievement("you started an education program about reptiles")
                
                # Check for Rex owner achievement
                if generator['name'] == 'Rex' and generator['count'] == 1:
                    self.trigger_achievement('rex owner')
                
                self.save_state()
                # Check all generator-related achievements
                self.check_achievements()
                return True
        return False
    
    def start_tutorial(self):
        """Start the tutorial sequence - checks which tutorial to show"""
        if self.first_tutorial_completed:
            # Start UI navigation tutorial
            self.start_ui_tutorial()
        else:
            # Start first tutorial (getting started)
            self.start_first_tutorial()
    
    def start_first_tutorial(self):
        """Start the first tutorial sequence (getting started)"""
        self.tutorial_active = True
        self.tutorial_type = 'start'
        self.tutorial_step = 0
        self.tutorial_clicks = 0
        self.tutorial_message = None
        self.pointer_target = None
        self.tutorial_displayed_text = ""
        self.tutorial_full_text = ""
        self.tutorial_text_index = 0
        self.tutorial_text_timer = 0
        # Force spawn first lavender hognose when we reach that step
        self.tutorial_force_lavender_hognose = False
        self.tutorial_force_thief_snake = False
        self.tutorial_lavender_hognose_clicked = False
        self.tutorial_thief_snake_clicked = False
    
    def start_ui_tutorial(self):
        """Start the UI navigation tutorial"""
        self.tutorial_active = True
        self.tutorial_type = 'ui'
        self.tutorial_step = 0
        self.tutorial_message = None
        self.pointer_target = None
        self.tutorial_displayed_text = ""
        self.tutorial_full_text = ""
        self.tutorial_text_index = 0
        self.tutorial_text_timer = 0
    
    def update_tutorial(self, current_time):
        """Update tutorial progression based on game state"""
        if not self.tutorial_active:
            return
        
        # Route to appropriate tutorial update method
        if self.tutorial_type == 'ui':
            self.update_ui_tutorial(current_time)
        else:
            self.update_first_tutorial(current_time)
    
    def update_first_tutorial(self, current_time):
        """Update first tutorial progression (getting started)"""
        # Step 0: Click egg 10 times
        if self.tutorial_step == 0:
            if self.tutorial_clicks >= 10:
                self.tutorial_step = 1
                self.tutorial_message = "Great! Now you have enough snakes to buy your first upgrade. Click on the Upgrades tab."
                self.tutorial_full_text = self.tutorial_message
                self.tutorial_displayed_text = ""
                self.tutorial_text_index = 0
                self.tutorial_text_timer = current_time
                self.pointer_target = 'upgrades_tab'
            else:
                if not self.tutorial_message:
                    self.tutorial_message = f"Click the egg 10 times! ({self.tutorial_clicks}/10)"
                    self.tutorial_full_text = self.tutorial_message
                    self.tutorial_displayed_text = ""
                    self.tutorial_text_index = 0
                    self.tutorial_text_timer = current_time
                    self.pointer_target = 'egg'
                else:
                    # Update message with current click count
                    self.tutorial_message = f"Click the egg 10 times! ({self.tutorial_clicks}/10)"
                    self.tutorial_full_text = self.tutorial_message
        
        # Step 1: Switch to upgrades tab
        elif self.tutorial_step == 1:
            if self.current_tab == 'upgrades':
                self.tutorial_step = 2
                self.tutorial_message = "Perfect! Now buy the first upgrade 'Better Incubator' for 10 snakes."
                self.tutorial_full_text = self.tutorial_message
                self.tutorial_displayed_text = ""
                self.tutorial_text_index = 0
                self.tutorial_text_timer = current_time
                self.pointer_target = 'first_upgrade'
        
        # Step 2: Buy first upgrade
        elif self.tutorial_step == 2:
            first_upgrade = self.state['upgrades'][0] if len(self.state['upgrades']) > 0 else None
            if first_upgrade and first_upgrade.get('purchased', False):
                self.tutorial_step = 3
                self.tutorial_message = "Excellent! Now switch to the Generators tab to buy your first generator."
                self.tutorial_full_text = self.tutorial_message
                self.tutorial_displayed_text = ""
                self.tutorial_text_index = 0
                self.tutorial_text_timer = current_time
                self.pointer_target = 'generators_tab'
        
        # Step 3: Switch to generators tab
        elif self.tutorial_step == 3:
            if self.current_tab == 'generators':
                self.tutorial_step = 4
                # Force spawn lavender hognose
                self.tutorial_force_lavender_hognose = True
                self.tutorial_message = "Look! A special purple hognose appeared! Click it to get 15 snakes!"
                self.tutorial_full_text = self.tutorial_message
                self.tutorial_displayed_text = ""
                self.tutorial_text_index = 0
                self.tutorial_text_timer = current_time
                self.pointer_target = 'lavender_hognose'
        
        # Step 4: First part of lavender hognose section (waiting for click)
        elif self.tutorial_step == 4:
            if self.tutorial_lavender_hognose_clicked:
                self.tutorial_step = 5
                self.tutorial_message = "Amazing! The purple hognose gives you bonus snakes when clicked. They appear randomly during gameplay."
                self.tutorial_full_text = self.tutorial_message
                self.tutorial_displayed_text = ""
                self.tutorial_text_index = 0
                self.tutorial_text_timer = current_time
                self.pointer_target = None
        
        # Step 5: Second part of lavender hognose section (explanation)
        elif self.tutorial_step == 5:
            # Wait for text to finish, then move on
            if self.tutorial_text_index >= len(self.tutorial_full_text):
                # Check if enough time has passed after text finished
                if current_time - self.tutorial_text_timer > 2000:  # 2 seconds after text finishes
                    self.tutorial_step = 6
                    self.tutorial_message = "Now buy your first generator 'Emily & Ed' for 15 snakes."
                    self.tutorial_full_text = self.tutorial_message
                    self.tutorial_displayed_text = ""
                    self.tutorial_text_index = 0
                    self.tutorial_text_timer = current_time
                    self.pointer_target = 'first_generator'
        
        # Step 6: Buy first generator
        elif self.tutorial_step == 6:
            first_generator = self.state['generators'][0] if len(self.state['generators']) > 0 else None
            if first_generator and first_generator.get('count', 0) > 0:
                self.tutorial_step = 7
                self.tutorial_message = "Great! Generators produce snakes automatically. Now let's check out the Achievements tab."
                self.tutorial_full_text = self.tutorial_message
                self.tutorial_displayed_text = ""
                self.tutorial_text_index = 0
                self.tutorial_text_timer = current_time
                self.pointer_target = 'achievements_tab'
        
        # Step 7: Switch to achievements tab
        elif self.tutorial_step == 7:
            if self.current_tab == 'achievements':
                self.tutorial_step = 8
                self.tutorial_message = "Achievements track your progress and unlock special rewards. Keep playing to unlock them all!"
                self.tutorial_full_text = self.tutorial_message
                self.tutorial_displayed_text = ""
                self.tutorial_text_index = 0
                self.tutorial_text_timer = current_time
                self.pointer_target = None
        
        # Step 8: Achievements explanation (wait for text to finish)
        elif self.tutorial_step == 8:
            if self.tutorial_text_index >= len(self.tutorial_full_text):
                if current_time - self.tutorial_text_timer > 2000:  # 2 seconds after text finishes
                    self.tutorial_step = 9
                    # Force spawn thief snake
                    self.tutorial_force_thief_snake = True
                    self.tutorial_message = "Watch out! A thief snake appeared! Click it to shoo it away before it steals your snakes!"
                    self.tutorial_full_text = self.tutorial_message
                    self.tutorial_displayed_text = ""
                    self.tutorial_text_index = 0
                    self.tutorial_text_timer = current_time
                    self.pointer_target = 'thief_snake'
        
        # Step 9: Thief snake section (waiting for click)
        elif self.tutorial_step == 9:
            if self.tutorial_thief_snake_clicked:
                self.tutorial_step = 10
                self.tutorial_message = "Good job! Thief snakes will steal your snakes if you don't shoo them away. Keep an eye out for them!"
                self.tutorial_full_text = self.tutorial_message
                self.tutorial_displayed_text = ""
                self.tutorial_text_index = 0
                self.tutorial_text_timer = current_time
                self.pointer_target = None
        
        # Step 10: Tutorial complete
        elif self.tutorial_step == 10:
            if self.tutorial_text_index >= len(self.tutorial_full_text):
                if current_time - self.tutorial_text_timer > 2000:
                    self.tutorial_active = False
                    self.tutorial_message = None
                    self.pointer_target = None
                    self.first_tutorial_completed = True  # Mark first tutorial as completed
        
        # Update letter-by-letter text animation
        if self.tutorial_message and self.tutorial_full_text:
            if current_time - self.tutorial_text_timer >= 30:  # 30ms per letter
                if self.tutorial_text_index < len(self.tutorial_full_text):
                    self.tutorial_displayed_text = self.tutorial_full_text[:self.tutorial_text_index + 1]
                    self.tutorial_text_index += 1
                    self.tutorial_text_timer = current_time
    
    def update_ui_tutorial(self, current_time):
        """Update UI navigation tutorial progression"""
        # Step 0: Explain tabs
        if self.tutorial_step == 0:
            if not self.tutorial_message:
                self.tutorial_message = "Let's learn how to navigate the UI! There are three tabs at the top: Upgrades, Generators, and Achievements."
                self.tutorial_full_text = self.tutorial_message
                self.tutorial_displayed_text = ""
                self.tutorial_text_index = 0
                self.tutorial_text_timer = current_time
                self.pointer_target = 'upgrades_tab'
            elif self.tutorial_text_index >= len(self.tutorial_full_text):
                if current_time - self.tutorial_text_timer > 2000:
                    self.tutorial_step = 1
                    self.tutorial_message = "Click on each tab to switch between different sections. Try clicking the Upgrades tab now!"
                    self.tutorial_full_text = self.tutorial_message
                    self.tutorial_displayed_text = ""
                    self.tutorial_text_index = 0
                    self.tutorial_text_timer = current_time
                    self.pointer_target = 'upgrades_tab'
        
        # Step 1: Wait for upgrades tab click
        elif self.tutorial_step == 1:
            if self.current_tab == 'upgrades':
                self.tutorial_step = 2
                self.tutorial_message = "Great! Now try the Generators tab."
                self.tutorial_full_text = self.tutorial_message
                self.tutorial_displayed_text = ""
                self.tutorial_text_index = 0
                self.tutorial_text_timer = current_time
                self.pointer_target = 'generators_tab'
        
        # Step 2: Wait for generators tab click
        elif self.tutorial_step == 2:
            if self.current_tab == 'generators':
                self.tutorial_step = 3
                self.tutorial_message = "Perfect! Now try the Achievements tab."
                self.tutorial_full_text = self.tutorial_message
                self.tutorial_displayed_text = ""
                self.tutorial_text_index = 0
                self.tutorial_text_timer = current_time
                self.pointer_target = 'achievements_tab'
        
        # Step 3: Wait for achievements tab click
        elif self.tutorial_step == 3:
            if self.current_tab == 'achievements':
                self.tutorial_step = 4
                self.tutorial_message = "Excellent! You can scroll through items in each tab using your mouse wheel or by dragging."
                self.tutorial_full_text = self.tutorial_message
                self.tutorial_displayed_text = ""
                self.tutorial_text_index = 0
                self.tutorial_text_timer = current_time
                self.pointer_target = None
        
        # Step 4: Explain scrolling
        elif self.tutorial_step == 4:
            if self.tutorial_text_index >= len(self.tutorial_full_text):
                if current_time - self.tutorial_text_timer > 2000:
                    self.tutorial_step = 5
                    self.tutorial_message = "At the top, you'll find action buttons: Fullscreen, Tutorial, Reset, and Save."
                self.tutorial_full_text = self.tutorial_message
                self.tutorial_displayed_text = ""
                self.tutorial_text_index = 0
                self.tutorial_text_timer = current_time
                self.pointer_target = 'fullscreen_btn'
        
        # Step 5: Explain buttons
        elif self.tutorial_step == 5:
            if self.tutorial_text_index >= len(self.tutorial_full_text):
                if current_time - self.tutorial_text_timer > 2000:
                    self.tutorial_step = 6
                    self.tutorial_message = "The main egg button in the center is where you click to hatch snakes. That's the core of the game!"
                    self.tutorial_full_text = self.tutorial_message
                    self.tutorial_displayed_text = ""
                    self.tutorial_text_index = 0
                    self.tutorial_text_timer = current_time
                    self.pointer_target = 'egg'
        
        # Step 6: Explain egg button
        elif self.tutorial_step == 6:
            if self.tutorial_text_index >= len(self.tutorial_full_text):
                if current_time - self.tutorial_text_timer > 2000:
                    self.tutorial_step = 7
                    self.tutorial_message = "That's it! You now know how to navigate the UI. Have fun playing!"
                    self.tutorial_full_text = self.tutorial_message
                    self.tutorial_displayed_text = ""
                    self.tutorial_text_index = 0
                    self.tutorial_text_timer = current_time
                    self.pointer_target = None
        
        # Step 7: Tutorial complete
        elif self.tutorial_step == 7:
            if self.tutorial_text_index >= len(self.tutorial_full_text):
                if current_time - self.tutorial_text_timer > 2000:
                    self.tutorial_active = False
                    self.tutorial_message = None
                    self.pointer_target = None
        
        # Update letter-by-letter text animation
        if self.tutorial_message and self.tutorial_full_text:
            if current_time - self.tutorial_text_timer >= 30:  # 30ms per letter
                if self.tutorial_text_index < len(self.tutorial_full_text):
                    self.tutorial_displayed_text = self.tutorial_full_text[:self.tutorial_text_index + 1]
                    self.tutorial_text_index += 1
                    self.tutorial_text_timer = current_time
    
    def trigger_achievement(self, text, use_lavender_image=False, use_dedicated_player_image=False):
        """Display an achievement notification"""
        # Mark achievement as unlocked in state
        if 'achievements' not in self.state:
            self.state['achievements'] = {}

        # Only trigger if not already unlocked (avoid duplicate notifications)
        if not self.state['achievements'].get(text, False):
            self.state['achievements'][text] = True
            # Save state immediately to persist achievement
            self.save_state()

            self.achievement_message = {
                'text': text,
                'time': pygame.time.get_ticks(),
                'duration': 4000,  # 4 seconds
                'use_lavender_image': use_lavender_image,  # Flag to use lavender hognose image
                'use_dedicated_player_image': use_dedicated_player_image  # Flag to use dedicated player image
            }
            print(f"Achievement unlocked: {text}")
    
    def check_achievements(self):
        """Check and trigger achievements based on current game state"""
        if 'achievements' not in self.state:
            self.state['achievements'] = {}
        
        snakes = self.state['snakes']
        sps = self.state.get('snakes_per_second', 0)
        snakes_per_click = self.state.get('snakes_per_click', 1)
        
        # Track click count (initialize if not exists)
        if 'total_clicks' not in self.state:
            self.state['total_clicks'] = 0
        
        # Count purchased upgrades
        purchased_upgrades = sum(1 for u in self.state.get('upgrades', []) if u.get('purchased', False))
        total_upgrades = len(self.state.get('upgrades', []))
        
        # Count total generators owned
        total_generators = sum(g.get('count', 0) for g in self.state.get('generators', []))
        
        # Check snake count achievements
        if snakes >= 1 and not self.state['achievements'].get('first snake', False):
            self.trigger_achievement('first snake')
        if snakes >= 100 and not self.state['achievements'].get('snake collector', False):
            self.trigger_achievement('snake collector')
        if snakes >= 1000 and not self.state['achievements'].get('snake hoarder', False):
            self.trigger_achievement('snake hoarder')
        if snakes >= 1000000 and not self.state['achievements'].get('snake millionaire', False):
            self.trigger_achievement('snake millionaire')
        if snakes >= 1000000000 and not self.state['achievements'].get('snake billionaire', False):
            self.trigger_achievement('snake billionaire')
        if snakes >= 1000000000000 and not self.state['achievements'].get('snake empire', False):
            self.trigger_achievement('snake empire')
        
        # Check production achievements
        if sps >= 100 and not self.state['achievements'].get('100 snakes per second', False):
            self.trigger_achievement('100 snakes per second')
        if sps >= 1000 and not self.state['achievements'].get('1000 snakes per second', False):
            self.trigger_achievement('1000 snakes per second')
        if sps >= 10000 and not self.state['achievements'].get('10000 snakes per second', False):
            self.trigger_achievement('10000 snakes per second')
        if sps >= 100000 and not self.state['achievements'].get('100000 snakes per second', False):
            self.trigger_achievement('100000 snakes per second')
        if sps >= 1000000 and not self.state['achievements'].get('1 million snakes per second', False):
            self.trigger_achievement('1 million snakes per second')
        
        # Check generator achievements
        if total_generators >= 10 and not self.state['achievements'].get('10 generators', False):
            self.trigger_achievement('10 generators')
        if total_generators >= 50 and not self.state['achievements'].get('50 generators', False):
            self.trigger_achievement('50 generators')
        if total_generators >= 100 and not self.state['achievements'].get('100 generators', False):
            self.trigger_achievement('100 generators')
        if total_generators >= 5 and not self.state['achievements'].get('generator master', False):
            self.trigger_achievement('generator master')
        if sps >= 10 and not self.state['achievements'].get('production line', False):
            self.trigger_achievement('production line')
        if sps >= 1 and not self.state['achievements'].get('passive income', False):
            self.trigger_achievement('passive income')
        
        # Check upgrade achievements
        if purchased_upgrades >= 1 and not self.state['achievements'].get('first upgrade', False):
            self.trigger_achievement('first upgrade')
        if purchased_upgrades >= 5 and not self.state['achievements'].get('upgrade enthusiast', False):
            self.trigger_achievement('upgrade enthusiast')
        if purchased_upgrades >= 10 and not self.state['achievements'].get('upgrade master', False):
            self.trigger_achievement('upgrade master')
        if purchased_upgrades >= total_upgrades and total_upgrades > 0 and not self.state['achievements'].get('all upgrades', False):
            self.trigger_achievement('all upgrades')
        
        # Check click achievements
        if self.state['total_clicks'] >= 1 and not self.state['achievements'].get('first click', False):
            self.trigger_achievement('first click')
        if self.state['total_clicks'] >= 1000 and not self.state['achievements'].get('click master', False):
            self.trigger_achievement('click master')
        
        # Check speed/production achievements
        if sps >= 10000 and not self.state['achievements'].get('speed demon', False):
            self.trigger_achievement('speed demon')
        
        # Check specific item achievements (handled in buy functions, but check here too)
        # YouTube star - check if YouTube upgrade is purchased
        youtube_upgrade = next((u for u in self.state.get('upgrades', []) if u.get('name') == 'START A SNAKE YOUTUBE CHANNEL' and u.get('purchased', False)), None)
        if youtube_upgrade and not self.state['achievements'].get('youtube star', False):
            self.trigger_achievement('youtube star')
        
        # Rex owner - check if Rex generator is owned
        rex_generator = next((g for g in self.state.get('generators', []) if g.get('name') == 'Rex' and g.get('count', 0) > 0), None)
        if rex_generator and not self.state['achievements'].get('rex owner', False):
            self.trigger_achievement('rex owner')
        
        
        # Snake whisperer - high click power
        if snakes_per_click >= 1000 and not self.state['achievements'].get('snake whisperer', False):
            self.trigger_achievement('snake whisperer')

        # Dedicated player - played for 1 hour (3600 seconds)
        if self.state.get('total_playtime', 0) >= 3600 and not self.state['achievements'].get('dedicated player', False):
            self.trigger_achievement('dedicated player')
    
    def reset_game(self):
        """Reset game to default values - snakes_per_click = 1, all else = 0 or False"""
        # Set ALL state values to their defaults
        self.state = {
            'snakes': 0,
            'snakes_per_click': 1,  # Default value = 1
            'snakes_per_second': 0,
            'total_clicks': 0,
            'total_playtime': 0,
            'lavender_hognose_clicked': False,
            'achievements': {
                'you started an education program about reptiles': False,
                'super rare morph!': False,
                'oops we lost the code': False,
                'first click': False,
                'first snake': False,
                'snake collector': False,
                'snake hoarder': False,
                'snake millionaire': False,
                'snake billionaire': False,
                'generator master': False,
                'production line': False,
                'first upgrade': False,
                'upgrade enthusiast': False,
                'upgrade master': False,
                'speed demon': False,
                'click master': False,
                'passive income': False,
                'snake empire': False,
                'youtube star': False,
                'rex owner': False,
                '100 snakes per second': False,
                '1000 snakes per second': False,
                '10000 snakes per second': False,
                '100000 snakes per second': False,
                '1 million snakes per second': False,
                '10 generators': False,
                '50 generators': False,
                '100 generators': False,
                'all upgrades': False,
                'snake whisperer': False,
                'dedicated player': False
            }
        }

        # Reset upgrades and generators to default state
        self.state['upgrades'] = [u.copy() for u in self.upgrades]
        for u in self.state['upgrades']:
            u['purchased'] = False

        self.state['generators'] = [g.copy() for g in self.generators]
        for g in self.state['generators']:
            g['count'] = 0

        # Reset tutorial system
        self.tutorial_active = False
        self.tutorial_type = None
        self.tutorial_step = 0
        self.tutorial_clicks = 0
        self.tutorial_message = None
        self.tutorial_message_timer = 0
        self.pointer_target = None
        self.tutorial_displayed_text = ""
        self.tutorial_full_text = ""
        self.tutorial_text_index = 0
        self.tutorial_text_timer = 0
        self.tutorial_bot_talking_frame_index = 0
        self.tutorial_bot_nottalking_frame_index = 0
        self.tutorial_bot_talking_timer = 0
        self.tutorial_bot_nottalking_timer = 0
        self.first_tutorial_completed = False
        if hasattr(self, 'tutorial_force_lavender_hognose'):
            self.tutorial_force_lavender_hognose = False
        if hasattr(self, 'tutorial_force_thief_snake'):
            self.tutorial_force_thief_snake = False
        if hasattr(self, 'tutorial_lavender_hognose_clicked'):
            self.tutorial_lavender_hognose_clicked = False
        if hasattr(self, 'tutorial_thief_snake_clicked'):
            self.tutorial_thief_snake_clicked = False
        
        # Reset special snakes
        self.lavender_hognose = None
        self.lavender_hognose_spawn_timer = pygame.time.get_ticks()
        self.thief_snake = None
        self.thief_snake_spawn_timer = pygame.time.get_ticks()
        
        # Reset current tab to generators (default)
        self.current_tab = 'generators'
        self.scroll_y_upgrades = 0
        self.scroll_y_generators = 0
        self.scroll_y_achievements = 0
        
        # Reset timing
        self.last_update = pygame.time.get_ticks()
        
        # Recalculate snakes_per_click from base (1) with all upgrades added together
        # Since all upgrades are reset to unpurchased, this should be 1
        base_click = 1
        total_effect = 0.0
        for u in self.state['upgrades']:
            if u.get('purchased', False):
                total_effect += (u['effect'] - 1.0)
        self.state['snakes_per_click'] = base_click * (1.0 + total_effect)
        
        # Clear any active messages
        self.bonus_message = None
        self.achievement_message = None
        # Note: save_message is set after reset, so we don't clear it here
        
        # Clear production multiplier if it exists
        if 'production_multiplier' in self.state:
            self.state['production_multiplier'] = 1.0
        if 'multiplier_end_time' in self.state:
            del self.state['multiplier_end_time']

        # Save the reset state
        self.save_state()
        
        # Auto-start tutorial after reset (with small delay)
        self.auto_start_tutorial = True
        self.auto_start_timer = None  # Will be set in update()
    
    def update(self):

        # Update passive income
        current_time = pygame.time.get_ticks()
        if current_time - self.last_update >= 1000:
            # Always recalculate production first (in case generators were just purchased)
            self.state['snakes_per_second'] = self.calculate_sps()
            # Then add the production to snakes
            if self.state['snakes_per_second'] > 0:
                self.state['snakes'] += self.state['snakes_per_second']
            self.save_state()
            self.last_update = current_time
            # Update playtime (add 1 second)
            self.state['total_playtime'] += 1

            # Check achievements periodically (every second)
            self.check_achievements()
        
        # Update animation
        if self.egg_click_animation > 0:
            self.egg_click_animation -= 1
        
        # Update Lavender Hognose (golden cookie equivalent)
        if self.lavender_hognose is None:
            # Force spawn during tutorial if needed
            if hasattr(self, 'tutorial_force_lavender_hognose') and self.tutorial_force_lavender_hognose:
                import random
                x = random.randint(100, WIDTH - 100)
                y = random.randint(200, HEIGHT - 200)
                self.lavender_hognose = {
                    'x': x,
                    'y': y,
                    'spawn_time': current_time,
                    'duration': self.lavender_hognose_duration
                }
                self.tutorial_force_lavender_hognose = False
            # Not spawned, check if we should spawn it (but not during tutorial unless forced)
            elif not self.tutorial_active and current_time - self.lavender_hognose_spawn_timer >= self.lavender_hognose_min_spawn_time:
                # Random chance to spawn (higher chance as time passes)
                time_since_last = current_time - self.lavender_hognose_spawn_timer
                spawn_chance = min(0.1, (time_since_last - self.lavender_hognose_min_spawn_time) / (self.lavender_hognose_max_spawn_time - self.lavender_hognose_min_spawn_time) * 0.1)
                import random
                if random.random() < spawn_chance or time_since_last >= self.lavender_hognose_max_spawn_time:
                    # Spawn the lavender hognose at a random position
                    import random
                    x = random.randint(100, WIDTH - 100)
                    y = random.randint(200, HEIGHT - 200)
                    self.lavender_hognose = {
                        'x': x,
                        'y': y,
                        'spawn_time': current_time,
                        'duration': self.lavender_hognose_duration
                    }
        else:
            # Check if it's expired
            if current_time - self.lavender_hognose['spawn_time'] >= self.lavender_hognose['duration']:
                self.lavender_hognose = None
                self.lavender_hognose_spawn_timer = current_time

        # Update Thief Snake
        if self.thief_snake is None:
            # Force spawn during tutorial if needed
            if hasattr(self, 'tutorial_force_thief_snake') and self.tutorial_force_thief_snake:
                import random
                x = random.randint(150, WIDTH - 150)
                y = random.randint(250, HEIGHT - 250)
                self.thief_snake = {
                    'x': x,
                    'y': y,
                    'spawn_time': current_time,
                    'duration': self.thief_snake_duration,
                    'last_steal_time': current_time
                }
                self.tutorial_force_thief_snake = False
            # Not spawned, check if we should spawn it (but not during tutorial unless forced)
            elif not self.tutorial_active and current_time - self.thief_snake_spawn_timer >= self.thief_snake_min_spawn_time:
                # Random chance to spawn (higher chance as time passes)
                time_since_last = current_time - self.thief_snake_spawn_timer
                spawn_chance = min(0.08, (time_since_last - self.thief_snake_min_spawn_time) / (self.thief_snake_max_spawn_time - self.thief_snake_min_spawn_time) * 0.08)
                import random
                if random.random() < spawn_chance or time_since_last >= self.thief_snake_max_spawn_time:
                    # Spawn the thief snake at a random position
                    import random
                    x = random.randint(150, WIDTH - 150)
                    y = random.randint(250, HEIGHT - 250)
                    self.thief_snake = {
                        'x': x,
                        'y': y,
                        'spawn_time': current_time,
                        'duration': self.thief_snake_duration,
                        'last_steal_time': current_time
                    }
        else:
            # Thief snake is active - steal 1% of total snakes per second
            if current_time - self.thief_snake['last_steal_time'] >= 1000:
                # Steal 1% of total snakes (but don't go below 0)
                total_snakes = self.state.get('snakes', 0)
                steal_amount = max(0, int(total_snakes * 0.01))  # 1% of total
                if steal_amount > 0:
                    self.state['snakes'] -= steal_amount
                    # Show theft message
                    self.bonus_message = {
                        'text': f'Thief Snake stole {self.format_number(steal_amount)} snakes!',
                        'time': current_time,
                        'duration': 2000,  # 2 seconds
                        'color': RED
                    }
                self.thief_snake['last_steal_time'] = current_time

            # Check if it's expired
            if current_time - self.thief_snake['spawn_time'] >= self.thief_snake['duration']:
                self.thief_snake = None
                self.thief_snake_spawn_timer = current_time
        
        # Update production multiplier if active
        if 'production_multiplier' in self.state and 'multiplier_end_time' in self.state:
            if current_time >= self.state['multiplier_end_time']:
                self.state['production_multiplier'] = 1.0
                del self.state['multiplier_end_time']
        
        # Update bonus message display
        if self.bonus_message:
            if current_time - self.bonus_message['time'] >= self.bonus_message['duration']:
                self.bonus_message = None
        
        # Update save message display
        if self.save_message:
            if current_time - self.save_message['time'] >= self.save_message['duration']:
                self.save_message = None
        
        # Update achievement message display
        if self.achievement_message:
            if current_time - self.achievement_message['time'] >= self.achievement_message['duration']:
                self.achievement_message = None
        
        # Update tutorial bot animation
        if self.tutorial_active:
            # Update talking animation if message is active
            if self.tutorial_message and self.tutorial_bot_talking_frames:
                if self.tutorial_bot_talking_timer == 0:
                    self.tutorial_bot_talking_timer = current_time
                elif current_time - self.tutorial_bot_talking_timer >= 100:  # 100ms per frame
                    self.tutorial_bot_talking_frame_index = (self.tutorial_bot_talking_frame_index + 1) % len(self.tutorial_bot_talking_frames)
                    self.tutorial_bot_talking_timer = current_time
            # Update nottalking animation if no message
            elif not self.tutorial_message and self.tutorial_bot_nottalking_frames:
                if self.tutorial_bot_nottalking_timer == 0:
                    self.tutorial_bot_nottalking_timer = current_time
                elif current_time - self.tutorial_bot_nottalking_timer >= 100:  # 100ms per frame
                    self.tutorial_bot_nottalking_frame_index = (self.tutorial_bot_nottalking_frame_index + 1) % len(self.tutorial_bot_nottalking_frames)
                    self.tutorial_bot_nottalking_timer = current_time
            
            # Update pointer animation
            if self.pointer_target and self.pointer_frames:
                if self.pointer_animation_timer == 0:
                    self.pointer_animation_timer = current_time
                elif current_time - self.pointer_animation_timer >= 500:  # 500ms per frame (pointing/clicking)
                    self.pointer_frame_index = (self.pointer_frame_index + 1) % len(self.pointer_frames)
                    self.pointer_animation_timer = current_time
        
        # Auto-start tutorial on first launch (with small delay to ensure everything is ready)
        if hasattr(self, 'auto_start_tutorial') and self.auto_start_tutorial:
            # Wait a bit for the game to fully initialize (1 second delay)
            if not hasattr(self, 'auto_start_timer'):
                self.auto_start_timer = current_time
            elif current_time - self.auto_start_timer >= 1000:  # 1 second delay
                self.start_first_tutorial()
                self.auto_start_tutorial = False
                del self.auto_start_timer
        
        # Update tutorial progression
        self.update_tutorial(current_time)
    
    def draw_button(self, surface, rect, text, bg_color, text_color=WHITE, hover=False, disabled=False, border_color=None):
        if disabled:
            bg_color = DARK_GRAY
            text_color = GRAY
        elif hover:
            # Brighten on hover
            bg_color = tuple(min(255, c + 30) for c in bg_color)
        
        # Shadow
        shadow_rect = pygame.Rect(rect.x + 3, rect.y + 3, rect.width, rect.height)
        pygame.draw.rect(surface, (0, 0, 0, 80), shadow_rect)
        
        # Button background
        pygame.draw.rect(surface, bg_color, rect)
        
        # Border
        border = border_color if border_color else (tuple(max(0, c - 30) for c in bg_color))
        pygame.draw.rect(surface, border, rect, 2)
        
        # Highlight on top
        if not disabled:
            highlight_rect = pygame.Rect(rect.x, rect.y, rect.width, rect.height // 2)
            highlight_color = tuple(min(255, c + 20) for c in bg_color)
            pygame.draw.rect(surface, highlight_color, highlight_rect)
        
        # Draw text with shadow
        text_surf = font_small.render(text, True, text_color if not disabled else GRAY)
        text_shadow = font_small.render(text, True, BLACK)
        text_rect = text_surf.get_rect(center=rect.center)
        surface.blit(text_shadow, (text_rect.x + 1, text_rect.y + 1))
        surface.blit(text_surf, text_rect)
    
    def draw(self):
        # Clamp scroll positions to valid ranges - prevent negative scrolls
        max_scroll_upgrades = self.get_max_scroll('upgrades')
        max_scroll_generators = self.get_max_scroll('generators')
        max_scroll_achievements = self.get_max_scroll('achievements')
        self.scroll_y_upgrades = max(0, min(max_scroll_upgrades, max(0, self.scroll_y_upgrades)))
        self.scroll_y_generators = max(0, min(max_scroll_generators, max(0, self.scroll_y_generators)))
        self.scroll_y_achievements = max(0, min(max_scroll_achievements, max(0, self.scroll_y_achievements)))
        
        # Reset hover states at start of each frame
        self.hovered_item = None
        self.hovered_tab = None
        self.hovered_button = None
        
        mouse_pos = pygame.mouse.get_pos()
        shop_rect = self.shop_rect
        
        # Draw shop items on a separate surface (behind background)
        shop_items_surface = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
        scale_x = WIDTH / 1600.0
        scale_y = HEIGHT / 1000.0
        # Use shop_rect position for y_offset calculation (was hardcoded 500)
        y_offset = shop_rect.y + int(10 * scale_y) - (self.scroll_y_upgrades if self.current_tab == 'upgrades' else self.scroll_y_generators)
        item_height = int(110 * scale_y)
        item_width = WIDTH - int(120 * scale_x)
        item_x = int(60 * scale_x)
        shop_top = shop_rect.y + int(10 * scale_y)
        shop_bottom = shop_rect.y + shop_rect.height - int(10 * scale_y)
        
        if self.current_tab == 'upgrades':
            for i, upgrade in enumerate(self.state['upgrades']):
                item_y = y_offset + i * item_height
                if item_y + item_height < shop_top or item_y > shop_bottom:
                    continue
                item_rect = pygame.Rect(item_x, item_y, item_width, item_height - 3)
                hover = item_rect.collidepoint(mouse_pos)
                if upgrade['purchased']:
                    bg_color = (50, 50, 50)
                elif hover:
                    bg_color = GREEN_MEDIUM
                else:
                    bg_color = (35, 80, 55)
                shadow_rect = pygame.Rect(item_rect.x + 2, item_rect.y + 2, item_rect.width, item_rect.height)
                pygame.draw.rect(shop_items_surface, (0, 0, 0, 60), shadow_rect)
                pygame.draw.rect(shop_items_surface, bg_color, item_rect)
                border_color = GOLD if hover and not upgrade['purchased'] else (GREEN_LIGHT if hover else (60, 60, 60))
                pygame.draw.rect(shop_items_surface, border_color, item_rect, 2)
                status_x = item_rect.x + 15
                text_y = item_rect.y + (item_rect.height - font_small.get_height()) // 2
                text_x = status_x
                if upgrade['name'] in self.images:
                    img = self.images[upgrade['name']]
                    img_size = img.get_width()
                    # Ensure image fits within item_rect height, adjust if needed
                    max_img_size = min(img_size, item_rect.height - 4)  # Leave 4px padding
                    if max_img_size < img_size:
                        # Scale down if too large
                        scale_factor = max_img_size / img_size
                        new_width = int(img.get_width() * scale_factor)
                        new_height = int(img.get_height() * scale_factor)
                        img = pygame.transform.smoothscale(img, (new_width, new_height))
                        img_size = new_width
                    img_y = item_rect.y + (item_rect.height - img_size) // 2
                    # Ensure image doesn't go below the item_rect
                    if img_y + img_size > item_rect.y + item_rect.height:
                        img_y = item_rect.y + item_rect.height - img_size - 2
                    img_border = pygame.Rect(text_x - 2, img_y - 2, img_size + 4, img_size + 4)
                    pygame.draw.rect(shop_items_surface, GOLD, img_border, 2)
                    shop_items_surface.blit(img, (text_x, img_y))
                    text_x += img_size + 10
                if upgrade['purchased']:
                    status_text = font_small.render("[SOLD]", True, GOLD)
                else:
                    status_text = font_small.render("[BUY]", True, GREEN_LIGHT)
                shop_items_surface.blit(status_text, (text_x, text_y))
                # Draw upgrade name
                name_text_color = GRAY if upgrade['purchased'] else (GOLD_BRIGHT if hover else WHITE)
                name_text = font_small.render(f"{upgrade['name']} - ", True, name_text_color)
                shop_items_surface.blit(name_text, (text_x + status_text.get_width() + 15, text_y))
                current_x = text_x + status_text.get_width() + 15 + name_text.get_width()
                
                if upgrade['purchased']:
                    cost_text = font_small.render("SOLD", True, GRAY)
                    shop_items_surface.blit(cost_text, (current_x, text_y))
                else:
                    # Draw cost number
                    cost_num_text = font_small.render(self.format_number(upgrade['cost']), True, GREEN_LIGHT)
                    shop_items_surface.blit(cost_num_text, (current_x, text_y))
                    current_x += cost_num_text.get_width() + 5
                    # Draw snake icon instead of "snakes" text
                    if self.snakes_money_icon:
                        icon_size = int(20 * scale_y)
                        icon_scaled = pygame.transform.smoothscale(self.snakes_money_icon, (icon_size, icon_size))
                        icon_y = text_y + (font_small.get_height() - icon_size) // 2
                        shop_items_surface.blit(icon_scaled, (current_x, icon_y))
        elif self.current_tab == 'generators':
            for i, gen in enumerate(self.state['generators']):
                item_y = y_offset + i * item_height
                if item_y + item_height < shop_top or item_y > shop_bottom:
                    continue
                item_rect = pygame.Rect(item_x, item_y, item_width, item_height - 3)
                hover = item_rect.collidepoint(mouse_pos)
                if hover:
                    bg_color = GREEN_MEDIUM
                    self.hovered_item = ('generator', i)
                else:
                    bg_color = (35, 80, 55)
                shadow_rect = pygame.Rect(item_rect.x + 2, item_rect.y + 2, item_rect.width, item_rect.height)
                pygame.draw.rect(shop_items_surface, (0, 0, 0, 60), shadow_rect)
                pygame.draw.rect(shop_items_surface, bg_color, item_rect)
                border_color = GOLD if hover else GREEN_LIGHT
                pygame.draw.rect(shop_items_surface, border_color, item_rect, 2)
                text_x = item_rect.x + 15
                if gen['name'] in self.images:
                    img = self.images[gen['name']]
                    img_size = img.get_width()
                    img_y = item_rect.y + (item_rect.height - img_size) // 2
                    img_border = pygame.Rect(text_x - 2, img_y - 2, img_size + 4, img_size + 4)
                    pygame.draw.rect(shop_items_surface, GOLD, img_border, 2)
                    shop_items_surface.blit(img, (text_x, img_y))
                    text_x += img_size + 10
                cost = self.get_generator_cost(gen)
                # Calculate production with upgrade multipliers (same as calculate_sps)
                base_production = gen['count'] * gen['base_production']
                upgrade_multiplier = self.get_upgrade_multiplier()
                temp_multiplier = self.state.get('production_multiplier', 1.0)
                production = base_production * upgrade_multiplier * temp_multiplier
                text_y = item_rect.y + (item_rect.height - font_small.get_height()) // 2
                name_text = font_small.render(f"{gen['name']} - ", True, GOLD_BRIGHT if hover else WHITE)
                shop_items_surface.blit(name_text, (text_x, text_y))
                current_x = text_x + name_text.get_width()
                # Draw "Cost: " text
                cost_label = font_small.render("Cost: ", True, GREEN_LIGHT)
                shop_items_surface.blit(cost_label, (current_x, text_y))
                current_x += cost_label.get_width()
                # Draw cost number
                cost_num_text = font_small.render(self.format_number(cost), True, GREEN_LIGHT)
                shop_items_surface.blit(cost_num_text, (current_x, text_y))
                current_x += cost_num_text.get_width() + 5
                # Draw snake icon instead of "snakes" text
                if self.snakes_money_icon:
                    icon_size = int(20 * scale_y)
                    icon_scaled = pygame.transform.smoothscale(self.snakes_money_icon, (icon_size, icon_size))
                    icon_y = text_y + (font_small.get_height() - icon_size) // 2
                    shop_items_surface.blit(icon_scaled, (current_x, icon_y))
                    current_x += icon_size + 10
                if current_x < item_rect.x + item_width - 200:
                    owned_text = font_small.render(f"Owned: {gen['count']}", True, LIGHT_GRAY)
                    shop_items_surface.blit(owned_text, (current_x, text_y))
                    current_x += owned_text.get_width() + 10
                    if current_x < item_rect.x + item_width - 150:
                        prod_text = font_small.render(f"Produces: {self.format_production(production)}/sec", True, LIGHT_GRAY)
                        shop_items_surface.blit(prod_text, (current_x, text_y))
        elif self.current_tab == 'achievements':
            # Display achievements
            achievements_list = [
                'first click',
                'first snake',
                'snake collector',
                'snake hoarder',
                'snake millionaire',
                'snake billionaire',
                'generator master',
                'production line',
                'first upgrade',
                'upgrade enthusiast',
                'upgrade master',
                'speed demon',
                'click master',
                'passive income',
                'snake empire',
                'you started an education program about reptiles',
                'youtube star',
                'rex owner',
                '100 snakes per second',
                '1000 snakes per second',
                '10000 snakes per second',
                '100000 snakes per second',
                '1 million snakes per second',
                '10 generators',
                '50 generators',
                '100 generators',
                'all upgrades',
                'snake whisperer',
                'super rare morph!',
                'oops we lost the code',
                'dedicated player'
            ]
            
            # Ensure achievements dict exists in state and initialize all achievements
            if 'achievements' not in self.state:
                self.state['achievements'] = {}
            
            # Initialize any missing achievements to False
            for achievement_name in achievements_list:
                if achievement_name not in self.state['achievements']:
                    self.state['achievements'][achievement_name] = False
            
            # Sort achievements: unlocked first, then locked
            sorted_achievements = sorted(achievements_list, key=lambda name: not self.state['achievements'].get(name, False))
            
            # Display 2 achievements per row
            achievements_per_row = 2
            achievement_item_width = (item_width - 10) // 2  # Width for each achievement item (with spacing)
            achievement_item_height = item_height
            
            for i, achievement_name in enumerate(sorted_achievements):
                row = i // achievements_per_row
                col = i % achievements_per_row
                
                item_y = y_offset + row * achievement_item_height
                if item_y + achievement_item_height < shop_top or item_y > shop_bottom:
                    continue
                
                # Calculate x position based on column
                item_x_pos = item_x + col * (achievement_item_width + 10)
                item_rect = pygame.Rect(item_x_pos, item_y, achievement_item_width, achievement_item_height - 3)
                hover = item_rect.collidepoint(mouse_pos)
                
                # Check if achievement is unlocked
                is_unlocked = self.state['achievements'].get(achievement_name, False)
                
                if is_unlocked:
                    bg_color = GREEN_MEDIUM if hover else (35, 80, 55)
                else:
                    bg_color = (20, 20, 20) if hover else (15, 15, 15)  # Darker for locked
                
                shadow_rect = pygame.Rect(item_rect.x + 2, item_rect.y + 2, item_rect.width, item_rect.height)
                pygame.draw.rect(shop_items_surface, (0, 0, 0, 60), shadow_rect)
                pygame.draw.rect(shop_items_surface, bg_color, item_rect)
                border_color = GOLD if (hover and is_unlocked) else (GRAY if is_unlocked else DARK_GRAY)
                pygame.draw.rect(shop_items_surface, border_color, item_rect, 2)
                
                text_x = item_rect.x + 15
                text_y = item_rect.y + (item_rect.height - font_small.get_height()) // 2
                
                # Display image - use locked.png for locked achievements (smaller for 2-per-row layout)
                display_size = int(60 * scale_y)
                if is_unlocked:
                    # Special achievements with specific images
                    if achievement_name == 'you started an education program about reptiles' and self.achievement_image:
                        img = pygame.transform.smoothscale(self.achievement_image, (display_size, display_size))
                    elif achievement_name == 'super rare morph!' and self.lavender_hognose_image:
                        img = pygame.transform.smoothscale(self.lavender_hognose_image, (display_size, display_size))
                    elif achievement_name == 'oops we lost the code' and self.missing_texture_image:
                        img = pygame.transform.smoothscale(self.missing_texture_image, (display_size, display_size))
                    elif achievement_name == 'dedicated player' and self.dedicated_player_image:
                        img = pygame.transform.smoothscale(self.dedicated_player_image, (display_size, display_size))
                    # Snake-related achievements use Snakes.png
                    elif any(keyword in achievement_name.lower() for keyword in ['snake', 'snakes']) and self.snakes_money_icon:
                        img = pygame.transform.smoothscale(self.snakes_money_icon, (display_size, display_size))
                    else:
                        # Try to load achievement-specific image, fallback to missing texture
                        img = self.load_achievement_image(achievement_name, display_size)
                        if img is None:
                            img = self.get_missing_texture(display_size) if self.missing_texture_image else None
                else:
                    # Use locked.png for locked achievements
                    if self.locked_achievement_image:
                        img = pygame.transform.smoothscale(self.locked_achievement_image, (display_size, display_size))
                    else:
                        img = self.get_missing_texture(display_size) if self.missing_texture_image else None
                
                if img:
                    img_y = item_rect.y + (item_rect.height - display_size) // 2
                    img_border = pygame.Rect(text_x - 2, img_y - 2, display_size + 4, display_size + 4)
                    border_img_color = GOLD if is_unlocked else DARK_GRAY
                    pygame.draw.rect(shop_items_surface, border_img_color, img_border, 2)
                    shop_items_surface.blit(img, (text_x, img_y))
                    text_x += display_size + 10
                
                # Display achievement name or "undiscovered achievement"
                # Wrap text if it's too long for the smaller width
                max_text_width = item_rect.width - (text_x - item_rect.x) - 20  # Available width from text_x to end of rect
                if is_unlocked:
                    # Use special font for dedicated player achievement
                    if achievement_name == 'dedicated player' and self.dedicated_player_font:
                        name_text = self.dedicated_player_font.render(achievement_name, True, GOLD_BRIGHT if hover else WHITE)
                    else:
                        name_text = font_small.render(achievement_name, True, GOLD_BRIGHT if hover else WHITE)
                else:
                    name_text = font_small.render("undiscovered achievement", True, GRAY)
                
                # If text is too wide, try to fit it or truncate
                if name_text.get_width() > max_text_width:
                    # Try smaller font or truncate
                    truncated_name = achievement_name
                    if is_unlocked:
                        while font_small.size(truncated_name + "...")[0] > max_text_width and len(truncated_name) > 10:
                            truncated_name = truncated_name[:-1]
                        if len(truncated_name) < len(achievement_name):
                            truncated_name += "..."
                        name_text = font_small.render(truncated_name, True, GOLD_BRIGHT if hover else WHITE)
                    else:
                        # For locked, just use shorter text
                        name_text = font_tiny.render("undiscovered", True, GRAY)
                
                shop_items_surface.blit(name_text, (text_x, text_y))
        
        # Draw shop background image BEFORE shop items (so items appear on top)
        shop_rect = self.shop_rect
        if self.shop_background_image:
            # Scale background to shop rect size if needed
            current_shop_size = (shop_rect.width, shop_rect.height)
            if self.scaled_shop_bg is None or self.cached_shop_bg_size != current_shop_size:
                self.scaled_shop_bg = pygame.transform.smoothscale(self.shop_background_image, current_shop_size)
                self.cached_shop_bg_size = current_shop_size
            # Draw the scaled shop background
            screen.blit(self.scaled_shop_bg, (shop_rect.x, shop_rect.y))
        else:
            # Fallback: draw a simple background if image not available
            pygame.draw.rect(screen, BG_LIGHT, shop_rect)
        
        # Blit shop items on top of the background
        screen.blit(shop_items_surface, (0, 0))
        
        # Draw background image if available (has transparent shop area), otherwise draw programmatically
        if hasattr(self, 'background_image') and self.background_image:
            # Scale background to current screen size if needed
            current_size = (WIDTH, HEIGHT)
            if self.scaled_background is None or self.cached_bg_size != current_size:
                self.scaled_background = pygame.transform.smoothscale(self.background_image, current_size)
                self.cached_bg_size = current_size
            # Use scaled background image with transparent shop area
            screen.blit(self.scaled_background, (0, 0))
        else:
            # Fallback: draw background programmatically
            screen.fill(BG_DARK)
            for y in range(0, HEIGHT, 2):
                alpha = int(255 * (1 - y / HEIGHT * 0.3))
                color = tuple(min(255, BG_DARK[i] + int((BG_MEDIUM[i] - BG_DARK[i]) * (1 - y / HEIGHT))) for i in range(3))
                pygame.draw.line(screen, color, (0, y), (WIDTH, y))
            
            # Add subtle scale pattern overlay everywhere
            for y in range(0, HEIGHT, 40):
                for x in range(0, WIDTH, 60):
                    if (x // 60 + y // 40) % 2 == 0:
                        scale_rect = pygame.Rect(x, y, 50, 35)
                        pygame.draw.ellipse(screen, SNAKE_SCALE, scale_rect)
        
        # Header with gradient effect
        header_rect = pygame.Rect(0, 0, WIDTH, 130)
        for y in range(header_rect.height):
            alpha = y / header_rect.height
            color = tuple(int(BG_MEDIUM[i] * (1 - alpha) + GREEN_DARK[i] * alpha) for i in range(3))
            pygame.draw.line(screen, color, (0, y), (WIDTH, y))
        
        # Header border glow
        pygame.draw.line(screen, GREEN_BRIGHT, (0, 130), (WIDTH, 130), 3)
        pygame.draw.line(screen, GREEN_MEDIUM, (0, 0), (WIDTH, 0), 2)
        
        # Title with better styling
        title = font_title.render("Snake Idle", True, GOLD_BRIGHT)
        title_shadow = font_title.render("Snake Idle", True, BLACK)
        title_glow = font_title.render("Snake Idle", True, GOLD_DARK)
        title_x = WIDTH//2 - title.get_width()//2
        title_y = 25
        # Glow effect
        for offset in [(2, 2), (-2, 2), (2, -2), (-2, -2)]:
            screen.blit(title_glow, (title_x + offset[0], title_y + offset[1]))
        screen.blit(title_shadow, (title_x + 3, title_y + 3))
        screen.blit(title, (title_x, title_y))
        
        # Stats panel with modern card design
        stats_panel = pygame.Rect(50, 60, WIDTH - 100, 55)
        # Shadow
        shadow_rect = pygame.Rect(stats_panel.x + 4, stats_panel.y + 4, stats_panel.width, stats_panel.height)
        pygame.draw.rect(screen, (0, 0, 0, 100), shadow_rect)
        # Panel background
        pygame.draw.rect(screen, BG_LIGHT, stats_panel)
        pygame.draw.rect(screen, GREEN_MEDIUM, stats_panel, 2)
        # Inner highlight
        highlight_rect = pygame.Rect(stats_panel.x, stats_panel.y, stats_panel.width, stats_panel.height // 2)
        pygame.draw.rect(screen, (BG_LIGHT[0] + 10, BG_LIGHT[1] + 10, BG_LIGHT[2] + 10), highlight_rect)
        
        stats_y = 78
        # Stats with better formatting - spaced evenly across panel
        stats_panel_width = WIDTH - 100
        stats_spacing = stats_panel_width // 3
        
        # Draw snakes money icon if available
        snakes_x = stats_panel.x + 20
        if self.snakes_money_icon:
            icon_y = stats_y + (font_medium.get_height() - 32) // 2
            screen.blit(self.snakes_money_icon, (snakes_x, icon_y))
            snakes_x += 40  # Space after icon
        
        # Draw "Snakes: " label
        snakes_label = font_medium.render("Snakes: ", True, GOLD_BRIGHT)
        snakes_label_shadow = font_medium.render("Snakes: ", True, BLACK)
        screen.blit(snakes_label_shadow, (snakes_x + 2, stats_y + 2))
        screen.blit(snakes_label, (snakes_x, stats_y))
        current_x = snakes_x + snakes_label.get_width()
        # Draw snake count number
        snakes_num_text = font_medium.render(self.format_number(self.state['snakes']), True, GOLD_BRIGHT)
        snakes_num_shadow = font_medium.render(self.format_number(self.state['snakes']), True, BLACK)
        screen.blit(snakes_num_shadow, (current_x + 2, stats_y + 2))
        screen.blit(snakes_num_text, (current_x, stats_y))
        current_x += snakes_num_text.get_width() + 5
        # Draw snake icon instead of "snakes" text
        if self.snakes_money_icon:
            icon_size = int(28 * scale_y) if 'scale_y' in locals() else 28
            icon_scaled = pygame.transform.smoothscale(self.snakes_money_icon, (icon_size, icon_size))
            icon_y = stats_y + (font_medium.get_height() - icon_size) // 2
            screen.blit(icon_scaled, (current_x, icon_y))
        
        spc_text = font_medium.render(f"Per Click: {self.format_number(self.state['snakes_per_click'])}", True, GOLD_BRIGHT)
        spc_shadow = font_medium.render(f"Per Click: {self.format_number(self.state['snakes_per_click'])}", True, BLACK)
        spc_x = stats_panel.x + stats_spacing
        screen.blit(spc_shadow, (spc_x + 2, stats_y + 2))
        screen.blit(spc_text, (spc_x, stats_y))
        
        self.state['snakes_per_second'] = self.calculate_sps()
        sps_text = font_medium.render(f"Per Second: {self.format_production(self.state['snakes_per_second'])}", True, GOLD_BRIGHT)
        sps_shadow = font_medium.render(f"Per Second: {self.format_production(self.state['snakes_per_second'])}", True, BLACK)
        sps_x = stats_panel.x + stats_spacing * 2
        screen.blit(sps_shadow, (sps_x + 2, stats_y + 2))
        screen.blit(sps_text, (sps_x, stats_y))
        
        # Egg button with premium visuals - ALL PARTS AS CIRCLES
        egg_size = 250 + (self.egg_click_animation * 3)
        egg_x = WIDTH//2 - egg_size//2
        egg_y = 145 - self.egg_click_animation
        egg_center_x = egg_x + egg_size // 2
        egg_center_y = egg_y + egg_size // 2
        
        # Multiple shadow layers for depth - CIRCLES
        for i in range(3, 0, -1):
            shadow_radius = (egg_size // 2) + i * 2
            # Draw circle shadow using filled circle (pygame doesn't support alpha in draw.circle)
            shadow_surface = pygame.Surface((shadow_radius * 2, shadow_radius * 2), pygame.SRCALPHA)
            shadow_alpha = 40 - i * 10
            pygame.draw.circle(shadow_surface, (0, 0, 0, shadow_alpha), (shadow_radius, shadow_radius), shadow_radius)
            screen.blit(shadow_surface, (egg_center_x + i - shadow_radius, egg_center_y + i - shadow_radius))
        
        # Egg with original beautiful design - PERFECT CIRCLE, NO CORNERS
        egg_radius = egg_size // 2
        
        # Draw egg as a SINGLE perfect circle - no gradient overlay to avoid distortion
        pygame.draw.circle(screen, (255, 248, 220), (egg_center_x, egg_center_y), egg_radius)
        
        # Simple border - just one thin circle outline, no multiple layers
        pygame.draw.circle(screen, (139, 115, 85), (egg_center_x, egg_center_y), egg_radius, 2)
        
        # Shine/highlight - CIRCLE (with alpha)
        highlight_radius = egg_size // 5
        highlight_x = egg_center_x - egg_radius // 3
        highlight_y = egg_center_y - egg_radius // 3
        highlight_surface = pygame.Surface((highlight_radius * 2, highlight_radius * 2), pygame.SRCALPHA)
        pygame.draw.circle(highlight_surface, (255, 255, 255, 150), (highlight_radius, highlight_radius), highlight_radius)
        screen.blit(highlight_surface, (highlight_x - highlight_radius, highlight_y - highlight_radius))
        
        # Inner glow - CIRCLE (with alpha)
        inner_glow_radius = int(egg_radius * 0.7)
        glow_surface = pygame.Surface((inner_glow_radius * 2, inner_glow_radius * 2), pygame.SRCALPHA)
        pygame.draw.circle(glow_surface, (255, 255, 255, 30), (inner_glow_radius, inner_glow_radius), inner_glow_radius)
        screen.blit(glow_surface, (egg_center_x - inner_glow_radius, egg_center_y - inner_glow_radius))
        
        # Hint text with better styling
        hint_text = font_tiny.render("Click to hatch snakes!", True, LIGHT_GRAY)
        hint_shadow = font_tiny.render("Click to hatch snakes!", True, BLACK)
        hint_x = WIDTH//2 - hint_text.get_width()//2
        screen.blit(hint_shadow, (hint_x + 1, egg_y + egg_size + 11))
        screen.blit(hint_text, (hint_x, egg_y + egg_size + 10))
        
        # Update egg_rect for collision detection (still a rect for pygame collision)
        self.egg_rect = pygame.Rect(egg_x, egg_y, egg_size, egg_size)
        
        # Draw tutorial bot (animated sprite) in bottom right corner
        if self.tutorial_bot_frames and self.tutorial_bot_frame_index < len(self.tutorial_bot_frames):
            # Position tutorial bot in bottom right corner, scaled down
            bot_scale = 0.15  # 15% of original size
            original_frame = self.tutorial_bot_frames[self.tutorial_bot_frame_index]
            bot_width = int(original_frame.get_width() * bot_scale)
            bot_height = int(original_frame.get_height() * bot_scale)
            bot_scaled = pygame.transform.smoothscale(original_frame, (bot_width, bot_height))
            
            # Position in bottom right with some padding
            bot_x = WIDTH - bot_width - 20
            bot_y = HEIGHT - bot_height - 20
            
            # Draw shadow
            shadow_surface = pygame.Surface((bot_width + 4, bot_height + 4), pygame.SRCALPHA)
            pygame.draw.ellipse(shadow_surface, (0, 0, 0, 100), (0, 0, bot_width + 4, bot_height + 4))
            screen.blit(shadow_surface, (bot_x - 2, bot_y - 2 + 4))
            
            # Draw tutorial bot
            screen.blit(bot_scaled, (bot_x, bot_y))
        
        # Tabs with modern design - taller for snake theme
        upgrades_hover = self.upgrades_tab_rect.collidepoint(mouse_pos)
        generators_hover = self.generators_tab_rect.collidepoint(mouse_pos)
        achievements_hover = self.achievements_tab_rect.collidepoint(mouse_pos)
        
        # Active tab gets gold, inactive gets dark green
        if self.current_tab == 'upgrades':
            tab_color = GOLD_DARK if not upgrades_hover else GOLD
            border_color = GOLD_BRIGHT
        else:
            tab_color = GREEN_DARK if not upgrades_hover else GREEN_MEDIUM
            border_color = GREEN_LIGHT
        
        self.draw_button(screen, self.upgrades_tab_rect, "Upgrades", tab_color, WHITE, upgrades_hover, border_color=border_color)
        
        if self.current_tab == 'generators':
            tab_color = GOLD_DARK if not generators_hover else GOLD
            border_color = GOLD_BRIGHT
        else:
            tab_color = GREEN_DARK if not generators_hover else GREEN_MEDIUM
            border_color = GREEN_LIGHT
        
        self.draw_button(screen, self.generators_tab_rect, "Generators", tab_color, WHITE, generators_hover, border_color=border_color)
        
        if self.current_tab == 'achievements':
            tab_color = GOLD_DARK if not achievements_hover else GOLD
            border_color = GOLD_BRIGHT
        else:
            tab_color = GREEN_DARK if not achievements_hover else GREEN_MEDIUM
            border_color = GREEN_LIGHT
        
        self.draw_button(screen, self.achievements_tab_rect, "Achievements", tab_color, WHITE, achievements_hover, border_color=border_color)
        
        # Shop area border (background was already drawn earlier, before shop items)
        shop_rect = self.shop_rect
        # Draw border outline
        pygame.draw.rect(screen, GREEN_MEDIUM, shop_rect, 3)
        pygame.draw.rect(screen, GREEN_BRIGHT, shop_rect, 1)
        
        # Draw Lavender Hognose (golden cookie equivalent) if spawned
        if self.lavender_hognose and self.lavender_hognose_image:
            import math
            # Pulsing animation
            current_time = pygame.time.get_ticks()
            time_alive = current_time - self.lavender_hognose['spawn_time']
            pulse = 1.0 + 0.1 * math.sin(time_alive / 200.0)  # Gentle pulsing
            # Display at 8% of screen height (larger, more visible)
            base_size = int(HEIGHT * 0.08)  # 8% of screen height (80px on 1000px screen)
            size = int(base_size * pulse)
            
            # Draw shadow
            shadow_surface = pygame.Surface((size + 4, size + 4), pygame.SRCALPHA)
            pygame.draw.circle(shadow_surface, (0, 0, 0, 100), (size // 2 + 2, size // 2 + 2), size // 2 + 2)
            screen.blit(shadow_surface, (self.lavender_hognose['x'] - size // 2, self.lavender_hognose['y'] - size // 2 + 2))
            
            # Scale image to size
            scaled_img = pygame.transform.smoothscale(self.lavender_hognose_image, (size, size))
            
            # Create circular mask to crop image to circle
            mask_surface = pygame.Surface((size, size), pygame.SRCALPHA)
            pygame.draw.circle(mask_surface, (255, 255, 255, 255), (size // 2, size // 2), size // 2)
            
            # Apply circular mask to image
            circular_img = pygame.Surface((size, size), pygame.SRCALPHA)
            circular_img.blit(scaled_img, (0, 0))
            circular_img.blit(mask_surface, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)
            
            # Draw the circular image
            screen.blit(circular_img, (self.lavender_hognose['x'] - size // 2, self.lavender_hognose['y'] - size // 2))

        # Draw Thief Snake if spawned
        if self.thief_snake and self.thief_snake_image:
            import math
            # Pulsing animation (more aggressive to show it's dangerous)
            current_time = pygame.time.get_ticks()
            time_alive = current_time - self.thief_snake['spawn_time']
            pulse = 1.0 + 0.2 * math.sin(time_alive / 150.0)  # More aggressive pulsing
            # Display at 7% of screen height (slightly smaller than lavender)
            base_size = int(HEIGHT * 0.07)  # 7% of screen height
            size = int(base_size * pulse)

            # Draw shadow (darker for thief)
            shadow_surface = pygame.Surface((size + 6, size + 6), pygame.SRCALPHA)
            pygame.draw.circle(shadow_surface, (0, 0, 0, 150), (size // 2 + 3, size // 2 + 3), size // 2 + 3)
            screen.blit(shadow_surface, (self.thief_snake['x'] - size // 2, self.thief_snake['y'] - size // 2 + 3))

            # Scale image to size
            scaled_img = pygame.transform.smoothscale(self.thief_snake_image, (size, size))

            # Create circular mask to crop image to circle
            mask_surface = pygame.Surface((size, size), pygame.SRCALPHA)
            pygame.draw.circle(mask_surface, (255, 255, 255, 255), (size // 2, size // 2), size // 2)

            # Apply circular mask to image
            circular_img = pygame.Surface((size, size), pygame.SRCALPHA)
            circular_img.blit(scaled_img, (0, 0))
            circular_img.blit(mask_surface, (0, 0), special_flags=pygame.BLEND_RGBA_MULT)

            # Draw red glow effect around thief snake
            glow_surface = pygame.Surface((size + 20, size + 20), pygame.SRCALPHA)
            pygame.draw.circle(glow_surface, (255, 0, 0, 50), ((size + 20) // 2, (size + 20) // 2), (size + 20) // 2)
            screen.blit(glow_surface, (self.thief_snake['x'] - (size + 20) // 2, self.thief_snake['y'] - (size + 20) // 2))

            # Draw the circular image
            screen.blit(circular_img, (self.thief_snake['x'] - size // 2, self.thief_snake['y'] - size // 2))

        # Draw bonus message if active
        if self.bonus_message:
            current_time = pygame.time.get_ticks()
            elapsed = current_time - self.bonus_message['time']
            if elapsed < self.bonus_message['duration']:
                # Fade out effect
                alpha = int(255 * (1 - elapsed / self.bonus_message['duration']))
                bonus_color = self.bonus_message.get('color', GOLD_BRIGHT)
                bonus_surf = font_large.render(self.bonus_message['text'], True, bonus_color)
                bonus_surf.set_alpha(alpha)
                bonus_x = WIDTH // 2 - bonus_surf.get_width() // 2
                bonus_y = HEIGHT // 2 - 100
                screen.blit(bonus_surf, (bonus_x, bonus_y))
        
        # Draw save message if active
        if self.save_message:
            current_time = pygame.time.get_ticks()
            elapsed = current_time - self.save_message['time']
            if elapsed < self.save_message['duration']:
                # Fade out effect
                alpha = int(255 * (1 - elapsed / self.save_message['duration']))
                # Use green color for save message
                save_color = GREEN_BRIGHT if 'Failed' not in self.save_message['text'] else RED
                save_surf = font_medium.render(self.save_message['text'], True, save_color)
                save_surf.set_alpha(alpha)
                save_x = WIDTH // 2 - save_surf.get_width() // 2
                save_y = HEIGHT // 2 - 50  # Position below center
                screen.blit(save_surf, (save_x, save_y))
        
        # Draw achievement message if active
        if self.achievement_message:
            current_time = pygame.time.get_ticks()
            elapsed = current_time - self.achievement_message['time']
            if elapsed < self.achievement_message['duration']:
                # Fade out effect
                alpha = int(255 * (1 - elapsed / self.achievement_message['duration']))
                
                # Draw achievement panel background (bottom right corner)
                panel_width = 400
                panel_height = 250
                panel_x = WIDTH - panel_width - 20  # 20 pixels from right edge
                panel_y = HEIGHT - panel_height - 20  # 20 pixels from bottom edge
                
                # Semi-transparent background
                panel_surface = pygame.Surface((panel_width, panel_height), pygame.SRCALPHA)
                pygame.draw.rect(panel_surface, (20, 20, 20, int(230 * (alpha / 255))), panel_surface.get_rect())
                pygame.draw.rect(panel_surface, (GOLD_BRIGHT[0], GOLD_BRIGHT[1], GOLD_BRIGHT[2], alpha), panel_surface.get_rect(), 3)
                panel_surface.set_alpha(alpha)
                screen.blit(panel_surface, (panel_x, panel_y))
                
                # Draw achievement image if available
                achievement_img = None
                achievement_name = self.achievement_message['text']

                # Special achievements with specific images
                if self.achievement_message.get('use_lavender_image', False) and self.lavender_hognose_image:
                    # Scale lavender hognose image to 200x200 for achievement display
                    achievement_img = pygame.transform.smoothscale(self.lavender_hognose_image, (200, 200))
                elif achievement_name == 'you started an education program about reptiles' and self.achievement_image:
                    achievement_img = self.achievement_image
                elif achievement_name == 'oops we lost the code' and self.missing_texture_image:
                    achievement_img = pygame.transform.smoothscale(self.missing_texture_image, (200, 200))
                elif achievement_name == 'dedicated player' and self.dedicated_player_image:
                    achievement_img = self.dedicated_player_image
                # Snake-related achievements use Snakes.png
                elif any(keyword in achievement_name.lower() for keyword in ['snake', 'snakes']) and self.snakes_money_icon:
                    achievement_img = pygame.transform.smoothscale(self.snakes_money_icon, (200, 200))
                else:
                    # Try to load achievement-specific image, fallback to missing texture
                    img = self.load_achievement_image(achievement_name, 200)
                    if img is None and self.missing_texture_image:
                        achievement_img = pygame.transform.smoothscale(self.missing_texture_image, (200, 200))
                    else:
                        achievement_img = img
                
                if achievement_img:
                    img_alpha = alpha
                    img_surface = achievement_img.copy()
                    img_surface.set_alpha(img_alpha)
                    img_x = panel_x + (panel_width - img_surface.get_width()) // 2
                    img_y = panel_y + 20
                    screen.blit(img_surface, (img_x, img_y))
                
                # Draw achievement text - use special font for dedicated player
                if self.achievement_message['text'] == 'dedicated player' and self.dedicated_player_font:
                    achievement_surf = self.dedicated_player_font.render(self.achievement_message['text'], True, GOLD_BRIGHT)
                else:
                    achievement_surf = font_medium.render(self.achievement_message['text'], True, GOLD_BRIGHT)
                achievement_surf.set_alpha(alpha)
                text_x = panel_x + (panel_width - achievement_surf.get_width()) // 2  # Center within panel
                text_y = panel_y + panel_height - 60
                screen.blit(achievement_surf, (text_x, text_y))
        
        # Action buttons with premium styling - taller
        reset_hover = self.reset_btn_rect.collidepoint(mouse_pos)
        save_hover = self.save_btn_rect.collidepoint(mouse_pos)
        fullscreen_hover = self.fullscreen_btn_rect.collidepoint(mouse_pos)
        tutorial_hover = self.tutorial_btn_rect.collidepoint(mouse_pos)
        
        self.draw_button(screen, self.fullscreen_btn_rect, "Fullscreen", BLUE_ACCENT, WHITE, fullscreen_hover, border_color=GREEN_BRIGHT)
        self.draw_button(screen, self.tutorial_btn_rect, "Tutorial", PURPLE, WHITE, tutorial_hover, border_color=GREEN_BRIGHT)
        self.draw_button(screen, self.reset_btn_rect, "Reset Game", DARK_RED, WHITE, reset_hover, border_color=RED)
        self.draw_button(screen, self.save_btn_rect, "Save", GREEN_BUTTON, WHITE, save_hover, border_color=GREEN_BRIGHT)
        
        # Draw tutorial bot, speech bubble, and pointer (at the end so they render on top)
        if self.tutorial_active:
            # Draw tutorial bot in bottom-left corner
            bot_scale = 0.90  # 3x bigger (was 0.15, then 0.45, now 0.90)
            bot_x = 0
            bot_y = HEIGHT
            
            # Choose which animation to use
            if self.tutorial_message and self.tutorial_bot_talking_frames:
                if self.tutorial_bot_talking_frame_index < len(self.tutorial_bot_talking_frames):
                    bot_frame = self.tutorial_bot_talking_frames[self.tutorial_bot_talking_frame_index]
                    bot_width = int(bot_frame.get_width() * bot_scale)
                    bot_height = int(bot_frame.get_height() * bot_scale)
                    bot_y = HEIGHT - bot_height
                    scaled_bot = pygame.transform.smoothscale(bot_frame, (bot_width, bot_height))
                    screen.blit(scaled_bot, (bot_x, bot_y))
            elif not self.tutorial_message and self.tutorial_bot_nottalking_frames:
                if self.tutorial_bot_nottalking_frame_index < len(self.tutorial_bot_nottalking_frames):
                    bot_frame = self.tutorial_bot_nottalking_frames[self.tutorial_bot_nottalking_frame_index]
                    bot_width = int(bot_frame.get_width() * bot_scale)
                    bot_height = int(bot_frame.get_height() * bot_scale)
                    bot_y = HEIGHT - bot_height
                    scaled_bot = pygame.transform.smoothscale(bot_frame, (bot_width, bot_height))
                    screen.blit(scaled_bot, (bot_x, bot_y))
            
            # Draw speech bubble if message is active
            if self.tutorial_message and self.tutorial_displayed_text:
                # Check if text animation is complete
                text_complete = self.tutorial_text_index >= len(self.tutorial_full_text)
                
                # Position speech bubble to the right of bot (closer now)
                bubble_x = bot_x + bot_width + 30  # Closer to bot
                bubble_y = bot_y - 100  # Moved some down
                bubble_width = 600  # Enlarged from 400
                bubble_height = 225  # Enlarged from 150
                bubble_padding = 20  # Increased padding
                
                # Draw speech bubble image if available, otherwise fallback to drawn version
                if self.speech_bubble_image:
                    # Scale bubble image to desired size
                    scaled_bubble = pygame.transform.smoothscale(self.speech_bubble_image, (bubble_width, bubble_height))
                    screen.blit(scaled_bubble, (bubble_x, bubble_y))
                else:
                    # Fallback: Draw speech bubble background (pink colors)
                    PINK_LIGHT = (255, 192, 203)
                    PINK_DARK = (255, 105, 180)
                    bubble_rect = pygame.Rect(bubble_x, bubble_y, bubble_width, bubble_height)
                    pygame.draw.rect(screen, PINK_LIGHT, bubble_rect)
                    pygame.draw.rect(screen, PINK_DARK, bubble_rect, 3)
                    
                    # Draw speech bubble tail pointing left (flipped horizontally)
                    tail_points = [
                        (bubble_x, bubble_y + bubble_height // 2),
                        (bubble_x - 20, bubble_y + bubble_height // 2 + 10),
                        (bubble_x - 20, bubble_y + bubble_height // 2 - 10)
                    ]
                    pygame.draw.polygon(screen, PINK_LIGHT, tail_points)
                    pygame.draw.polygon(screen, PINK_DARK, tail_points, 3)
                
                # Draw text with word wrapping
                words = self.tutorial_displayed_text.split(' ')
                lines = []
                current_line = ""
                for word in words:
                    test_line = current_line + (" " if current_line else "") + word
                    text_surf = font_small.render(test_line, True, (0, 0, 0))
                    if text_surf.get_width() <= bubble_width - bubble_padding * 2:
                        current_line = test_line
                    else:
                        if current_line:
                            lines.append(current_line)
                        current_line = word
                if current_line:
                    lines.append(current_line)
                
                # Draw wrapped text
                text_y = bubble_y + bubble_padding
                for line in lines:
                    text_surf = font_small.render(line, True, (0, 0, 0))
                    text_x = bubble_x + bubble_padding
                    screen.blit(text_surf, (text_x, text_y))
                    text_y += font_small.get_height() + 5
                
                # Draw pointer after text animation completes
                if text_complete and self.pointer_target and self.pointer_frames and len(self.pointer_frames) >= 2:
                    # Get target position based on pointer_target
                    target_x = 0
                    target_y = 0
                    offset_distance = 30
                    
                    if self.pointer_target == 'egg':
                        target_x = self.egg_rect.centerx
                        target_y = self.egg_rect.centery
                    elif self.pointer_target == 'upgrades_tab':
                        target_x = self.upgrades_tab_rect.centerx
                        target_y = self.upgrades_tab_rect.centery
                    elif self.pointer_target == 'generators_tab':
                        target_x = self.generators_tab_rect.centerx
                        target_y = self.generators_tab_rect.centery
                    elif self.pointer_target == 'achievements_tab':
                        target_x = self.achievements_tab_rect.centerx
                        target_y = self.achievements_tab_rect.centery
                    elif self.pointer_target == 'fullscreen_btn':
                        target_x = self.fullscreen_btn_rect.centerx
                        target_y = self.fullscreen_btn_rect.centery
                    elif self.pointer_target == 'first_upgrade':
                        # First upgrade in shop
                        scale_y = HEIGHT / 1000.0
                        y_offset = self.shop_rect.y + int(10 * scale_y) - self.scroll_y_upgrades
                        item_height = int(110 * scale_y)
                        target_x = self.shop_rect.centerx
                        target_y = y_offset + item_height // 2
                    elif self.pointer_target == 'first_generator':
                        # First generator in shop
                        scale_y = HEIGHT / 1000.0
                        y_offset = self.shop_rect.y + int(10 * scale_y) - self.scroll_y_generators
                        item_height = int(110 * scale_y)
                        target_x = self.shop_rect.centerx
                        target_y = y_offset + item_height // 2
                    elif self.pointer_target == 'lavender_hognose' and self.lavender_hognose:
                        target_x = self.lavender_hognose['x']
                        target_y = self.lavender_hognose['y']
                    elif self.pointer_target == 'thief_snake' and self.thief_snake:
                        target_x = self.thief_snake['x']
                        target_y = self.thief_snake['y']
                    
                    # Position pointer at bottom-right of target
                    pointer_x = target_x + offset_distance
                    pointer_y = target_y + offset_distance
                    
                    # Draw pointer frame (alternate between pointing and clicking)
                    pointer_frame = self.pointer_frames[self.pointer_frame_index]
                    pointer_scale = 0.3
                    pointer_width = int(pointer_frame.get_width() * pointer_scale)
                    pointer_height = int(pointer_frame.get_height() * pointer_scale)
                    scaled_pointer = pygame.transform.smoothscale(pointer_frame, (pointer_width, pointer_height))
                    screen.blit(scaled_pointer, (pointer_x, pointer_y))
        
        pygame.display.flip()
    
    def handle_click(self, pos):
        # Tutorial button
        if self.tutorial_btn_rect.collidepoint(pos):
            if not self.tutorial_active:
                self.start_tutorial()
            return True
        
        # Lavender Hognose (golden cookie equivalent) - check first so it has priority
        if self.lavender_hognose and self.lavender_hognose_image:
            # Use same size calculation as drawing (8% of screen height)
            hognose_size = int(HEIGHT * 0.08)
            hognose_rect = pygame.Rect(
                self.lavender_hognose['x'] - hognose_size // 2,
                self.lavender_hognose['y'] - hognose_size // 2,
                hognose_size,
                hognose_size
            )
            if hognose_rect.collidepoint(pos):
                # Check if this is the first time clicking the lavender hognose
                is_first_click = not self.state.get('lavender_hognose_clicked', False)
                
                # During tutorial, give exactly 15 snakes
                if self.tutorial_active:
                    bonus = 15
                    self.state['snakes'] += bonus
                    bonus_text = f"+{bonus} snakes!"
                    self.tutorial_lavender_hognose_clicked = True
                else:
                    # Clicked the lavender hognose! Give bonus
                    import random
                    bonus_type = random.choice(['snakes', 'multiplier', 'time'])
                    
                    if bonus_type == 'snakes':
                        # Give snakes equal to 10 minutes of production
                        bonus = max(100, self.state['snakes_per_second'] * 600)
                        self.state['snakes'] += bonus
                        bonus_text = f"+{self.format_number(bonus)} snakes!"
                    elif bonus_type == 'multiplier':
                        # Double production for 30 seconds (stored in state)
                        if 'production_multiplier' not in self.state:
                            self.state['production_multiplier'] = 1.0
                        self.state['production_multiplier'] = 2.0
                        self.state['multiplier_end_time'] = pygame.time.get_ticks() + 30000
                        bonus_text = "2x production for 30s!"
                    else:  # time
                        # Give 1 hour of production instantly
                        bonus = max(1000, self.state['snakes_per_second'] * 3600)
                        self.state['snakes'] += bonus
                        bonus_text = f"+{self.format_number(bonus)} snakes!"
                
                # Mark as clicked
                self.state['lavender_hognose_clicked'] = True
                
                # Trigger achievement if first click
                if is_first_click:
                    self.trigger_achievement("super rare morph!", use_lavender_image=True)
                
                # Remove the lavender hognose
                self.lavender_hognose = None
                self.lavender_hognose_spawn_timer = pygame.time.get_ticks()
                self.save_state()
                
                # Show bonus message (we'll display this in the draw function)
                self.bonus_message = {
                    'text': bonus_text,
                    'time': pygame.time.get_ticks(),
                    'duration': 2000  # 2 seconds
                }
                return True

        # Thief Snake - check if clicked to shoo it away
        if self.thief_snake and self.thief_snake_image:
            # Use same size calculation as drawing (7% of screen height)
            thief_size = int(HEIGHT * 0.07)
            thief_rect = pygame.Rect(
                self.thief_snake['x'] - thief_size // 2,
                self.thief_snake['y'] - thief_size // 2,
                thief_size,
                thief_size
            )
            if thief_rect.collidepoint(pos):
                # Track tutorial progress
                if self.tutorial_active:
                    self.tutorial_thief_snake_clicked = True
                
                # Shoo away the thief snake
                self.thief_snake = None
                self.thief_snake_spawn_timer = pygame.time.get_ticks()

                # Show message that thief was shooed away
                current_time = pygame.time.get_ticks()
                self.bonus_message = {
                    'text': 'Thief Snake shooed away!',
                    'time': current_time,
                    'duration': 2000,  # 2 seconds
                    'color': GREEN_BRIGHT
                }
                return True  # Don't process other clicks

        # Egg button
        if self.egg_rect.collidepoint(pos):
            self.click_egg()
            return True
        
        # Tabs - check buttons first to avoid conflicts
        # Check all tabs and return immediately if clicked (order: upgrades, achievements, generators)
        if self.upgrades_tab_rect.collidepoint(pos):
            self.current_tab = 'upgrades'
            max_scroll = self.get_max_scroll('upgrades')
            self.scroll_y_upgrades = min(max_scroll, max(0, self.scroll_y_upgrades))
            print(f"DEBUG: Clicked upgrades tab, current_tab set to: {self.current_tab}")
            return True
        if self.achievements_tab_rect.collidepoint(pos):
            self.current_tab = 'achievements'
            max_scroll = self.get_max_scroll('achievements')
            self.scroll_y_achievements = min(max_scroll, max(0, self.scroll_y_achievements))
            print(f"DEBUG: Clicked achievements tab, current_tab set to: {self.current_tab}")
            return True
        if self.generators_tab_rect.collidepoint(pos):
            self.current_tab = 'generators'
            max_scroll = self.get_max_scroll('generators')
            self.scroll_y_generators = min(max_scroll, max(0, self.scroll_y_generators))
            print(f"DEBUG: Clicked generators tab, current_tab set to: {self.current_tab}")
            return True
        
        # Action buttons - check before shop items
        if self.fullscreen_btn_rect.collidepoint(pos):
            self.toggle_fullscreen()
            return True
        if self.reset_btn_rect.collidepoint(pos):
            return 'reset'
        if self.save_btn_rect.collidepoint(pos):
            self.save_state()
            return True
        
        # Shop items - improved click detection
        # Only process shop clicks if not clicking on tabs (tabs are at y=430-480, shop starts at y=490)
        # Make sure we're not clicking on any tab area - tabs end at y=480
        tab_area_y_end = 480  # Tabs are at y=430 with height 50, so they end at y=480
        if self.shop_rect.collidepoint(pos) and pos[1] > tab_area_y_end:
            # Scale values for current screen size
            scale_x = WIDTH / 1600.0
            scale_y = HEIGHT / 1000.0
            # Use shop_rect position for y_offset (was hardcoded 500)
            scroll_y = self.scroll_y_upgrades if self.current_tab == 'upgrades' else (self.scroll_y_generators if self.current_tab == 'generators' else self.scroll_y_achievements)
            y_offset = self.shop_rect.y + int(10 * scale_y) - scroll_y
            item_height = int(110 * scale_y)  # Scale item height
            shop_top = self.shop_rect.y + int(10 * scale_y)
            relative_y = pos[1] - y_offset
            
            # Only process clicks within visible shop area
            shop_bottom = self.shop_rect.y + self.shop_rect.height - int(10 * scale_y)
            if shop_top <= pos[1] <= shop_bottom and relative_y >= 0:
                index = int(relative_y // item_height)
                if self.current_tab == 'upgrades':
                    if 0 <= index < len(self.state['upgrades']):
                        self.buy_upgrade(index)
                        return True
                else:
                    if 0 <= index < len(self.state['generators']):
                        self.buy_generator(index)
                        return True
            return False
        
        return False
    
    def toggle_fullscreen(self):
        """Toggle between fullscreen and windowed mode"""
        global screen, WIDTH, HEIGHT
        self.fullscreen = not self.fullscreen
        
        if self.fullscreen:
            # Get the current display mode for fullscreen
            screen = pygame.display.set_mode((0, 0), pygame.FULLSCREEN)
            WIDTH, HEIGHT = screen.get_size()
        else:
            # Return to windowed mode with original size
            WIDTH, HEIGHT = 1600, 1000
            screen = pygame.display.set_mode((WIDTH, HEIGHT))
        
        # Invalidate background cache to force rescaling
        self.scaled_background = None
        self.cached_bg_size = None
        self.scaled_shop_bg = None
        self.cached_shop_bg_size = None
        
        # Update all UI element positions for new screen size
        self.reset_btn_rect = pygame.Rect(WIDTH - 300, 10, 140, 35)
        self.save_btn_rect = pygame.Rect(WIDTH - 150, 10, 100, 35)
        self.fullscreen_btn_rect = pygame.Rect(10, 10, 100, 35)
        self.tutorial_btn_rect = pygame.Rect(120, 10, 100, 35)
        
        # Update shop and tab positions - scale proportionally
        # Calculate scale factors
        scale_x = WIDTH / 1600.0
        scale_y = HEIGHT / 1000.0
        
        # Update shop rect (was: 50, 490, WIDTH - 100, 500)
        shop_x = int(50 * scale_x)
        shop_y = int(490 * scale_y)
        shop_width = WIDTH - int(100 * scale_x)
        shop_height = int(500 * scale_y)
        self.shop_rect = pygame.Rect(shop_x, shop_y, shop_width, shop_height)
        
        # Update tab positions (was: upgrades at 50,430 and generators at 290,430)
        tab_y = int(430 * scale_y)
        tab_width = int(230 * scale_x)
        tab_height = int(50 * scale_y)
        self.upgrades_tab_rect = pygame.Rect(int(50 * scale_x), tab_y, tab_width, tab_height)
        self.generators_tab_rect = pygame.Rect(int(290 * scale_x), tab_y, tab_width, tab_height)
        self.achievements_tab_rect = pygame.Rect(int(530 * scale_x), tab_y, tab_width, tab_height)
        
        pygame.display.flip()
    
    def run(self):
        running = True
        reset_pending = False
        
        while running:
            for event in pygame.event.get():
                if event.type == pygame.QUIT:
                    running = False
                elif event.type == pygame.MOUSEBUTTONDOWN:
                    if event.button == 1:  # Left click
                        result = self.handle_click(event.pos)
                        if result == 'reset':
                            reset_pending = True
                    elif event.button == 4:  # Scroll up - move content up (increase scroll_y since we subtract it)
                        if self.current_tab == 'upgrades':
                            max_scroll = self.get_max_scroll('upgrades')
                            if max_scroll > 0:  # Only scroll if there's content cut off
                                self.scroll_y_upgrades = min(max_scroll, self.scroll_y_upgrades + 30)
                        else:
                            max_scroll = self.get_max_scroll('generators')
                            if max_scroll > 0:  # Only scroll if there's content cut off
                                self.scroll_y_generators = min(max_scroll, self.scroll_y_generators + 30)
                    elif event.button == 5:  # Scroll down - move content down (decrease scroll_y since we subtract it)
                        if self.current_tab == 'upgrades':
                            max_scroll = self.get_max_scroll('upgrades')
                            if max_scroll > 0:  # Only scroll if there's content cut off
                                self.scroll_y_upgrades = max(0, self.scroll_y_upgrades - 30)
                        else:
                            max_scroll = self.get_max_scroll('generators')
                            if max_scroll > 0:  # Only scroll if there's content cut off
                                self.scroll_y_generators = max(0, self.scroll_y_generators - 30)
                elif event.type == pygame.KEYDOWN:
                    if event.key == pygame.K_F11:
                        # Toggle fullscreen with F11
                        self.toggle_fullscreen()
                    elif reset_pending and (event.key == pygame.K_y or event.key == pygame.K_RETURN):
                        # Reset game state in place without closing
                        self.reset_game()
                        # Show reset confirmation message
                        self.save_message = {
                            'text': 'Game Reset! All progress cleared.',
                            'time': pygame.time.get_ticks(),
                            'duration': 3000  # 3 seconds
                        }
                        reset_pending = False
                    elif reset_pending and (event.key == pygame.K_n or event.key == pygame.K_ESCAPE):
                        reset_pending = False
            
            self.update()
            self.draw()
            
            # Show reset confirmation - very safe colors, no flashing
            if reset_pending:
                # Very dark overlay to reduce contrast
                overlay = pygame.Surface((WIDTH, HEIGHT), pygame.SRCALPHA)
                overlay.fill((0, 0, 0, 200))  # Very dark overlay
                screen.blit(overlay, (0, 0))

                confirm_rect = pygame.Rect(WIDTH//2 - 250, HEIGHT//2 - 75, 500, 150)
                # Very dark gray background (almost black)
                pygame.draw.rect(screen, (25, 25, 25), confirm_rect)
                # Very subtle border (dark gray, not bright)
                pygame.draw.rect(screen, (60, 60, 60), confirm_rect, 2)

                # Muted gray text (no bright colors)
                title_text = font_title.render("RESET GAME?", True, (180, 180, 180))
                screen.blit(title_text, (WIDTH//2 - title_text.get_width()//2, HEIGHT//2 - 50))

                confirm_text = font_medium.render("This will delete all progress!", True, (160, 160, 160))
                screen.blit(confirm_text, (WIDTH//2 - confirm_text.get_width()//2, HEIGHT//2 - 15))

                # Muted gray text for instructions
                instruction_text = font_small.render("Press Y for Yes, N for No", True, (140, 140, 140))
                screen.blit(instruction_text, (WIDTH//2 - instruction_text.get_width()//2, HEIGHT//2 + 15))
            
            clock.tick(60)
        
        pygame.quit()

if __name__ == '__main__':
    game = SnakeIdleGame()
    game.run()
